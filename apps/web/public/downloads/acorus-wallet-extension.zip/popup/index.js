"use strict";
(() => {
  // ../../packages/shared/src/chains.ts
  var DEFAULT_SOLANA_CHAIN_ID = 101;
  var DEFAULT_TRON_CHAIN_ID = "tron-mainnet";
  var DEFAULT_BITCOIN_CHAIN_ID = "bitcoin-mainnet";
  var DEFAULT_TON_CHAIN_ID = "ton-mainnet";
  var EVM_CHAINS = [
    {
      chainId: 1,
      family: "evm",
      name: "Ethereum",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ETH_RPC_URL",
      blockExplorerUrl: "https://etherscan.io"
    },
    {
      chainId: 56,
      family: "evm",
      name: "BNB Smart Chain",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_BSC_RPC_URL",
      blockExplorerUrl: "https://bscscan.com"
    },
    {
      chainId: 137,
      family: "evm",
      name: "Polygon",
      nativeSymbol: "MATIC",
      rpcUrlEnv: "NEXT_PUBLIC_POLYGON_RPC_URL",
      blockExplorerUrl: "https://polygonscan.com"
    },
    {
      chainId: 42161,
      family: "evm",
      name: "Arbitrum One",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ARBITRUM_RPC_URL",
      blockExplorerUrl: "https://arbiscan.io"
    },
    {
      chainId: 10,
      family: "evm",
      name: "Optimism",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_OPTIMISM_RPC_URL",
      blockExplorerUrl: "https://optimistic.etherscan.io"
    },
    {
      chainId: 8453,
      family: "evm",
      name: "Base",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_BASE_RPC_URL",
      blockExplorerUrl: "https://basescan.org"
    },
    {
      chainId: 43114,
      family: "evm",
      name: "Avalanche",
      nativeSymbol: "AVAX",
      rpcUrlEnv: "NEXT_PUBLIC_AVALANCHE_RPC_URL",
      blockExplorerUrl: "https://snowtrace.io"
    },
    {
      chainId: 59144,
      family: "evm",
      name: "Linea",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_LINEA_RPC_URL",
      blockExplorerUrl: "https://lineascan.build"
    },
    {
      chainId: 250,
      family: "evm",
      name: "Fantom",
      nativeSymbol: "FTM",
      rpcUrlEnv: "NEXT_PUBLIC_FANTOM_RPC_URL",
      blockExplorerUrl: "https://ftmscan.com"
    },
    {
      chainId: 1329,
      family: "evm",
      name: "Sei",
      nativeSymbol: "SEI",
      rpcUrlEnv: "NEXT_PUBLIC_SEI_RPC_URL",
      blockExplorerUrl: "https://seitrace.com"
    },
    {
      chainId: 204,
      family: "evm",
      name: "opBNB",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_OPBNB_RPC_URL",
      blockExplorerUrl: "https://opbnbscan.com"
    },
    {
      chainId: 324,
      family: "evm",
      name: "zkSync Era",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ZKSYNC_RPC_URL",
      blockExplorerUrl: "https://era.zksync.network"
    }
  ];
  var SOLANA_MAINNET_CHAIN = {
    chainId: DEFAULT_SOLANA_CHAIN_ID,
    family: "solana",
    name: "Solana",
    network: "mainnet-beta",
    nativeSymbol: "SOL",
    rpcUrlEnv: "NEXT_PUBLIC_SOLANA_RPC_URL",
    blockExplorerUrl: "https://solscan.io"
  };
  var TRON_MAINNET_CHAIN = {
    family: "tron",
    chainId: DEFAULT_TRON_CHAIN_ID,
    name: "Tron",
    nativeSymbol: "TRX",
    rpcUrlEnv: "NEXT_PUBLIC_TRON_RPC_URL",
    blockExplorerUrl: "https://tronscan.org/#",
    isEnabled: false,
    isSkeleton: true
  };
  var BITCOIN_MAINNET_CHAIN = {
    family: "utxo",
    chainId: DEFAULT_BITCOIN_CHAIN_ID,
    name: "Bitcoin",
    nativeSymbol: "BTC",
    rpcUrlEnv: "NEXT_PUBLIC_BITCOIN_RPC_URL",
    blockExplorerUrl: "https://mempool.space",
    isEnabled: false,
    isSkeleton: true
  };
  var TON_MAINNET_CHAIN = {
    family: "ton",
    chainId: DEFAULT_TON_CHAIN_ID,
    name: "TON",
    nativeSymbol: "TON",
    rpcUrlEnv: "NEXT_PUBLIC_TON_RPC_URL",
    blockExplorerUrl: "https://tonscan.org",
    isEnabled: false,
    isSkeleton: true
  };
  var UNIVERSAL_CHAINS = [
    ...EVM_CHAINS.map((chain) => ({
      family: "evm",
      chainId: chain.chainId,
      name: chain.name,
      nativeSymbol: chain.nativeSymbol,
      rpcUrlEnv: chain.rpcUrlEnv,
      blockExplorerUrl: chain.blockExplorerUrl,
      isEnabled: true
    })),
    {
      family: SOLANA_MAINNET_CHAIN.family,
      chainId: SOLANA_MAINNET_CHAIN.chainId,
      name: SOLANA_MAINNET_CHAIN.name,
      nativeSymbol: SOLANA_MAINNET_CHAIN.nativeSymbol,
      rpcUrlEnv: SOLANA_MAINNET_CHAIN.rpcUrlEnv,
      blockExplorerUrl: SOLANA_MAINNET_CHAIN.blockExplorerUrl,
      network: SOLANA_MAINNET_CHAIN.network,
      isEnabled: true
    },
    TRON_MAINNET_CHAIN,
    BITCOIN_MAINNET_CHAIN,
    TON_MAINNET_CHAIN
  ];

  // ../../packages/shared/src/dapp.ts
  function getDappRequestKindLabel(kind) {
    switch (kind) {
      case "connect":
        return "Connect";
      case "add_chain":
        return "Add network";
      case "watch_asset":
        return "Watch asset";
      case "multichain_send":
        return "Send";
      case "swap":
        return "Swap";
      case "sign_message":
        return "Sign message";
      case "sign_typed_data":
        return "Sign typed data";
      case "sign_transaction":
        return "Sign transaction";
      case "send_transaction":
        return "Send transaction";
      default:
        return kind;
    }
  }
  function getDappConnectionTransportLabel(transport) {
    switch (transport) {
      case "walletconnect":
        return "WalletConnect";
      case "injected":
      default:
        return "Injected";
    }
  }

  // src/shared/evm-compat.ts
  var EVM_COMPATIBILITY_METHODS = [
    "eth_requestAccounts",
    "eth_accounts",
    "eth_chainId",
    "web3_clientVersion",
    "net_version",
    "eth_coinbase",
    "wallet_getPermissions",
    "wallet_requestPermissions",
    "wallet_revokePermissions",
    "wallet_addEthereumChain",
    "wallet_switchEthereumChain",
    "wallet_watchAsset",
    "personal_sign",
    "eth_signTypedData_v4",
    "eth_signTransaction",
    "eth_sendTransaction"
  ];

  // src/shared/protocol.ts
  var ACORUS_PROVIDER_METHODS = [
    "acorus_ping",
    "acorus_getVaultStatus",
    "acorus_createWallet",
    "acorus_importWallet",
    "acorus_unlockWallet",
    "acorus_lockWallet",
    "acorus_receiveAddress",
    "acorus_requestAccounts",
    "acorus_accounts",
    "acorus_chainId",
    "acorus_switchChain",
    "acorus_getPermissions",
    "acorus_requestPermissions",
    "acorus_revokePermissions",
    "acorus_addChain",
    "acorus_watchAsset",
    "acorus_multichainSend",
    "acorus_swap",
    "acorus_signMessage",
    "acorus_signTypedData",
    "acorus_signTransaction",
    "acorus_sendTransaction"
  ];
  function createRequestId(prefix = "acorus") {
    if (globalThis.crypto?.randomUUID) {
      return `${prefix}_${globalThis.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }
  function createSkeletonState(input) {
    return {
      phase: "permission_shell",
      providerInjection: input?.providerInjection ?? "stub_only",
      executionEnabled: input?.executionEnabled ?? true,
      proposals: input?.proposals ?? [],
      sessions: input?.sessions ?? [],
      pendingRequests: input?.pendingRequests ?? [],
      approvalResults: input?.approvalResults ?? [],
      signerUnlockQueue: input?.signerUnlockQueue ?? [],
      activeOriginBridge: input?.activeOriginBridge ?? null,
      walletExposureMode: input?.walletExposureMode ?? "preview_accounts",
      walletExposedAccounts: input?.walletExposedAccounts ?? [],
      walletLastSyncedAt: input?.walletLastSyncedAt ?? null,
      extensionVaultStatus: input?.extensionVaultStatus ?? {
        hasVault: false,
        isUnlocked: false,
        activeProfileId: null,
        profiles: [],
        unlockedAt: null,
        createdAt: null,
        updatedAt: null
      },
      supportedMethods: ACORUS_PROVIDER_METHODS,
      lastUpdatedAt: input?.lastUpdatedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
      activeOrigin: input?.activeOrigin ?? null
    };
  }

  // src/popup/index.ts
  var root = getRoot("Popup root not found.");
  var lastCreatedMnemonic = null;
  var currentPopupState = createSkeletonState();
  var currentHomeSnapshot = null;
  void loadPopupState();
  async function loadPopupState() {
    let state = createSkeletonState();
    let home = null;
    try {
      const [stateResponse, homeResponse] = await Promise.all([
        chrome.runtime.sendMessage({
          kind: "get_state",
          requestId: createRequestId("popup"),
          surface: "popup",
          origin: null
        }),
        loadExtensionHome()
      ]);
      if (stateResponse.ok && stateResponse.result) {
        state = stateResponse.result;
      }
      home = homeResponse;
    } catch {
      state = createSkeletonState();
      home = null;
    }
    currentPopupState = state;
    currentHomeSnapshot = home;
    root.innerHTML = renderPopup(state, home);
    wirePopupActions();
  }
  async function loadExtensionHome() {
    try {
      const response = await chrome.runtime.sendMessage({
        kind: "get_extension_home",
        requestId: createRequestId("popup_home"),
        surface: "popup"
      });
      return response.ok && response.result ? response.result : null;
    } catch {
      return null;
    }
  }
  function renderPopup(state, home) {
    const vault = state.extensionVaultStatus;
    const selectedProfile = vault.profiles.find((profile) => profile.selected) ?? state.walletExposedAccounts.find((profile) => profile.selected) ?? vault.profiles[0] ?? state.walletExposedAccounts[0] ?? null;
    const activeChain = home?.activeChainId ?? selectedProfile?.chainIds[0] ?? state.activeOriginBridge?.activeChainId ?? 1;
    const pendingCount = state.proposals.length + state.pendingRequests.length + state.signerUnlockQueue.length;
    return `
    <main class="wallet-shell">
      <header class="wallet-header">
        <div class="brand">
          <div class="brand-mark">A</div>
          <div>
            <div class="brand-title">Acorus</div>
            <div class="brand-subtitle">${escapeHtml(selectedProfile?.name ?? "Multichain wallet")}</div>
          </div>
        </div>
        <div class="row">
          <span class="network-pill">${chainName(activeChain)}</span>
          <button class="icon-button" type="button" data-open-url="options.html" title="Settings">\u2699</button>
        </div>
      </header>

      <div class="main">
        ${pendingCount > 0 ? renderPromptNotice(state) : ""}
        ${lastCreatedMnemonic ? renderSeedReveal(lastCreatedMnemonic) : ""}
        ${vault.hasVault ? renderWalletHome(state, selectedProfile, home) : renderOnboarding()}
        ${renderConnectedSites(state)}
        ${renderRecentActivity(state)}
      </div>
    </main>
  `;
  }
  function renderWalletHome(state, selectedProfile, home) {
    const vault = state.extensionVaultStatus;
    const account = selectedProfile?.account ?? "No synced account";
    const unlockedLabel = vault.isUnlocked ? "Unlocked" : "Locked";
    const activeNetwork = home?.networks.find(
      (item) => String(item.chainId) === String(home.activeChainId)
    ) ?? home?.networks[0] ?? null;
    const visibleAssets = home?.assets.filter(
      (asset) => !activeNetwork || String(asset.chainId) === String(activeNetwork.chainId)
    ).slice(0, 30) ?? [];
    return `
    <section class="account-card">
      <div class="account-row">
        <div>
          <button class="account-name as-button" type="button" data-open-url="options.html">
            ${escapeHtml(selectedProfile?.name ?? "Main wallet")} \u25BE
          </button>
          <button class="address-pill as-button" type="button" data-copy="${escapeHtml(account)}">
            ${shortAddress(account)} <span>\u29C9</span>
          </button>
        </div>
        <button class="network-pill as-button" type="button" data-action="open-network-panel" data-id="network">
          ${escapeHtml(activeNetwork?.name ?? "All networks")} \u25BE
        </button>
      </div>

      <div class="balance">${formatFiat(home?.totalFiatValue)}</div>
      <div class="balance-sub">${unlockedLabel} \xB7 ${state.walletExposureMode === "wallet_backed" ? "Multichain vault active" : "Preview bridge mode"}</div>

      <div class="quick-actions">
        ${quickAction("\uFF0B", "Buy", "internal:buy")}
        ${quickAction("\u21C4", "Swap", "internal:swap")}
        ${quickAction("\u2197", "Send", "internal:send")}
        ${quickAction("\u2199", "Receive", "internal:receive")}
      </div>
    </section>

    ${renderNetworkPanel(home)}
    ${renderExtensionActionPanel(state, home)}

    <section class="panel stack">
      <div class="tabs">
        <span class="tab" data-active="true">Tokens</span>
        <span class="tab">Activity</span>
        <span class="tab">dApps</span>
        <span class="tab">NFT</span>
      </div>
      <div class="row">
        <span class="network-pill">All popular networks</span>
        <span class="small">${home?.assets.length ?? 0} assets</span>
      </div>
      <div class="token-list">
        ${visibleAssets.length ? visibleAssets.map(renderAssetRow).join("") : `<p class="copy">No live assets yet. Add a token or switch network.</p>`}
      </div>
      ${home?.warnings.length ? renderWarnings(home.warnings) : ""}
      <div class="row">
        ${vault.isUnlocked ? `<button class="ghost-button" type="button" data-action="lock-extension-wallet" data-id="vault">Lock wallet</button>` : `<form id="unlock-wallet-form" class="form" style="flex:1">
                <input class="field" name="passcode" placeholder="Passcode" type="password" autocomplete="current-password">
                <button class="primary-button" type="submit">Unlock</button>
              </form>`}
        <button class="ghost-button" type="button" data-open-url="http://24wallet.ru/extension">Open site</button>
      </div>
    </section>
  `;
  }
  function renderAssetRow(asset) {
    const assetId = [
      asset.family,
      String(asset.chainId),
      asset.type,
      asset.tokenAddress?.toLowerCase() ?? "native",
      asset.symbol.toUpperCase()
    ].join(":");
    return `
    <button class="token-row as-button wide" type="button" data-asset-id="${escapeHtml(assetId)}">
      <div class="token-icon">${escapeHtml(asset.symbol.slice(0, 4))}</div>
      <div>
        <div class="token-name">${escapeHtml(asset.name)}</div>
        <div class="token-meta">
          ${escapeHtml(asset.balanceFormatted ?? "0")} ${escapeHtml(asset.symbol)}
          \xB7 ${escapeHtml(asset.source ?? "unknown")}
        </div>
      </div>
      <div class="token-value">${formatFiat(asset.fiatValue)}</div>
    </button>
  `;
  }
  function renderNetworkPanel(home) {
    if (!home) {
      return "";
    }
    return `
    <section class="panel stack" id="network-panel" hidden>
      <div class="row">
        <h2 class="section-title">Networks</h2>
        <input class="field compact" id="network-search" placeholder="Search">
      </div>
      <div class="network-grid">
        ${home.networks.map((network) => `
          <button class="network-card ${String(network.chainId) === String(home.activeChainId) ? "active" : ""}"
                  type="button"
                  data-action="set-active-chain"
                  data-id="${escapeHtml(String(network.chainId))}">
            <span class="network-dot" style="background:${escapeHtml(network.accent)}"></span>
            <span>
              <strong>${escapeHtml(network.name)}</strong>
              <small>${escapeHtml(network.family.toUpperCase())} \xB7 ${network.capabilities.send ? "send" : "receive only"}</small>
            </span>
          </button>
        `).join("")}
      </div>
    </section>
  `;
  }
  function renderExtensionActionPanel(state, home) {
    return `
    <section class="panel stack" id="action-panel" hidden>
      <div class="row">
        <h2 class="section-title" id="action-title">Action</h2>
        <button class="icon-button" type="button" data-action="close-action-panel" data-id="action">\xD7</button>
      </div>
      <div id="action-content">
        ${renderReceiveComposer(state, home)}
      </div>
    </section>
  `;
  }
  function renderReceiveComposer(state, home) {
    const vault = state.extensionVaultStatus;
    const profiles = vault.profiles.length ? vault.profiles : state.walletExposedAccounts;
    const networks = home?.networks ?? [];
    return `
    <div class="form">
      <label class="small">Network</label>
      <select class="field" id="receive-network">
        ${networks.map((network) => `
          <option value="${escapeHtml(String(network.chainId))}">
            ${escapeHtml(network.name)}
          </option>
        `).join("")}
      </select>
      <div class="receive-box">
        ${profiles.map((profile) => `
          <div class="site-row">
            <div>
              <div class="token-name">${escapeHtml(profile.name)}</div>
              <div class="token-meta">${escapeHtml(profile.chainFamily)} \xB7 ${shortAddress(profile.account)}</div>
            </div>
            <button class="ghost-button" type="button" data-copy="${escapeHtml(profile.account)}">Copy</button>
          </div>
        `).join("")}
      </div>
      <p class="copy">Send only assets from the selected network to the matching address family. Wrong network can permanently lose funds.</p>
    </div>
  `;
  }
  function renderWarnings(warnings) {
    return `
    <section class="notice warning">
      <strong>Network notes</strong>
      <ul>
        ${warnings.slice(0, 4).map((warning) => `<li>${escapeHtml(warning)}</li>`).join("")}
      </ul>
    </section>
  `;
  }
  function renderOnboarding() {
    return `
    <section class="onboarding-card stack">
      <div>
        <h1 style="margin:0;font-size:24px;letter-spacing:-0.03em">Create your wallet</h1>
        <p class="copy" style="margin-top:8px">
          Seed phrase and encrypted vault stay inside this Chrome extension.
          Sites connect through the injected provider, like a normal wallet.
        </p>
      </div>
      <form id="create-wallet-form" class="form">
        <input class="field" name="name" placeholder="Wallet name" value="Main wallet">
        <input class="field" name="passcode" placeholder="Passcode, min 8 chars" type="password" autocomplete="new-password">
        <button class="primary-button" type="submit">Create wallet</button>
      </form>
      <details>
        <summary style="cursor:pointer;font-weight:700">Import existing seed phrase</summary>
        <form id="import-wallet-form" class="form" style="margin-top:12px">
          <input class="field" name="name" placeholder="Wallet name" value="Imported wallet">
          <textarea class="field" name="mnemonic" placeholder="Seed phrase" rows="3"></textarea>
          <input class="field" name="passcode" placeholder="Passcode, min 8 chars" type="password" autocomplete="new-password">
          <button class="ghost-button" type="submit">Import wallet</button>
        </form>
      </details>
    </section>
  `;
  }
  function renderPromptNotice(state) {
    const signer = state.signerUnlockQueue[0];
    if (signer) {
      return `
      <section class="notice warning">
        <strong>${escapeHtml(getDappRequestKindLabel(signer.kind))}</strong><br>
        ${escapeHtml(signer.summary)}
        <div class="row" style="margin-top:10px">
          ${actionButton("confirm-signer-unlock", signer.id, "Confirm", true)}
          ${actionButton("reject-signer-unlock", signer.id, "Reject", false, true)}
        </div>
      </section>
    `;
    }
    const request = state.pendingRequests[0];
    if (request) {
      return `
      <section class="notice warning">
        <strong>${escapeHtml(getDappRequestKindLabel(request.kind))} request</strong><br>
        ${escapeHtml(request.origin.title)} wants approval on ${chainName(request.chainId)}.
        <div class="row" style="margin-top:10px">
          ${actionButton("approve-request", request.id, "Review", true)}
          ${actionButton("reject-request", request.id, "Reject", false, true)}
        </div>
      </section>
    `;
    }
    const proposal = state.proposals[0];
    if (!proposal) {
      return "";
    }
    return `
    <section class="notice warning">
      <strong>Connect request</strong><br>
      ${escapeHtml(proposal.origin.title)} wants to see your selected account.
      <div class="row" style="margin-top:10px">
        ${actionButton("approve-proposal", proposal.id, "Connect", true)}
        ${actionButton("reject-proposal", proposal.id, "Reject", false, true)}
      </div>
    </section>
  `;
  }
  function renderSeedReveal(mnemonic) {
    return `
    <section class="notice warning">
      <strong>Save these words offline now.</strong>
      <div class="seed-grid" style="margin-top:10px">
        ${mnemonic.split(" ").map((word, index) => `<div class="seed-word"><span class="muted">${index + 1}.</span> ${escapeHtml(word)}</div>`).join("")}
      </div>
      <button class="ghost-button" data-action="clear-created-seed" data-id="seed" style="margin-top:10px" type="button">I saved it</button>
    </section>
  `;
  }
  function renderConnectedSites(state) {
    const activeSessions = state.sessions.filter((session) => session.status === "active");
    if (!activeSessions.length && !state.proposals.length) {
      return `
      <section class="panel">
        <h2 class="section-title">Connected sites</h2>
        <p class="copy">No dApps connected yet. Open Acorus or another dApp and connect through the extension.</p>
      </section>
    `;
    }
    return `
    <section class="panel stack">
      <h2 class="section-title">Connected sites</h2>
      ${activeSessions.slice(0, 3).map((session) => `
          <div class="site-row">
            <div>
              <div class="token-name">${escapeHtml(session.origin.title)}</div>
              <div class="token-meta">${escapeHtml(getDappConnectionTransportLabel(session.transport))} \xB7 ${escapeHtml(String(session.activeChainId ?? "multi"))}</div>
            </div>
            ${actionButton("revoke-session", session.id, "Disconnect", false, true)}
          </div>
        `).join("")}
    </section>
  `;
  }
  function renderRecentActivity(state) {
    const latest = state.approvalResults[0];
    const activeBridge = state.activeOriginBridge;
    return `
    <section class="panel stack">
      <h2 class="section-title">Activity</h2>
      <div class="row">
        <span class="small">Provider</span>
        <span class="badge">${escapeHtml(state.providerInjection.replace("_", " "))}</span>
      </div>
      <div class="row">
        <span class="small">EVM methods</span>
        <span class="small">${EVM_COMPATIBILITY_METHODS.length} compatible</span>
      </div>
      <div class="row">
        <span class="small">Active site</span>
        <span class="small">${escapeHtml(activeBridge?.origin ?? "none")}</span>
      </div>
      <p class="copy">${latest ? `${latest.decision} ${latest.targetKind}` : "No approvals yet."}</p>
    </section>
  `;
  }
  function wirePopupActions() {
    wireWalletForms();
    const buttons = root.querySelectorAll("[data-action], [data-open-url], [data-copy]");
    buttons.forEach((button) => {
      button.addEventListener("click", async () => {
        const copyValue = button.dataset.copy;
        if (copyValue) {
          await navigator.clipboard.writeText(copyValue);
          return;
        }
        const openUrl = button.dataset.openUrl;
        if (openUrl) {
          await chrome.tabs.create({ url: openUrl.startsWith("http") ? openUrl : chrome.runtime.getURL(openUrl) });
          return;
        }
        const action = button.dataset.action;
        const targetId = button.dataset.id;
        const extra = button.dataset.extra;
        if (action === "open-network-panel") {
          root.querySelector("#network-panel")?.toggleAttribute("hidden");
          return;
        }
        if (action === "set-active-chain" && targetId) {
          await chrome.runtime.sendMessage({
            kind: "set_active_extension_chain",
            requestId: createRequestId("popup"),
            surface: "popup",
            chainId: /^\d+$/u.test(targetId) ? Number(targetId) : targetId
          });
          await loadPopupState();
          return;
        }
        if (action === "open-action-panel" && targetId) {
          const panel = root.querySelector("#action-panel");
          const title = root.querySelector("#action-title");
          const content = root.querySelector("#action-content");
          if (panel && title && content) {
            panel.hidden = false;
            title.textContent = `${targetId[0]?.toUpperCase() ?? ""}${targetId.slice(1)}`;
            content.innerHTML = renderActionContent(targetId);
            wireInlineButtons(content);
          }
          return;
        }
        if (action === "close-action-panel") {
          const panel = root.querySelector("#action-panel");
          if (panel) {
            panel.hidden = true;
          }
          return;
        }
        if (action === "clear-created-seed") {
          lastCreatedMnemonic = null;
          await loadPopupState();
          return;
        }
        if (action === "lock-extension-wallet") {
          await chrome.runtime.sendMessage({
            kind: "lock_extension_wallet",
            requestId: createRequestId("popup"),
            surface: "popup"
          });
          await loadPopupState();
          return;
        }
        if (!action || !targetId) {
          return;
        }
        button.disabled = true;
        try {
          await sendAction(action, targetId, extra);
        } finally {
          await loadPopupState();
        }
      });
    });
  }
  function wireInlineButtons(scope) {
    scope.querySelectorAll("[data-open-url], [data-copy]").forEach((button) => {
      button.addEventListener("click", async () => {
        const copyValue = button.dataset.copy;
        if (copyValue) {
          await navigator.clipboard.writeText(copyValue);
          return;
        }
        const openUrl = button.dataset.openUrl;
        if (openUrl) {
          await chrome.tabs.create({ url: openUrl.startsWith("http") ? openUrl : chrome.runtime.getURL(openUrl) });
        }
      });
    });
  }
  function wireWalletForms() {
    root.querySelector("#unlock-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const response = await chrome.runtime.sendMessage({
        kind: "unlock_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        passcode: String(formData.get("passcode") ?? "")
      });
      if (!response.ok) {
        window.alert(response.error?.message ?? "Unable to unlock wallet.");
      }
      await loadPopupState();
    });
    root.querySelector("#create-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const response = await chrome.runtime.sendMessage({
        kind: "create_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        name: String(formData.get("name") ?? "Main wallet"),
        passcode: String(formData.get("passcode") ?? "")
      });
      if (response.ok && response.result) {
        const result = response.result;
        lastCreatedMnemonic = result.mnemonic ?? null;
      } else {
        lastCreatedMnemonic = null;
        window.alert(response.error?.message ?? "Unable to create wallet.");
      }
      await loadPopupState();
    });
    root.querySelector("#import-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const response = await chrome.runtime.sendMessage({
        kind: "import_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        name: String(formData.get("name") ?? "Imported wallet"),
        mnemonic: String(formData.get("mnemonic") ?? ""),
        passcode: String(formData.get("passcode") ?? "")
      });
      if (!response.ok) {
        window.alert(response.error?.message ?? "Unable to import wallet.");
      }
      await loadPopupState();
    });
  }
  async function sendAction(action, targetId, extra) {
    if (action === "approve-proposal") {
      await chrome.runtime.sendMessage({
        kind: "approve_proposal",
        requestId: createRequestId("popup"),
        surface: "popup",
        proposalId: targetId
      });
      return;
    }
    if (action === "reject-proposal") {
      await chrome.runtime.sendMessage({
        kind: "reject_proposal",
        requestId: createRequestId("popup"),
        surface: "popup",
        proposalId: targetId
      });
      return;
    }
    if (action === "approve-request") {
      await chrome.runtime.sendMessage({
        kind: "approve_request",
        requestId: createRequestId("popup"),
        surface: "popup",
        requestIdTarget: targetId
      });
      return;
    }
    if (action === "reject-request") {
      await chrome.runtime.sendMessage({
        kind: "reject_request",
        requestId: createRequestId("popup"),
        surface: "popup",
        requestIdTarget: targetId
      });
      return;
    }
    if (action === "revoke-session") {
      await chrome.runtime.sendMessage({
        kind: "revoke_session",
        requestId: createRequestId("popup"),
        surface: "popup",
        sessionId: targetId
      });
      return;
    }
    if (action === "select-wallet-profile") {
      await chrome.runtime.sendMessage({
        kind: "select_wallet_profile",
        requestId: createRequestId("popup"),
        surface: "popup",
        profileId: targetId
      });
      return;
    }
    if (action === "set-session-account" && extra) {
      await chrome.runtime.sendMessage({
        kind: "set_session_account",
        requestId: createRequestId("popup"),
        surface: "popup",
        sessionId: targetId,
        profileId: extra
      });
      return;
    }
    if (action === "confirm-signer-unlock") {
      await chrome.runtime.sendMessage({
        kind: "confirm_signer_unlock",
        requestId: createRequestId("popup"),
        surface: "popup",
        intentId: targetId
      });
      return;
    }
    if (action === "reject-signer-unlock") {
      await chrome.runtime.sendMessage({
        kind: "reject_signer_unlock",
        requestId: createRequestId("popup"),
        surface: "popup",
        intentId: targetId
      });
    }
  }
  function quickAction(icon, label, target) {
    if (target.startsWith("internal:")) {
      return `
      <button class="quick-action" type="button" data-action="open-action-panel" data-id="${escapeHtml(target.replace("internal:", ""))}">
        <span>${icon}</span>
        <span>${escapeHtml(label)}</span>
      </button>
    `;
    }
    return `
    <button class="quick-action" type="button" data-open-url="http://24wallet.ru${target}">
      <span>${icon}</span>
      <span>${escapeHtml(label)}</span>
    </button>
  `;
  }
  function renderActionContent(target) {
    switch (target) {
      case "buy":
        return `
        <div class="form">
          <p class="copy">Buy crypto through approved external on-ramp providers. Acorus does not custody fiat or sell crypto.</p>
          <button class="primary-button" type="button" data-open-url="http://24wallet.ru/buy">Open Buy</button>
        </div>
      `;
      case "swap":
        return `
        <div class="form">
          <p class="copy">Swap quotes route through the Acorus swap shell. Execution is enabled only where the adapter is safety-reviewed.</p>
          <button class="primary-button" type="button" data-open-url="http://24wallet.ru/swap">Open Swap</button>
        </div>
      `;
      case "send":
        return `
        <div class="form">
          <input class="field" placeholder="Recipient address">
          <input class="field" placeholder="Amount">
          <p class="copy">EVM send can execute after review. Non-EVM send remains disabled until adapter execution is reviewed.</p>
          <button class="primary-button" type="button" data-open-url="http://24wallet.ru/send">Review Send</button>
        </div>
      `;
      case "receive":
      default:
        return renderReceiveComposer(currentPopupState, currentHomeSnapshot);
    }
  }
  function actionButton(action, id, label, primary, danger = false) {
    const className = danger ? "danger-button" : primary ? "primary-button" : "ghost-button";
    return `<button data-action="${action}" data-id="${escapeHtml(id)}" class="${className}" type="button">${escapeHtml(label)}</button>`;
  }
  function chainName(chainId) {
    switch (Number(chainId)) {
      case 1:
        return "Ethereum";
      case 56:
        return "BNB Chain";
      case 137:
        return "Polygon";
      case 8453:
        return "Base";
      case 42161:
        return "Arbitrum";
      case 101:
        return "Solana";
      default:
        return chainId ? `Chain ${chainId}` : "Multichain";
    }
  }
  function shortAddress(value) {
    if (!value || value === "No synced account") {
      return value;
    }
    if (value.length <= 14) {
      return value;
    }
    return `${value.slice(0, 6)}...${value.slice(-4)}`;
  }
  function formatFiat(value) {
    return typeof value === "number" && Number.isFinite(value) ? `${value.toFixed(2)} $` : "\u2014";
  }
  function getRoot(message) {
    const element = document.getElementById("app");
    if (!element) {
      throw new Error(message);
    }
    return element;
  }
  function escapeHtml(value) {
    return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }
})();
