"use strict";
(() => {
  // ../../packages/shared/src/chains.ts
  var DEFAULT_SOLANA_CHAIN_ID = 101;
  var DEFAULT_TRON_CHAIN_ID = "tron-mainnet";
  var DEFAULT_BITCOIN_CHAIN_ID = "bitcoin-mainnet";
  var DEFAULT_TON_CHAIN_ID = "ton-mainnet";
  var EVM_CHAINS = [
    {
      chainId: 1,
      family: "evm",
      name: "Ethereum",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ETH_RPC_URL",
      blockExplorerUrl: "https://etherscan.io"
    },
    {
      chainId: 56,
      family: "evm",
      name: "BNB Smart Chain",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_BSC_RPC_URL",
      blockExplorerUrl: "https://bscscan.com"
    },
    {
      chainId: 137,
      family: "evm",
      name: "Polygon",
      nativeSymbol: "MATIC",
      rpcUrlEnv: "NEXT_PUBLIC_POLYGON_RPC_URL",
      blockExplorerUrl: "https://polygonscan.com"
    },
    {
      chainId: 42161,
      family: "evm",
      name: "Arbitrum One",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ARBITRUM_RPC_URL",
      blockExplorerUrl: "https://arbiscan.io"
    },
    {
      chainId: 10,
      family: "evm",
      name: "Optimism",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_OPTIMISM_RPC_URL",
      blockExplorerUrl: "https://optimistic.etherscan.io"
    },
    {
      chainId: 8453,
      family: "evm",
      name: "Base",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_BASE_RPC_URL",
      blockExplorerUrl: "https://basescan.org"
    },
    {
      chainId: 43114,
      family: "evm",
      name: "Avalanche",
      nativeSymbol: "AVAX",
      rpcUrlEnv: "NEXT_PUBLIC_AVALANCHE_RPC_URL",
      blockExplorerUrl: "https://snowtrace.io"
    },
    {
      chainId: 59144,
      family: "evm",
      name: "Linea",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_LINEA_RPC_URL",
      blockExplorerUrl: "https://lineascan.build"
    },
    {
      chainId: 250,
      family: "evm",
      name: "Fantom",
      nativeSymbol: "FTM",
      rpcUrlEnv: "NEXT_PUBLIC_FANTOM_RPC_URL",
      blockExplorerUrl: "https://ftmscan.com"
    },
    {
      chainId: 1329,
      family: "evm",
      name: "Sei",
      nativeSymbol: "SEI",
      rpcUrlEnv: "NEXT_PUBLIC_SEI_RPC_URL",
      blockExplorerUrl: "https://seitrace.com"
    },
    {
      chainId: 204,
      family: "evm",
      name: "opBNB",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_OPBNB_RPC_URL",
      blockExplorerUrl: "https://opbnbscan.com"
    },
    {
      chainId: 324,
      family: "evm",
      name: "zkSync Era",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ZKSYNC_RPC_URL",
      blockExplorerUrl: "https://era.zksync.network"
    }
  ];
  var SOLANA_MAINNET_CHAIN = {
    chainId: DEFAULT_SOLANA_CHAIN_ID,
    family: "solana",
    name: "Solana",
    network: "mainnet-beta",
    nativeSymbol: "SOL",
    rpcUrlEnv: "NEXT_PUBLIC_SOLANA_RPC_URL",
    blockExplorerUrl: "https://solscan.io"
  };
  var TRON_MAINNET_CHAIN = {
    family: "tron",
    chainId: DEFAULT_TRON_CHAIN_ID,
    name: "Tron",
    nativeSymbol: "TRX",
    rpcUrlEnv: "NEXT_PUBLIC_TRON_RPC_URL",
    blockExplorerUrl: "https://tronscan.org/#",
    isEnabled: false,
    isSkeleton: true
  };
  var BITCOIN_MAINNET_CHAIN = {
    family: "utxo",
    chainId: DEFAULT_BITCOIN_CHAIN_ID,
    name: "Bitcoin",
    nativeSymbol: "BTC",
    rpcUrlEnv: "NEXT_PUBLIC_BITCOIN_RPC_URL",
    blockExplorerUrl: "https://mempool.space",
    isEnabled: false,
    isSkeleton: true
  };
  var TON_MAINNET_CHAIN = {
    family: "ton",
    chainId: DEFAULT_TON_CHAIN_ID,
    name: "TON",
    nativeSymbol: "TON",
    rpcUrlEnv: "NEXT_PUBLIC_TON_RPC_URL",
    blockExplorerUrl: "https://tonscan.org",
    isEnabled: false,
    isSkeleton: true
  };
  var UNIVERSAL_CHAINS = [
    ...EVM_CHAINS.map((chain) => ({
      family: "evm",
      chainId: chain.chainId,
      name: chain.name,
      nativeSymbol: chain.nativeSymbol,
      rpcUrlEnv: chain.rpcUrlEnv,
      blockExplorerUrl: chain.blockExplorerUrl,
      isEnabled: true
    })),
    {
      family: SOLANA_MAINNET_CHAIN.family,
      chainId: SOLANA_MAINNET_CHAIN.chainId,
      name: SOLANA_MAINNET_CHAIN.name,
      nativeSymbol: SOLANA_MAINNET_CHAIN.nativeSymbol,
      rpcUrlEnv: SOLANA_MAINNET_CHAIN.rpcUrlEnv,
      blockExplorerUrl: SOLANA_MAINNET_CHAIN.blockExplorerUrl,
      network: SOLANA_MAINNET_CHAIN.network,
      isEnabled: true
    },
    TRON_MAINNET_CHAIN,
    BITCOIN_MAINNET_CHAIN,
    TON_MAINNET_CHAIN
  ];

  // ../../packages/shared/src/dapp.ts
  function getDappRequestKindLabel(kind) {
    switch (kind) {
      case "connect":
        return "Connect";
      case "add_chain":
        return "Add network";
      case "watch_asset":
        return "Watch asset";
      case "multichain_send":
        return "Send";
      case "swap":
        return "Swap";
      case "sign_message":
        return "Sign message";
      case "sign_typed_data":
        return "Sign typed data";
      case "sign_transaction":
        return "Sign transaction";
      case "send_transaction":
        return "Send transaction";
      default:
        return kind;
    }
  }
  function getDappConnectionTransportLabel(transport) {
    switch (transport) {
      case "walletconnect":
        return "WalletConnect";
      case "injected":
      default:
        return "Injected";
    }
  }

  // ../../packages/shared/src/evm-swap.ts
  function formatEvmTokenAmount(raw, decimals) {
    if (!/^[0-9]+$/u.test(raw)) {
      throw new Error("Invalid raw amount.");
    }
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > 30) {
      throw new Error("Invalid token decimals.");
    }
    const value = BigInt(raw);
    const base = 10n ** BigInt(decimals);
    const whole = value / base;
    const fraction = value % base;
    const fractionText = fraction.toString().padStart(decimals, "0").replace(/0+$/u, "");
    return fractionText ? `${whole.toString()}.${fractionText}` : whole.toString();
  }
  function shortenFormattedEvmTokenAmount(raw, decimals, maxFractionDigits = 6) {
    const formatted = formatEvmTokenAmount(raw, decimals);
    const [wholePart = "0", fractionPart] = formatted.split(".");
    if (!fractionPart || maxFractionDigits < 0) {
      return formatted;
    }
    const trimmedFraction = fractionPart.slice(0, maxFractionDigits).replace(/0+$/u, "");
    return trimmedFraction ? `${wholePart}.${trimmedFraction}` : wholePart;
  }

  // src/shared/protocol.ts
  var ACORUS_PROVIDER_METHODS = [
    "acorus_ping",
    "acorus_getVaultStatus",
    "acorus_createWallet",
    "acorus_importWallet",
    "acorus_unlockWallet",
    "acorus_lockWallet",
    "acorus_receiveAddress",
    "acorus_requestAccounts",
    "acorus_accounts",
    "acorus_chainId",
    "acorus_switchChain",
    "acorus_getPermissions",
    "acorus_requestPermissions",
    "acorus_revokePermissions",
    "acorus_addChain",
    "acorus_watchAsset",
    "acorus_multichainSend",
    "acorus_swap",
    "acorus_signMessage",
    "acorus_signTypedData",
    "acorus_signTransaction",
    "acorus_sendTransaction"
  ];
  function createRequestId(prefix = "acorus") {
    if (globalThis.crypto?.randomUUID) {
      return `${prefix}_${globalThis.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }
  function createSkeletonState(input) {
    return {
      phase: "permission_shell",
      providerInjection: input?.providerInjection ?? "stub_only",
      executionEnabled: input?.executionEnabled ?? true,
      proposals: input?.proposals ?? [],
      sessions: input?.sessions ?? [],
      pendingRequests: input?.pendingRequests ?? [],
      approvalResults: input?.approvalResults ?? [],
      activityLog: input?.activityLog ?? [],
      signerUnlockQueue: input?.signerUnlockQueue ?? [],
      activeOriginBridge: input?.activeOriginBridge ?? null,
      walletExposureMode: input?.walletExposureMode ?? "preview_accounts",
      walletExposedAccounts: input?.walletExposedAccounts ?? [],
      walletLastSyncedAt: input?.walletLastSyncedAt ?? null,
      extensionVaultStatus: input?.extensionVaultStatus ?? {
        hasVault: false,
        isUnlocked: false,
        activeProfileId: null,
        profiles: [],
        unlockedAt: null,
        createdAt: null,
        updatedAt: null
      },
      supportedMethods: ACORUS_PROVIDER_METHODS,
      lastUpdatedAt: input?.lastUpdatedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
      activeOrigin: input?.activeOrigin ?? null
    };
  }

  // src/popup/index.ts
  var root = getRoot("Popup root not found.");
  var EXTENSION_SWAP_API_BASES = ["https://24wallet.ru", "http://85.239.59.199:8080"];
  var POPUP_RANDOM_PASSCODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";
  var lastCreatedMnemonic = null;
  var currentPopupState = createSkeletonState();
  var currentHomeSnapshot = null;
  void loadPopupState();
  async function loadPopupState() {
    let state = createSkeletonState();
    let home = null;
    try {
      const [stateResponse, homeResponse] = await Promise.all([
        chrome.runtime.sendMessage({
          kind: "get_state",
          requestId: createRequestId("popup"),
          surface: "popup",
          origin: null
        }),
        loadExtensionHome()
      ]);
      if (stateResponse.ok && stateResponse.result) {
        state = stateResponse.result;
      }
      home = homeResponse;
    } catch {
      state = createSkeletonState();
      home = null;
    }
    currentPopupState = state;
    currentHomeSnapshot = home;
    root.innerHTML = renderPopup(state, home);
    wirePopupActions();
  }
  async function loadExtensionHome() {
    try {
      const response = await chrome.runtime.sendMessage({
        kind: "get_extension_home",
        requestId: createRequestId("popup_home"),
        surface: "popup"
      });
      return response.ok && response.result ? response.result : null;
    } catch {
      return null;
    }
  }
  function renderPopup(state, home) {
    const vault = state.extensionVaultStatus;
    const selectedProfile = state.walletExposedAccounts.find((profile) => profile.selected) ?? vault.profiles.find((profile) => profile.selected) ?? vault.profiles[0] ?? state.walletExposedAccounts[0] ?? null;
    const activeChain = home?.activeChainId ?? selectedProfile?.chainIds[0] ?? state.activeOriginBridge?.activeChainId ?? 1;
    const activeNetwork = home?.networks.find((network) => String(network.chainId) === String(activeChain));
    const pendingCount = state.proposals.length + state.pendingRequests.length + state.signerUnlockQueue.length;
    return `
    <main class="wallet-shell">
      <header class="wallet-header">
        <div class="brand">
          <div class="brand-mark">A</div>
          <div>
            <div class="brand-title">Acorus</div>
            <div class="brand-subtitle">${escapeHtml(selectedProfile?.name ?? "Multichain wallet")}</div>
          </div>
        </div>
        <div class="row">
          <span class="network-pill">${escapeHtml(String(activeChain) === "all" ? "All networks" : activeNetwork?.name ?? chainName(activeChain))}</span>
          <span class="status-pill ${vault.isUnlocked ? "ok" : "locked"}">${vault.isUnlocked ? "Unlocked" : "Locked"}</span>
          <button class="icon-button" type="button" data-action="open-action-panel" data-id="settings" title="Settings">\u2699</button>
        </div>
      </header>

      <div class="main">
        ${pendingCount > 0 ? renderPromptNotice(state) : ""}
        ${lastCreatedMnemonic ? renderSeedReveal(lastCreatedMnemonic) : ""}
        ${vault.hasVault ? renderWalletHome(state, selectedProfile, home) : renderOnboarding()}
        ${renderConnectedSites(state)}
        ${renderRecentActivity(state)}
      </div>
    </main>
  `;
  }
  function renderWalletHome(state, selectedProfile, home) {
    const vault = state.extensionVaultStatus;
    const account = selectedProfile?.account ?? "No synced account";
    const unlockedLabel = vault.isUnlocked ? "Unlocked" : "Locked";
    const activeNetwork = home?.networks.find(
      (item) => String(item.chainId) === String(home.activeChainId)
    ) ?? home?.networks[0] ?? null;
    const visibleAssets = home?.assets.filter(
      (asset) => !activeNetwork || String(home?.activeChainId) === "all" || String(asset.chainId) === String(activeNetwork.chainId)
    ).slice(0, 30) ?? [];
    return `
    <section class="account-card">
      <div class="account-row">
        <div>
          <button class="account-name as-button" type="button" data-action="open-account-panel" data-id="account">
            ${escapeHtml(selectedProfile?.name ?? "Main wallet")} \u25BE
          </button>
          <button class="address-pill as-button" type="button" data-copy="${escapeHtml(account)}">
            ${shortAddress(account)} <span>\u29C9</span>
          </button>
        </div>
        <button class="network-pill as-button" type="button" data-action="open-network-panel" data-id="network">
          ${escapeHtml(String(home?.activeChainId) === "all" ? "All networks" : activeNetwork?.name ?? "All networks")} \u25BE
        </button>
      </div>

      <div class="balance">${formatFiat(home?.totalFiatValue)}</div>
      <div class="balance-sub">${unlockedLabel} \xB7 ${state.walletExposureMode === "wallet_backed" ? "Multichain vault active" : "Preview bridge mode"}</div>

      <div class="hero-actions">
        <button class="hero-action" type="button" data-action="open-action-panel" data-id="send">
          <span>\u2197</span>
          <strong>Send</strong>
        </button>
        <button class="hero-action" type="button" data-action="open-action-panel" data-id="receive">
          <span>\u2199</span>
          <strong>Receive</strong>
        </button>
      </div>
      <button class="portfolio-button" type="button" data-open-url="https://24wallet.ru/wallet">
        View portfolio <span>\u2192</span>
      </button>
      <div class="mini-actions">
        ${quickAction("\uFF0B", "Buy", "internal:buy")}
        ${quickAction("\u21C4", "Swap", "internal:swap")}
      </div>
    </section>

    ${renderAccountPanel(state, selectedProfile)}
    ${renderNetworkPanel(home)}
    ${renderExtensionActionPanel(state, home)}

    <section class="panel stack">
      <div class="tabs">
        <span class="tab" data-active="true">Tokens</span>
        <span class="tab">Activity</span>
        <span class="tab">dApps</span>
        <span class="tab">NFT</span>
      </div>
      <div class="row">
        <span class="network-pill">All popular networks</span>
        <span class="small">${home?.assets.length ?? 0} assets</span>
      </div>
      <div class="token-list">
        ${visibleAssets.length ? visibleAssets.map(renderAssetRow).join("") : `<p class="copy">No live assets yet. Add a token or switch network.</p>`}
      </div>
      ${home?.warnings.length ? renderWarnings(home.warnings) : ""}
      <div class="row">
        ${vault.isUnlocked ? `<button class="ghost-button" type="button" data-action="lock-extension-wallet" data-id="vault">Lock wallet</button>` : `<form id="unlock-wallet-form" class="form" style="flex:1">
                <input class="field" name="passcode" placeholder="Passcode" type="password" autocomplete="current-password">
                <button class="primary-button" type="submit">Unlock</button>
                <button class="danger-button" type="button" data-action="reset-extension-wallet" data-id="extension-vault">
                  Reset local wallet
                </button>
              </form>`}
        <button class="ghost-button" type="button" data-open-url="https://24wallet.ru/extension">Open site</button>
      </div>
    </section>
  `;
  }
  function renderAccountPanel(state, selectedProfile) {
    const profiles = state.extensionVaultStatus.profiles.length ? state.extensionVaultStatus.profiles : state.walletExposedAccounts;
    const familyLabels = [
      { family: "evm", label: "EVM Account" },
      { family: "solana", label: "Solana Account" },
      { family: "tron", label: "Tron Account" }
    ];
    return `
    <section class="panel stack" id="account-panel" hidden>
      <div class="row">
        <h2 class="section-title">Accounts</h2>
        <span class="small">${state.extensionVaultStatus.isUnlocked ? "unlocked" : "locked"}</span>
      </div>
      ${familyLabels.map(({ family, label }) => {
      const profile = profiles.find((item) => item.chainFamily === family);
      if (!profile) {
        return renderComingSoonAccount(label);
      }
      return `
          <button class="account-option ${profile.profileId === selectedProfile?.profileId ? "active" : ""}"
                  type="button"
                  data-action="select-wallet-profile"
                  data-id="${escapeHtml(profile.profileId)}">
            <span>
              <strong>${escapeHtml(label)}</strong>
              <small>${escapeHtml(profile.name)} \xB7 ${shortAddress(profile.account)}</small>
            </span>
            <span class="badge">${escapeHtml(profile.chainFamily.toUpperCase())}</span>
          </button>
        `;
    }).join("")}
      ${renderComingSoonAccount("BTC Coming soon")}
      ${renderComingSoonAccount("TON Coming soon")}
    </section>
  `;
  }
  function renderComingSoonAccount(label) {
    return `
    <div class="account-option disabled">
      <span>
        <strong>${escapeHtml(label)}</strong>
        <small>Profile derivation is not enabled yet</small>
      </span>
      <span class="badge muted-badge">Soon</span>
    </div>
  `;
  }
  function renderAssetRow(asset) {
    const assetId = [
      asset.family,
      String(asset.chainId),
      asset.type,
      asset.tokenAddress?.toLowerCase() ?? "native",
      asset.symbol.toUpperCase()
    ].join(":");
    const icon = asset.logoUrl ? `<img src="${escapeHtml(asset.logoUrl)}" alt="" loading="lazy">` : escapeHtml(asset.symbol.slice(0, 4).toUpperCase());
    const balanceText = `${asset.balanceFormatted ?? "0"} ${asset.symbol}`;
    const chainLabel = asset.family === "evm" ? `Chain ${String(asset.chainId)}` : asset.family.toUpperCase();
    return `
    <button class="token-row as-button wide" type="button" data-asset-id="${escapeHtml(assetId)}">
      <div class="token-icon">${icon}</div>
      <div>
        <div class="token-name">${escapeHtml(asset.name)}</div>
        <div class="token-meta">${escapeHtml(chainLabel)} \xB7 ${escapeHtml(balanceText)}</div>
      </div>
      <div class="token-value">${formatFiat(asset.fiatValue)}</div>
    </button>
  `;
  }
  function renderNetworkPanel(home) {
    if (!home) {
      return "";
    }
    return `
    <section class="panel stack" id="network-panel" hidden>
      <div class="row">
        <h2 class="section-title">Networks</h2>
        <input class="field compact" id="network-search" placeholder="Search">
      </div>
      ${renderNetworkGroup("All", [
      {
        id: "all",
        family: "all",
        chainId: "all",
        name: "All networks",
        nativeSymbol: "ALL",
        iconSymbol: "ALL",
        accent: "#111827",
        capabilities: { receive: true, balance: true, send: false, swap: false, dapp: false }
      }
    ], home.activeChainId)}
      <div class="network-grid">
        ${["evm", "solana", "tron", "coming"].map(
      (group) => renderNetworkGroup(
        getNetworkGroupLabel(group),
        getNetworksForGroup(home.networks, group),
        home.activeChainId
      )
    ).join("")}
      </div>
    </section>
  `;
  }
  function renderNetworkGroup(label, networks, activeChainId) {
    if (!networks.length) {
      return "";
    }
    return `
    <div class="network-group" data-network-group="${escapeHtml(label.toLowerCase())}">
      <div class="network-group-label">${escapeHtml(label)}</div>
      ${networks.map((network) => renderNetworkCard(network, activeChainId)).join("")}
    </div>
  `;
  }
  function renderNetworkCard(network, activeChainId) {
    const capabilityBadges = Object.entries(network.capabilities).map(([name, enabled]) => `<span class="capability-badge ${enabled ? "on" : "off"}">${escapeHtml(name)}</span>`).join("");
    const chainId = String(network.chainId);
    return `
    <button class="network-card ${chainId === String(activeChainId) ? "active" : ""}"
            type="button"
            data-action="set-active-chain"
            data-id="${escapeHtml(chainId)}"
            data-network-name="${escapeHtml(`${network.name} ${network.nativeSymbol} ${network.family}`.toLowerCase())}">
      <span class="network-dot" style="background:${escapeHtml(network.accent)}"></span>
      <span>
        <strong>${escapeHtml(network.name)}</strong>
        <small>${escapeHtml(network.family.toUpperCase())}</small>
        <span class="capability-row">${capabilityBadges}</span>
      </span>
    </button>
  `;
  }
  function getNetworksForGroup(networks, group) {
    if (group === "coming") {
      return networks.filter((network) => network.family === "utxo" || network.family === "ton");
    }
    return networks.filter((network) => network.family === group);
  }
  function getNetworkGroupLabel(group) {
    switch (group) {
      case "evm":
        return "EVM";
      case "solana":
        return "Solana";
      case "tron":
        return "Tron";
      default:
        return "Coming soon";
    }
  }
  function renderExtensionActionPanel(state, home) {
    return `
    <section class="panel stack" id="action-panel" hidden>
      <div class="row">
        <h2 class="section-title" id="action-title">Action</h2>
        <button class="icon-button" type="button" data-action="close-action-panel" data-id="action">\xD7</button>
      </div>
      <div id="action-content">
        ${renderReceiveComposer(state, home)}
      </div>
    </section>
  `;
  }
  function renderReceiveComposer(state, home) {
    const vault = state.extensionVaultStatus;
    const profiles = vault.profiles.length ? vault.profiles : state.walletExposedAccounts;
    const networks = home?.networks ?? [];
    const selectedNetwork = networks.find(
      (network) => String(network.chainId) === String(home?.activeChainId)
    ) ?? networks[0] ?? null;
    const selectedFamily = selectedNetwork?.family ?? "evm";
    return `
    <div class="form">
      <label class="small">Network</label>
      <select class="field" id="receive-network">
        ${networks.map((network) => `
          <option value="${escapeHtml(String(network.chainId))}" data-family="${escapeHtml(network.family)}" ${String(network.chainId) === String(selectedNetwork?.chainId) ? "selected" : ""}>
            ${escapeHtml(network.name)}
          </option>
        `).join("")}
      </select>
      <div class="receive-box">
        ${renderReceiveAddressRows(profiles, selectedFamily)}
      </div>
      <p class="copy" id="receive-warning">${escapeHtml(buildReceiveWarning(selectedNetwork))}</p>
    </div>
  `;
  }
  function renderReceiveAddressRows(profiles, family) {
    if (family === "utxo" || family === "ton") {
      return `
      <div class="site-row" data-receive-family="${escapeHtml(family)}">
        <div>
          <div class="token-name">${family.toUpperCase()} receive</div>
          <div class="token-meta">Coming soon</div>
        </div>
      </div>
    `;
    }
    const matching = profiles.filter((profile) => profile.chainFamily === family);
    if (!matching.length) {
      return `
      <div class="site-row" data-receive-family="${escapeHtml(family)}">
        <div>
          <div class="token-name">${escapeHtml(family.toUpperCase())} address</div>
          <div class="token-meta">Coming soon</div>
        </div>
      </div>
    `;
    }
    return matching.map((profile) => `
    <div class="site-row" data-receive-family="${escapeHtml(profile.chainFamily)}">
      <div>
        <div class="token-name">${escapeHtml(profile.name)}</div>
        <div class="token-meta">${escapeHtml(profile.chainFamily)} \xB7 ${shortAddress(profile.account)}</div>
      </div>
      <button class="ghost-button" type="button" data-copy="${escapeHtml(profile.account)}">Copy</button>
    </div>
  `).join("");
  }
  function buildReceiveWarning(network) {
    if (!network) {
      return "Select a network before copying a receive address.";
    }
    if (network.family === "utxo" || network.family === "ton") {
      return `${network.name} receive is coming soon in this extension build. Do not send funds here yet.`;
    }
    return `Send only ${network.name} assets to this ${network.family.toUpperCase()} address family. Wrong network can permanently lose funds.`;
  }
  function renderWarnings(warnings) {
    return `
    <section class="notice warning">
      <strong>Network notes</strong>
      <ul>
        ${warnings.slice(0, 4).map((warning) => `<li>${escapeHtml(warning)}</li>`).join("")}
      </ul>
    </section>
  `;
  }
  function renderExtensionPasscodeFields(formId) {
    return `
    <section class="passcode-setup-card">
      <div class="row">
        <div>
          <strong>Set wallet password</strong>
          <p class="copy" style="margin-top:4px">Acorus will not create or import a wallet until you choose the password yourself.</p>
        </div>
      </div>
      <div class="passcode-mode-grid" role="radiogroup" aria-label="Password mode">
        <label class="passcode-mode-option">
          <input type="radio" name="passcodeMode" value="pin" checked>
          <span>
            <strong>Numeric PIN</strong>
            <small>6-12 digits</small>
          </span>
        </label>
        <label class="passcode-mode-option">
          <input type="radio" name="passcodeMode" value="random">
          <span>
            <strong>Random</strong>
            <small>12+ symbols</small>
          </span>
        </label>
      </div>
      <div class="form">
        <input class="field" name="passcode" placeholder="Create password" type="password" autocomplete="new-password">
        <input class="field" name="confirmPasscode" placeholder="Repeat password" type="password" autocomplete="new-password">
        <label class="checkbox-row">
          <input name="passcodeSaved" type="checkbox" value="yes">
          <span>I saved this password. It cannot be recovered by Acorus.</span>
        </label>
        <button class="ghost-button" type="button" data-action="generate-extension-passcode" data-id="${escapeHtml(formId)}">
          Generate random password
        </button>
      </div>
    </section>
  `;
  }
  function renderOnboarding() {
    return `
    <section class="onboarding-card stack">
      <div>
        <h1 style="margin:0;font-size:24px;letter-spacing:-0.03em">Create your wallet</h1>
        <p class="copy" style="margin-top:8px">
          Seed phrase and encrypted vault stay inside this Chrome extension.
          Sites connect through the injected provider, like a normal wallet.
        </p>
      </div>
      <section class="notice warning">
        <strong>No automatic passwords</strong><br>
        If this extension locked itself before you chose a password, reset the local extension wallet and import again.
      </section>
      <button class="danger-button" type="button" data-action="reset-extension-wallet" data-id="extension-vault">
        Reset local extension wallet
      </button>
      <form id="create-wallet-form" class="form">
        <input class="field" name="name" placeholder="Wallet name" value="Main wallet">
        ${renderExtensionPasscodeFields("create-wallet-form")}
        <button class="primary-button" type="submit">Create wallet</button>
      </form>
      <details>
        <summary style="cursor:pointer;font-weight:700">Import existing seed phrase</summary>
        <form id="import-wallet-form" class="form" style="margin-top:12px">
          <input class="field" name="name" placeholder="Wallet name" value="Imported wallet">
          <textarea class="field" name="mnemonic" placeholder="Seed phrase" rows="3"></textarea>
          ${renderExtensionPasscodeFields("import-wallet-form")}
          <button class="ghost-button" type="submit">Import wallet</button>
        </form>
      </details>
    </section>
  `;
  }
  function renderPromptNotice(state) {
    const signer = state.signerUnlockQueue[0];
    if (signer) {
      return `
      <section class="notice warning">
        <strong>${escapeHtml(getDappRequestKindLabel(signer.kind))}</strong><br>
        ${escapeHtml(signer.summary)}
        <div class="row" style="margin-top:10px">
          ${actionButton("confirm-signer-unlock", signer.id, "Confirm", true)}
          ${actionButton("reject-signer-unlock", signer.id, "Reject", false, true)}
        </div>
      </section>
    `;
    }
    const request = state.pendingRequests[0];
    if (request) {
      const approveLabel = request.kind === "add_chain" || request.kind === "watch_asset" ? "Confirm" : "Review";
      return `
      <section class="notice warning">
        <strong>${escapeHtml(getDappRequestKindLabel(request.kind))} request</strong><br>
        ${escapeHtml(request.origin.title)} wants approval on ${chainName(request.chainId)}.<br>
        ${renderApprovalDetailCard(request)}
        <div class="row" style="margin-top:10px">
          ${actionButton("approve-request", request.id, approveLabel, true)}
          ${actionButton("reject-request", request.id, "Reject", false, true)}
        </div>
      </section>
    `;
    }
    const proposal = state.proposals[0];
    if (!proposal) {
      return "";
    }
    return `
    <section class="notice warning">
      <strong>Connect request</strong><br>
      ${escapeHtml(proposal.origin.title)} wants to see your selected account.
      <div class="row" style="margin-top:10px">
        ${actionButton("approve-proposal", proposal.id, "Connect", true)}
        ${actionButton("reject-proposal", proposal.id, "Reject", false, true)}
      </div>
    </section>
  `;
  }
  function renderApprovalDetailCard(request) {
    const details = request.reviewDetails;
    if (details?.kind === "add_chain") {
      return `
      <div class="approval-card">
        <div class="row"><strong>Add Network</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Name</dt><dd>${escapeHtml(details.chainName || "Unknown network")}</dd></div>
          <div><dt>Chain ID</dt><dd>${escapeHtml(String(details.chainIdDecimal ?? "n/a"))} / ${escapeHtml(details.chainIdHex || "n/a")}</dd></div>
          <div><dt>RPC</dt><dd>${escapeHtml(details.rpcHostname)}</dd></div>
          <div><dt>Explorer</dt><dd>${escapeHtml(details.explorerHostname)}</dd></div>
          <div><dt>Symbol</dt><dd>${escapeHtml(details.nativeSymbol || "n/a")}</dd></div>
        </dl>
      </div>
    `;
    }
    if (details?.kind === "watch_asset") {
      return `
      <div class="approval-card">
        <div class="row"><strong>Watch Asset</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Symbol</dt><dd>${escapeHtml(details.symbol || "UNKNOWN")}</dd></div>
          <div><dt>Address</dt><dd>${escapeHtml(shortAddress(details.tokenAddress))}</dd></div>
          <div><dt>Decimals</dt><dd>${escapeHtml(String(details.decimals ?? "n/a"))}</dd></div>
          <div><dt>Chain</dt><dd>${escapeHtml(String(details.chainId ?? "n/a"))}</dd></div>
        </dl>
      </div>
    `;
    }
    if (details?.kind === "multichain_send") {
      const ataWarning = details.ataWarning ? `<div><dt>ATA</dt><dd>${escapeHtml(details.ataWarning)}</dd></div>` : "";
      const tokenAddress = details.tokenAddress ? `<div><dt>Mint</dt><dd>${escapeHtml(shortAddress(details.tokenAddress))}</dd></div>` : "";
      const fee = details.estimatedFeeFormatted ? `<div><dt>Estimated fee</dt><dd>${escapeHtml(details.estimatedFeeFormatted)} SOL</dd></div>` : "";
      return `
      <div class="approval-card">
        <div class="row"><strong>Send ${escapeHtml(details.assetSymbol)}</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Network</dt><dd>${escapeHtml(details.family.toUpperCase())} \xB7 ${escapeHtml(String(details.chainId ?? "n/a"))}</dd></div>
          <div><dt>Asset</dt><dd>${escapeHtml(details.assetType ?? "native")} \xB7 ${escapeHtml(details.assetSymbol)}</dd></div>
          ${tokenAddress}
          <div><dt>From</dt><dd>${escapeHtml(shortAddress(details.fromAddress))}</dd></div>
          <div><dt>To</dt><dd>${escapeHtml(shortAddress(details.toAddress))}</dd></div>
          <div><dt>Amount</dt><dd>${escapeHtml(details.amountFormatted)} ${escapeHtml(details.assetSymbol)}</dd></div>
          ${fee}
          ${ataWarning}
        </dl>
      </div>
    `;
    }
    if (details?.kind === "token_approval") {
      return `
      <div class="approval-card">
        <div class="row"><strong>Approve ${escapeHtml(details.tokenSymbol)}</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Network</dt><dd>${escapeHtml(String(details.chainId ?? "n/a"))}</dd></div>
          <div><dt>Token</dt><dd>${escapeHtml(shortAddress(details.tokenAddress))}</dd></div>
          <div><dt>Spender</dt><dd>${escapeHtml(shortAddress(details.spender))}</dd></div>
          <div><dt>Amount</dt><dd>${escapeHtml(details.approvalMode === "infinite" ? "Unlimited" : details.amountFormatted ?? details.amountRaw)}</dd></div>
          ${details.currentAllowanceFormatted ? `<div><dt>Current allowance</dt><dd>${escapeHtml(details.currentAllowanceFormatted)}</dd></div>` : ""}
          ${details.requiredAllowanceFormatted ? `<div><dt>Required allowance</dt><dd>${escapeHtml(details.requiredAllowanceFormatted)}</dd></div>` : ""}
          <div><dt>Mode</dt><dd>${escapeHtml(details.approvalMode)}</dd></div>
        </dl>
      </div>
    `;
    }
    if (details?.kind === "evm_swap") {
      return `
      <div class="approval-card">
        <div class="row"><strong>0x Swap</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Network</dt><dd>${escapeHtml(String(details.chainId ?? "n/a"))}</dd></div>
          <div><dt>Sell</dt><dd>${escapeHtml(details.sellAmountFormatted ?? details.sellAmountRaw)} ${escapeHtml(details.sellTokenSymbol)}</dd></div>
          <div><dt>Buy</dt><dd>${escapeHtml(details.buyAmountFormatted ?? details.buyAmountRaw)} ${escapeHtml(details.buyTokenSymbol)}</dd></div>
          <div><dt>Min received</dt><dd>${escapeHtml(details.minBuyAmountFormatted ?? details.minBuyAmountRaw ?? "n/a")}</dd></div>
          <div><dt>Route</dt><dd>${escapeHtml(details.routeLabel)}</dd></div>
          <div><dt>Contract</dt><dd>${escapeHtml(shortAddress(details.contractAddress))}</dd></div>
          <div><dt>Value</dt><dd>${escapeHtml(details.value)}</dd></div>
          ${details.expiresAt ? `<div><dt>Expires</dt><dd>${escapeHtml(new Date(details.expiresAt).toLocaleTimeString())}</dd></div>` : ""}
        </dl>
      </div>
    `;
    }
    if (details?.kind === "universal_swap") {
      return `
      <div class="approval-card">
        <div class="row"><strong>${escapeHtml(details.provider)} Swap Route</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Network</dt><dd>${escapeHtml(String(details.chainId ?? "multi"))}</dd></div>
          <div><dt>Sell</dt><dd>${escapeHtml(details.sellAmountFormatted ?? details.sellAmountRaw)} ${escapeHtml(details.fromLabel)}</dd></div>
          <div><dt>Buy</dt><dd>${escapeHtml(details.buyAmountFormatted ?? details.buyAmountRaw ?? "route estimate")} ${escapeHtml(details.toLabel)}</dd></div>
          <div><dt>Route</dt><dd>${escapeHtml(details.routeLabel)}</dd></div>
          <div><dt>Execution</dt><dd>${escapeHtml(details.executionStatus === "review_only" ? "Review only" : "Disabled")}</dd></div>
          ${details.slippageBps !== null && details.slippageBps !== void 0 ? `<div><dt>Slippage</dt><dd>${escapeHtml(String(details.slippageBps / 100))}%</dd></div>` : ""}
          ${details.expiresAt ? `<div><dt>Expires</dt><dd>${escapeHtml(new Date(details.expiresAt).toLocaleTimeString())}</dd></div>` : ""}
        </dl>
      </div>
    `;
    }
    return `<span>${escapeHtml(request.summary)}</span>`;
  }
  function renderRiskLabels(labels) {
    return `<span class="risk-labels">${labels.map((label) => `<span>${escapeHtml(label)}</span>`).join("")}</span>`;
  }
  function renderSeedReveal(mnemonic) {
    return `
    <section class="notice warning">
      <strong>Save these words offline now.</strong>
      <div class="seed-grid" style="margin-top:10px">
        ${mnemonic.split(" ").map((word, index) => `<div class="seed-word"><span class="muted">${index + 1}.</span> ${escapeHtml(word)}</div>`).join("")}
      </div>
      <button class="ghost-button" data-action="clear-created-seed" data-id="seed" style="margin-top:10px" type="button">I saved it</button>
    </section>
  `;
  }
  function renderConnectedSites(state) {
    const activeSessions = state.sessions.filter((session) => session.status === "active");
    if (!activeSessions.length && !state.proposals.length) {
      return `
      <section class="panel">
        <h2 class="section-title">Connected sites</h2>
        <p class="copy">No dApps connected yet. Open Acorus or another dApp and connect through the extension.</p>
      </section>
    `;
    }
    return `
    <section class="panel stack">
      <h2 class="section-title">Connected sites</h2>
      ${activeSessions.slice(0, 3).map((session) => `
          <div class="site-row">
            <div>
              <div class="token-name">${escapeHtml(session.origin.title)}</div>
              <div class="token-meta">${escapeHtml(getDappConnectionTransportLabel(session.transport))} \xB7 ${escapeHtml(String(session.activeChainId ?? "multi"))}</div>
            </div>
            ${actionButton("revoke-session", session.id, "Disconnect", false, true)}
          </div>
        `).join("")}
    </section>
  `;
  }
  function renderRecentActivity(state) {
    const latest = state.activityLog.slice(0, 4);
    return `
    <section class="panel stack">
      <h2 class="section-title">Recent activity</h2>
      ${latest.length ? latest.map((item) => `
          <div class="site-row">
            <div>
              <div class="token-name">${escapeHtml(item.kind.replace(/_/gu, " "))}</div>
              <div class="token-meta">${escapeHtml((item.amountFormatted ?? `${item.sellTokenSymbol ?? item.tokenSymbol ?? ""}${item.buyAmountFormatted ? ` -> ${item.buyAmountFormatted} ${item.buyTokenSymbol ?? ""}` : ""}`.trim()) || item.account)}</div>
            </div>
            <span class="badge">${escapeHtml(item.status)}</span>
          </div>
        `).join("") : `<p class="copy">No recent wallet activity yet.</p>`}
      <button class="portfolio-button compact-portfolio" type="button" data-action="open-action-panel" data-id="activity">
        View all activity <span>\u2192</span>
      </button>
    </section>
  `;
  }
  function openActionPanel(targetId) {
    const panel = root.querySelector("#action-panel");
    const title = root.querySelector("#action-title");
    const content = root.querySelector("#action-content");
    if (!panel || !title || !content) {
      return;
    }
    panel.hidden = false;
    title.textContent = `${targetId[0]?.toUpperCase() ?? ""}${targetId.slice(1)}`;
    content.innerHTML = renderActionContent(targetId);
    wireInlineButtons(content);
    wireReceiveNetworkSelector(content);
    wireSendForm(content);
    wireEvmSwapForm(content);
  }
  function wirePopupActions() {
    wireWalletForms();
    wireReceiveNetworkSelector();
    wireNetworkSearch();
    const buttons = root.querySelectorAll("[data-action], [data-open-url], [data-copy]");
    buttons.forEach((button) => {
      button.addEventListener("click", async () => {
        const copyValue = button.dataset.copy;
        if (copyValue) {
          await navigator.clipboard.writeText(copyValue);
          return;
        }
        const openUrl = button.dataset.openUrl;
        if (openUrl) {
          await chrome.tabs.create({ url: openUrl.startsWith("http") ? openUrl : chrome.runtime.getURL(openUrl) });
          return;
        }
        const action = button.dataset.action;
        const targetId = button.dataset.id;
        const extra = button.dataset.extra;
        if (action === "open-network-panel") {
          root.querySelector("#network-panel")?.toggleAttribute("hidden");
          return;
        }
        if (action === "open-account-panel") {
          root.querySelector("#account-panel")?.toggleAttribute("hidden");
          return;
        }
        if (action === "set-active-chain" && targetId) {
          await chrome.runtime.sendMessage({
            kind: "set_active_extension_chain",
            requestId: createRequestId("popup"),
            surface: "popup",
            chainId: /^\d+$/u.test(targetId) ? Number(targetId) : targetId
          });
          await loadPopupState();
          return;
        }
        if (action === "open-action-panel" && targetId) {
          openActionPanel(targetId);
          return;
        }
        if (action === "close-action-panel") {
          const panel = root.querySelector("#action-panel");
          if (panel) {
            panel.hidden = true;
          }
          return;
        }
        if (action === "clear-created-seed") {
          lastCreatedMnemonic = null;
          await loadPopupState();
          return;
        }
        if (action === "lock-extension-wallet") {
          await chrome.runtime.sendMessage({
            kind: "lock_extension_wallet",
            requestId: createRequestId("popup"),
            surface: "popup"
          });
          await loadPopupState();
          return;
        }
        if (action === "generate-extension-passcode" && targetId) {
          const form = root.querySelector(`#${CSS.escape(targetId)}`);
          if (form) {
            fillGeneratedPasscode(form);
          }
          return;
        }
        if (action === "reset-extension-wallet") {
          const confirmed = window.confirm(
            "Reset the local extension wallet? This removes the encrypted vault from this browser profile. Your blockchain assets remain on-chain, but you need your seed phrase to restore access."
          );
          if (!confirmed) {
            return;
          }
          await chrome.runtime.sendMessage({
            kind: "reset_extension_wallet",
            requestId: createRequestId("popup"),
            surface: "popup"
          });
          lastCreatedMnemonic = null;
          await loadPopupState();
          return;
        }
        if (!action || !targetId) {
          return;
        }
        button.disabled = true;
        try {
          await sendAction(action, targetId, extra);
        } finally {
          await loadPopupState();
        }
      });
    });
  }
  function wireNetworkSearch(scope = root) {
    scope.querySelector("#network-search")?.addEventListener("input", (event) => {
      const query = event.currentTarget.value.trim().toLowerCase();
      filterNetworkCards(scope, query);
    });
  }
  function filterNetworkCards(scope, query) {
    scope.querySelectorAll(".network-card").forEach((card) => {
      const label = card.dataset.networkName ?? card.textContent?.toLowerCase() ?? "";
      card.hidden = Boolean(query) && !label.includes(query);
    });
  }
  function wireReceiveNetworkSelector(scope = root) {
    scope.querySelector("#receive-network")?.addEventListener("change", (event) => {
      const select = event.currentTarget;
      const selected = select.selectedOptions[0];
      const family = selected?.dataset.family ?? "evm";
      const networks = currentHomeSnapshot?.networks ?? [];
      const network = networks.find((item) => String(item.chainId) === select.value) ?? null;
      const profiles = currentPopupState.extensionVaultStatus.profiles.length ? currentPopupState.extensionVaultStatus.profiles : currentPopupState.walletExposedAccounts;
      const box = scope.querySelector(".receive-box");
      const warning = scope.querySelector("#receive-warning");
      if (box) {
        box.innerHTML = renderReceiveAddressRows(profiles, family);
        wireInlineButtons(box);
      }
      if (warning) {
        warning.textContent = buildReceiveWarning(network);
      }
    });
  }
  function wireSendForm(scope = root) {
    const form = scope.querySelector("#solana-send-form");
    if (!form) {
      return;
    }
    const networkSelect = form.querySelector("#send-network");
    const note = form.querySelector("#send-support-note");
    const button = form.querySelector("button[type='submit']");
    const updateSupport = () => {
      const family = networkSelect?.selectedOptions[0]?.dataset.family ?? "";
      const supported = family === "solana";
      if (note) {
        note.textContent = supported ? "Solana send is live after explicit popup confirmation." : "Send execution for this network is coming soon.";
      }
      if (button) {
        button.disabled = !supported;
      }
    };
    networkSelect?.addEventListener("change", updateSupport);
    updateSupport();
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const assetSelect = form.querySelector("#send-asset");
      const assetOption = assetSelect?.selectedOptions[0] ?? null;
      const response = await chrome.runtime.sendMessage({
        kind: "queue_solana_send",
        requestId: createRequestId("popup_solana_send"),
        surface: "popup",
        toAddress: String(formData.get("toAddress") ?? ""),
        amountFormatted: String(formData.get("amountFormatted") ?? ""),
        assetType: assetOption?.dataset.assetType === "spl" ? "spl" : "native",
        tokenAddress: assetOption?.dataset.tokenAddress || null,
        symbol: assetOption?.dataset.symbol || "SOL",
        decimals: assetOption?.dataset.decimals ? Number(assetOption.dataset.decimals) : 9,
        balanceRaw: assetOption?.dataset.balanceRaw || null
      });
      if (!response.ok) {
        window.alert(response.error?.message ?? "Unable to queue Solana send.");
        return;
      }
      await loadPopupState();
    });
  }
  function wireEvmSwapForm(scope = root) {
    const form = scope.querySelector("#evm-swap-form");
    if (!form) {
      return;
    }
    const chainSelect = form.querySelector("#swap-chain");
    const sellSelect = form.querySelector("#swap-sell-token");
    const buySelect = form.querySelector("#swap-buy-token");
    const result = form.querySelector("#evm-swap-result");
    chainSelect?.addEventListener("change", () => {
      const assets = getEvmSwapAssets(chainSelect.value);
      if (sellSelect) {
        sellSelect.innerHTML = assets.map((asset) => renderSwapAssetOption(asset)).join("");
      }
      if (buySelect) {
        buySelect.innerHTML = assets.map((asset, index) => renderSwapAssetOption(asset, index === Math.min(1, assets.length - 1))).join("");
      }
      if (result) {
        result.innerHTML = "";
      }
    });
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!result || !sellSelect || !buySelect || !chainSelect) {
        return;
      }
      const evmProfile = currentPopupState.extensionVaultStatus.profiles.find((profile) => profile.chainFamily === "evm") ?? currentPopupState.walletExposedAccounts.find((profile) => profile.chainFamily === "evm") ?? null;
      if (!evmProfile) {
        result.innerHTML = `<p class="copy">Create or import an EVM account before swapping.</p>`;
        return;
      }
      const formData = new FormData(form);
      const amountRaw = String(formData.get("amountRaw") ?? "").trim();
      const slippageBps = Number(formData.get("slippageBps") ?? 50);
      result.innerHTML = `<p class="copy">Fetching 0x quote...</p>`;
      try {
        const quote = await fetchEvmSwapQuote({
          chainId: Number(chainSelect.value),
          sellToken: sellSelect.value,
          buyToken: buySelect.value,
          sellAmount: amountRaw,
          taker: evmProfile.account,
          slippageBps
        });
        result.innerHTML = renderEvmSwapQuotePreview(quote, slippageBps);
        wireEvmSwapQuoteButtons(result, quote, slippageBps);
      } catch (error) {
        result.innerHTML = `<p class="copy">${escapeHtml(error instanceof Error ? error.message : "Unable to fetch quote.")}</p>`;
      }
    });
  }
  async function fetchEvmSwapQuote(input) {
    const params = new URLSearchParams({
      chainId: String(input.chainId),
      sellToken: input.sellToken,
      buyToken: input.buyToken,
      sellAmount: input.sellAmount,
      taker: input.taker,
      slippageBps: String(input.slippageBps)
    });
    for (const base of EXTENSION_SWAP_API_BASES) {
      try {
        const response = await fetch(`${base}/api/swap/evm/0x/quote?${params.toString()}`);
        const payload = await response.json().catch(() => null);
        if (response.ok && payload?.provider === "0x") {
          return payload;
        }
        if (payload?.error === "swap_provider_not_configured") {
          throw new Error("0x provider is not configured on the backend yet.");
        }
      } catch (error) {
        if (error instanceof Error && error.message.includes("0x provider")) {
          throw error;
        }
      }
    }
    throw new Error("0x quote API is unavailable.");
  }
  function renderEvmSwapQuotePreview(quote, slippageBps) {
    const sellFormatted = shortenFormattedEvmTokenAmount(
      quote.sellAmountRaw,
      quote.sellToken.decimals
    );
    const buyFormatted = shortenFormattedEvmTokenAmount(
      quote.buyAmountRaw,
      quote.buyToken.decimals
    );
    const minBuyFormatted = quote.minBuyAmountRaw ? shortenFormattedEvmTokenAmount(quote.minBuyAmountRaw, quote.buyToken.decimals) : "n/a";
    const approval = quote.approvalRequired && quote.approval ? `
      <label class="small" style="display:flex;align-items:center;gap:8px">
        <span>Approval mode</span>
        <select id="evm-approval-mode">
          <option value="exact">Exact</option>
          <option value="infinite">Infinite</option>
        </select>
      </label>
      <button class="ghost-button" type="button" id="evm-approve-token">Approve ${escapeHtml(quote.sellToken.symbol)}</button>
    ` : "";
    return `
    <div class="approval-card">
      <div class="row"><strong>0x quote</strong><span class="badge">${escapeHtml(quote.routeSummary.label)}</span></div>
      <dl>
        <div><dt>You pay</dt><dd>${escapeHtml(sellFormatted)} ${escapeHtml(quote.sellToken.symbol)}</dd></div>
        <div><dt>You receive</dt><dd>${escapeHtml(buyFormatted)} ${escapeHtml(quote.buyToken.symbol)}</dd></div>
        <div><dt>Min received</dt><dd>${escapeHtml(minBuyFormatted)} ${escapeHtml(quote.buyToken.symbol)}</dd></div>
        <div><dt>Slippage</dt><dd>${escapeHtml(String(slippageBps / 100))}%</dd></div>
        <div><dt>Gas</dt><dd>${escapeHtml(quote.gas ?? "estimate unavailable")}</dd></div>
        ${quote.approvalRequired && quote.approval ? `<div><dt>Allowance</dt><dd>${escapeHtml(quote.approval.currentAllowanceRaw ? shortenFormattedEvmTokenAmount(quote.approval.currentAllowanceRaw, quote.sellToken.decimals) : "0")} / ${escapeHtml(shortenFormattedEvmTokenAmount(quote.approval.requiredAllowanceRaw ?? quote.sellAmountRaw, quote.sellToken.decimals))} ${escapeHtml(quote.sellToken.symbol)}</dd></div>` : ""}
      </dl>
      ${quote.warnings.length ? `<p class="copy">${quote.warnings.map(escapeHtml).join(" ")}</p>` : ""}
      <div class="row" style="margin-top:10px">
        ${approval}
        <button class="primary-button" type="button" id="evm-review-swap">Review swap</button>
      </div>
    </div>
  `;
  }
  function wireEvmSwapQuoteButtons(scope, quote, slippageBps) {
    scope.querySelector("#evm-approve-token")?.addEventListener("click", async () => {
      if (!quote.approval) {
        return;
      }
      const approvalMode = scope.querySelector("#evm-approval-mode")?.value === "infinite" ? "infinite" : "exact";
      const response = await chrome.runtime.sendMessage({
        kind: "queue_evm_approve_token",
        requestId: createRequestId("popup_evm_approve"),
        surface: "popup",
        chainId: quote.chainId,
        tokenAddress: quote.approval.tokenAddress,
        tokenSymbol: quote.sellToken.symbol,
        tokenDecimals: quote.sellToken.decimals,
        spender: quote.approval.spender,
        amountRaw: quote.approval.requiredAllowanceRaw ?? quote.sellAmountRaw,
        amountFormatted: shortenFormattedEvmTokenAmount(
          quote.approval.requiredAllowanceRaw ?? quote.sellAmountRaw,
          quote.sellToken.decimals
        ),
        currentAllowanceRaw: quote.approval.currentAllowanceRaw ?? null,
        requiredAllowanceRaw: quote.approval.requiredAllowanceRaw ?? quote.sellAmountRaw,
        approvalMode
      });
      if (!response.ok) {
        window.alert(response.error?.message ?? "Unable to queue token approval.");
      } else {
        await loadPopupState();
      }
    });
    scope.querySelector("#evm-review-swap")?.addEventListener("click", async () => {
      const response = await chrome.runtime.sendMessage({
        kind: "queue_evm_swap_approval",
        requestId: createRequestId("popup_evm_swap"),
        surface: "popup",
        quote,
        slippageBps
      });
      if (!response.ok) {
        window.alert(response.error?.message ?? "Unable to queue swap.");
      } else {
        await loadPopupState();
      }
    });
  }
  function wireInlineButtons(scope) {
    scope.querySelectorAll("[data-action], [data-open-url], [data-copy]").forEach((button) => {
      button.addEventListener("click", async () => {
        const copyValue = button.dataset.copy;
        if (copyValue) {
          await navigator.clipboard.writeText(copyValue);
          return;
        }
        const openUrl = button.dataset.openUrl;
        if (openUrl) {
          await chrome.tabs.create({ url: openUrl.startsWith("http") ? openUrl : chrome.runtime.getURL(openUrl) });
          return;
        }
        const action = button.dataset.action;
        const targetId = button.dataset.id;
        if (action === "close-action-panel") {
          const panel = root.querySelector("#action-panel");
          if (panel) {
            panel.hidden = true;
          }
          return;
        }
        if (action === "open-action-panel" && targetId) {
          openActionPanel(targetId);
        }
      });
    });
  }
  function getPopupPasscodeMode(form) {
    const value = new FormData(form).get("passcodeMode");
    return value === "random" ? "random" : "pin";
  }
  function validatePopupPasscode(form) {
    const formData = new FormData(form);
    const mode = getPopupPasscodeMode(form);
    const passcode = String(formData.get("passcode") ?? "").trim();
    const confirmPasscode = String(formData.get("confirmPasscode") ?? "").trim();
    const saved = formData.get("passcodeSaved") === "yes";
    if (mode === "pin" && !/^\d{6,12}$/u.test(passcode)) {
      return "Choose a numeric PIN with 6-12 digits.";
    }
    if (mode === "random" && passcode.length < 12) {
      return "Choose a random password with at least 12 characters.";
    }
    if (passcode !== confirmPasscode) {
      return "Password confirmation does not match.";
    }
    if (!saved) {
      return "Confirm that you saved the password. Acorus cannot recover it.";
    }
    return null;
  }
  function fillGeneratedPasscode(form) {
    const passcode = generatePopupRandomPasscode();
    form.querySelector('input[name="passcodeMode"][value="random"]')?.click();
    const passcodeInput = form.querySelector('input[name="passcode"]');
    const confirmInput = form.querySelector('input[name="confirmPasscode"]');
    const savedInput = form.querySelector('input[name="passcodeSaved"]');
    if (passcodeInput) {
      passcodeInput.type = "text";
      passcodeInput.value = passcode;
    }
    if (confirmInput) {
      confirmInput.type = "text";
      confirmInput.value = passcode;
    }
    if (savedInput) {
      savedInput.checked = false;
    }
  }
  function generatePopupRandomPasscode(length = 18) {
    const bytes = new Uint8Array(length);
    crypto.getRandomValues(bytes);
    return Array.from(
      bytes,
      (byte) => POPUP_RANDOM_PASSCODE_ALPHABET[byte % POPUP_RANDOM_PASSCODE_ALPHABET.length]
    ).join("");
  }
  function wireWalletForms() {
    root.querySelector("#unlock-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const response = await chrome.runtime.sendMessage({
        kind: "unlock_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        passcode: String(formData.get("passcode") ?? "")
      });
      if (!response.ok) {
        window.alert(response.error?.message ?? "Unable to unlock wallet.");
      }
      await loadPopupState();
    });
    root.querySelector("#create-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const passcodeError = validatePopupPasscode(form);
      if (passcodeError) {
        window.alert(passcodeError);
        return;
      }
      const formData = new FormData(form);
      const response = await chrome.runtime.sendMessage({
        kind: "create_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        name: String(formData.get("name") ?? "Main wallet"),
        passcode: String(formData.get("passcode") ?? "").trim()
      });
      if (response.ok && response.result) {
        const result = response.result;
        lastCreatedMnemonic = result.mnemonic ?? null;
      } else {
        lastCreatedMnemonic = null;
        window.alert(response.error?.message ?? "Unable to create wallet.");
      }
      await loadPopupState();
    });
    root.querySelector("#import-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const passcodeError = validatePopupPasscode(form);
      if (passcodeError) {
        window.alert(passcodeError);
        return;
      }
      const formData = new FormData(form);
      const response = await chrome.runtime.sendMessage({
        kind: "import_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        name: String(formData.get("name") ?? "Imported wallet"),
        mnemonic: String(formData.get("mnemonic") ?? ""),
        passcode: String(formData.get("passcode") ?? "").trim()
      });
      if (!response.ok) {
        window.alert(response.error?.message ?? "Unable to import wallet.");
      }
      await loadPopupState();
    });
  }
  async function sendAction(action, targetId, extra) {
    if (action === "approve-proposal") {
      await chrome.runtime.sendMessage({
        kind: "approve_proposal",
        requestId: createRequestId("popup"),
        surface: "popup",
        proposalId: targetId
      });
      return;
    }
    if (action === "reject-proposal") {
      await chrome.runtime.sendMessage({
        kind: "reject_proposal",
        requestId: createRequestId("popup"),
        surface: "popup",
        proposalId: targetId
      });
      return;
    }
    if (action === "approve-request") {
      await chrome.runtime.sendMessage({
        kind: "approve_request",
        requestId: createRequestId("popup"),
        surface: "popup",
        requestIdTarget: targetId
      });
      return;
    }
    if (action === "reject-request") {
      await chrome.runtime.sendMessage({
        kind: "reject_request",
        requestId: createRequestId("popup"),
        surface: "popup",
        requestIdTarget: targetId
      });
      return;
    }
    if (action === "revoke-session") {
      await chrome.runtime.sendMessage({
        kind: "revoke_session",
        requestId: createRequestId("popup"),
        surface: "popup",
        sessionId: targetId
      });
      return;
    }
    if (action === "select-wallet-profile") {
      await chrome.runtime.sendMessage({
        kind: "select_wallet_profile",
        requestId: createRequestId("popup"),
        surface: "popup",
        profileId: targetId
      });
      return;
    }
    if (action === "set-session-account" && extra) {
      await chrome.runtime.sendMessage({
        kind: "set_session_account",
        requestId: createRequestId("popup"),
        surface: "popup",
        sessionId: targetId,
        profileId: extra
      });
      return;
    }
    if (action === "confirm-signer-unlock") {
      await chrome.runtime.sendMessage({
        kind: "confirm_signer_unlock",
        requestId: createRequestId("popup"),
        surface: "popup",
        intentId: targetId
      });
      return;
    }
    if (action === "reject-signer-unlock") {
      await chrome.runtime.sendMessage({
        kind: "reject_signer_unlock",
        requestId: createRequestId("popup"),
        surface: "popup",
        intentId: targetId
      });
    }
  }
  function quickAction(icon, label, target) {
    if (target.startsWith("internal:")) {
      return `
      <button class="quick-action" type="button" data-action="open-action-panel" data-id="${escapeHtml(target.replace("internal:", ""))}">
        <span>${icon}</span>
        <span>${escapeHtml(label)}</span>
      </button>
    `;
    }
    return `
    <button class="quick-action" type="button" data-open-url="https://24wallet.ru${target}">
      <span>${icon}</span>
      <span>${escapeHtml(label)}</span>
    </button>
  `;
  }
  function renderActionContent(target) {
    switch (target) {
      case "buy":
        return `
        <div class="form">
          <p class="copy">Buy crypto through approved external on-ramp providers. Acorus does not custody fiat or sell crypto.</p>
          <button class="primary-button" type="button" data-open-url="https://24wallet.ru/buy">Open Buy</button>
        </div>
      `;
      case "swap":
        return renderEvmSwapComposer();
      case "send":
        return renderSendComposer();
      case "activity":
        return renderActivityComposer(currentPopupState);
      case "settings":
        return renderSettingsComposer();
      case "receive":
      default:
        return renderReceiveComposer(currentPopupState, currentHomeSnapshot);
    }
  }
  function renderActivityComposer(state) {
    const items = state.activityLog.slice(0, 18);
    return `
    <div class="settings-sheet">
      <button class="settings-back as-button" type="button" data-action="close-action-panel" data-id="activity">\u2190 Activity</button>
      <div class="settings-section-label">Recent wallet activity</div>
      ${items.length ? items.map((item) => `
          <div class="settings-row activity-row">
            <span class="settings-icon">${escapeHtml(activityIcon(item.kind))}</span>
            <span>
              <span class="settings-label">${escapeHtml(item.kind.replace(/_/gu, " "))}</span>
              <span class="token-meta">
                ${escapeHtml((item.amountFormatted ?? `${item.sellTokenSymbol ?? item.tokenSymbol ?? ""}${item.buyAmountFormatted ? ` -> ${item.buyAmountFormatted} ${item.buyTokenSymbol ?? ""}` : ""}`.trim()) || item.account)}
              </span>
            </span>
            <span class="badge">${escapeHtml(item.status)}</span>
          </div>
        `).join("") : `<p class="copy">No approvals, sends, swaps, or dApp sessions have been recorded in this extension yet.</p>`}
      <button class="ghost-button" type="button" data-action="close-action-panel" data-id="activity">Back to wallet</button>
    </div>
  `;
  }
  function activityIcon(kind) {
    if (kind.includes("swap")) {
      return "\u21C4";
    }
    if (kind.includes("send")) {
      return "\u2197";
    }
    if (kind.includes("approval")) {
      return "\u2713";
    }
    if (kind.includes("sign")) {
      return "\u270E";
    }
    return "\u2022";
  }
  function renderSettingsComposer() {
    return `
    <div class="settings-sheet">
      <button class="settings-back as-button" type="button" data-action="close-action-panel" data-id="settings">\u2190 Settings</button>
      <div class="settings-section-label">Preferences</div>
      ${renderSettingsRow("\u25D0", "Theme", `<span class="segmented"><span>Auto</span><span>\u263C</span><span>\u263E</span></span>`)}
      ${renderSettingsRow("\u25C9", "Display currency", `<select class="mini-select"><option>USD</option><option>EUR</option><option>RUB</option><option>GBP</option><option>JPY</option></select>`)}
      ${renderSettingsRow("\u6587", "Language", `<select class="mini-select"><option>English</option><option>\u0420\u0443\u0441\u0441\u043A\u0438\u0439</option><option>Deutsch</option><option>Espa\xF1ol</option><option>\u4E2D\u6587</option></select>`)}
      ${renderSettingsRow("\u25AE", "Balances and activity", `<button class="settings-link" type="button" data-action="open-action-panel" data-id="activity">Open \u203A</button>`)}
      <div class="settings-section-label">Security and privacy</div>
      ${renderSettingsRow("\u2301", "Allow analytics", `<span class="toggle on"><span></span></span>`)}
      <div class="settings-section-label">Developer tools</div>
      ${renderSettingsRow("\u25A4", "App data", `<span>\u203A</span>`)}
      ${renderSettingsRow("\u2692", "Testnet mode", `<span class="toggle"><span></span></span>`)}
      <button class="ghost-button" type="button" data-open-url="options.html">Open provider diagnostics</button>
    </div>
  `;
  }
  function renderSettingsRow(icon, label, value) {
    return `
    <div class="settings-row">
      <span class="settings-icon">${icon}</span>
      <span class="settings-label">${escapeHtml(label)}</span>
      <span class="settings-value">${value}</span>
    </div>
  `;
  }
  function renderSendComposer() {
    const networks = currentHomeSnapshot?.networks ?? [];
    const solana = networks.find((network) => network.family === "solana");
    const solanaAssets = getSolanaSendAssets();
    return `
    <form class="form" id="solana-send-form">
      <label class="small">Network</label>
      <select class="field" id="send-network" name="chainId">
        ${networks.filter((network) => network.family !== "utxo" && network.family !== "ton").map((network) => `
            <option value="${escapeHtml(String(network.chainId))}" data-family="${escapeHtml(network.family)}" ${String(network.chainId) === String(solana?.chainId) ? "selected" : ""}>
              ${escapeHtml(network.name)}
            </option>
          `).join("")}
      </select>
      <label class="small">Asset</label>
      <select class="field" id="send-asset" name="assetId">
        ${solanaAssets.map((asset) => `
          <option
            value="${escapeHtml(buildPopupAssetId(asset))}"
            data-asset-type="${escapeHtml(asset.type === "spl" ? "spl" : "native")}"
            data-token-address="${escapeHtml(asset.tokenAddress ?? "")}"
            data-symbol="${escapeHtml(asset.symbol)}"
            data-decimals="${escapeHtml(String(asset.decimals))}"
            data-balance-raw="${escapeHtml(asset.balanceRaw)}"
          >
            ${escapeHtml(asset.symbol)} \xB7 ${escapeHtml(asset.balanceFormatted)} available
          </option>
        `).join("")}
      </select>
      <input class="field" name="toAddress" placeholder="Solana recipient address" autocomplete="off">
      <input class="field" name="amountFormatted" placeholder="Amount" inputmode="decimal">
      <p class="copy" id="send-support-note">SOL and SPL sends are queued for explicit popup confirmation. Missing recipient token accounts are shown in review.</p>
      <button class="primary-button" type="submit">Review Solana Send</button>
      <button class="ghost-button" type="button" data-open-url="https://24wallet.ru/send">Open full send</button>
    </form>
  `;
  }
  function renderEvmSwapComposer() {
    const networks = (currentHomeSnapshot?.networks ?? []).filter((network) => network.family === "evm" && network.capabilities.swap);
    const selectedNetwork = networks.find(
      (network) => String(network.chainId) === String(currentHomeSnapshot?.activeChainId)
    ) ?? networks[0] ?? null;
    const assets = getEvmSwapAssets(selectedNetwork?.chainId ?? 1);
    const defaultBuy = assets.find((asset) => asset.symbol === "USDC" && asset.type === "erc20") ?? assets.find((asset) => asset.type === "erc20") ?? assets[0];
    return `
    <form class="form" id="evm-swap-form">
      <label class="small">Network</label>
      <select class="field" id="swap-chain" name="chainId">
        ${networks.map((network) => `
          <option value="${escapeHtml(String(network.chainId))}" ${String(network.chainId) === String(selectedNetwork?.chainId) ? "selected" : ""}>
            ${escapeHtml(network.name)}
          </option>
        `).join("")}
      </select>
      <label class="small">Sell token</label>
      <select class="field" id="swap-sell-token" name="sellToken">
        ${assets.map((asset) => renderSwapAssetOption(asset)).join("")}
      </select>
      <label class="small">Buy token</label>
      <select class="field" id="swap-buy-token" name="buyToken">
        ${assets.map((asset) => renderSwapAssetOption(asset, asset === defaultBuy)).join("")}
      </select>
      <input class="field" name="amountRaw" placeholder="Sell amount in raw units, e.g. 1000000" inputmode="numeric">
      <select class="field" name="slippageBps">
        <option value="30">0.3% slippage</option>
        <option value="50" selected>0.5% slippage</option>
        <option value="100">1% slippage</option>
      </select>
      <p class="copy">0x quotes are loaded through the Acorus backend. Approval and swap broadcasts require explicit popup confirmation.</p>
      <button class="primary-button" type="submit">Get 0x Quote</button>
      <button class="ghost-button" type="button" data-open-url="https://24wallet.ru/swap">Open full swap</button>
      <div id="evm-swap-result" class="swap-result"></div>
    </form>
  `;
  }
  function renderSwapAssetOption(asset, selected = false) {
    const token = asset.type === "native" ? "native" : asset.tokenAddress ?? "";
    return `
    <option
      value="${escapeHtml(token)}"
      data-symbol="${escapeHtml(asset.symbol)}"
      data-decimals="${escapeHtml(String(asset.decimals))}"
      data-type="${escapeHtml(asset.type)}"
      ${selected ? "selected" : ""}
    >
      ${escapeHtml(asset.symbol)} \xB7 ${escapeHtml(asset.name)}
    </option>
  `;
  }
  function getEvmSwapAssets(chainId) {
    const chain = currentHomeSnapshot?.networks.find(
      (network) => String(network.chainId) === String(chainId)
    );
    const assets = currentHomeSnapshot?.assets.filter(
      (asset) => asset.family === "evm" && String(asset.chainId) === String(chainId)
    ) ?? [];
    const native = assets.find((asset) => asset.type === "native") ?? {
      family: "evm",
      chainId,
      type: "native",
      symbol: chain?.nativeSymbol ?? "ETH",
      name: chain?.name ?? "Ethereum",
      decimals: 18,
      tokenAddress: null,
      balanceRaw: "0",
      balanceFormatted: "0",
      fiatValue: null,
      priceUsd: null,
      source: "fallback"
    };
    const usdc = chainId === 1 ? {
      family: "evm",
      chainId,
      type: "erc20",
      symbol: "USDC",
      name: "USD Coin",
      decimals: 6,
      tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
      balanceRaw: "0",
      balanceFormatted: "0",
      fiatValue: null,
      priceUsd: null,
      source: "curated"
    } : null;
    const merged = [native, ...assets.filter((asset) => asset.type === "erc20")];
    if (usdc && !merged.some((asset) => asset.tokenAddress?.toLowerCase() === usdc.tokenAddress.toLowerCase())) {
      merged.push(usdc);
    }
    return merged;
  }
  function getSolanaSendAssets() {
    const assets = currentHomeSnapshot?.assets.filter((asset) => asset.family === "solana") ?? [];
    const hasSol = assets.some((asset) => asset.type === "native" && asset.symbol === "SOL");
    return hasSol ? assets : [
      {
        family: "solana",
        chainId: 101,
        type: "native",
        symbol: "SOL",
        name: "Solana",
        decimals: 9,
        tokenAddress: null,
        balanceRaw: "0",
        balanceFormatted: "0",
        fiatValue: null,
        priceUsd: null,
        source: "unavailable"
      },
      ...assets
    ];
  }
  function buildPopupAssetId(asset) {
    return [
      asset.family,
      String(asset.chainId),
      asset.type,
      asset.tokenAddress?.toLowerCase() ?? "native",
      asset.symbol.toUpperCase()
    ].join(":");
  }
  function actionButton(action, id, label, primary, danger = false) {
    const className = danger ? "danger-button" : primary ? "primary-button" : "ghost-button";
    return `<button data-action="${action}" data-id="${escapeHtml(id)}" class="${className}" type="button">${escapeHtml(label)}</button>`;
  }
  function chainName(chainId) {
    switch (Number(chainId)) {
      case 1:
        return "Ethereum";
      case 56:
        return "BNB Chain";
      case 137:
        return "Polygon";
      case 8453:
        return "Base";
      case 42161:
        return "Arbitrum";
      case 101:
        return "Solana";
      default:
        return chainId ? `Chain ${chainId}` : "Multichain";
    }
  }
  function shortAddress(value) {
    if (!value || value === "No synced account") {
      return value;
    }
    if (value.length <= 14) {
      return value;
    }
    return `${value.slice(0, 6)}...${value.slice(-4)}`;
  }
  function formatFiat(value) {
    return typeof value === "number" && Number.isFinite(value) ? `${value.toFixed(2)} $` : "\u2014";
  }
  function getRoot(message) {
    const element = document.getElementById("app");
    if (!element) {
      throw new Error(message);
    }
    return element;
  }
  function escapeHtml(value) {
    return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }
})();
