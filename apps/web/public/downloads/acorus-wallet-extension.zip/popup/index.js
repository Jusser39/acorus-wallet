"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../../node_modules/.pnpm/base64-js@1.5.1/node_modules/base64-js/index.js
  var require_base64_js = __commonJS({
    "../../node_modules/.pnpm/base64-js@1.5.1/node_modules/base64-js/index.js"(exports) {
      "use strict";
      init_node_compat_inject();
      exports.byteLength = byteLength;
      exports.toByteArray = toByteArray;
      exports.fromByteArray = fromByteArray;
      var lookup = [];
      var revLookup = [];
      var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
      var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for (i = 0, len = code.length; i < len; ++i) {
        lookup[i] = code[i];
        revLookup[code.charCodeAt(i)] = i;
      }
      var i;
      var len;
      revLookup["-".charCodeAt(0)] = 62;
      revLookup["_".charCodeAt(0)] = 63;
      function getLens(b64) {
        var len2 = b64.length;
        if (len2 % 4 > 0) {
          throw new Error("Invalid string. Length must be a multiple of 4");
        }
        var validLen = b64.indexOf("=");
        if (validLen === -1) validLen = len2;
        var placeHoldersLen = validLen === len2 ? 0 : 4 - validLen % 4;
        return [validLen, placeHoldersLen];
      }
      function byteLength(b64) {
        var lens = getLens(b64);
        var validLen = lens[0];
        var placeHoldersLen = lens[1];
        return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
      }
      function _byteLength(b64, validLen, placeHoldersLen) {
        return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
      }
      function toByteArray(b64) {
        var tmp;
        var lens = getLens(b64);
        var validLen = lens[0];
        var placeHoldersLen = lens[1];
        var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
        var curByte = 0;
        var len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
        var i2;
        for (i2 = 0; i2 < len2; i2 += 4) {
          tmp = revLookup[b64.charCodeAt(i2)] << 18 | revLookup[b64.charCodeAt(i2 + 1)] << 12 | revLookup[b64.charCodeAt(i2 + 2)] << 6 | revLookup[b64.charCodeAt(i2 + 3)];
          arr[curByte++] = tmp >> 16 & 255;
          arr[curByte++] = tmp >> 8 & 255;
          arr[curByte++] = tmp & 255;
        }
        if (placeHoldersLen === 2) {
          tmp = revLookup[b64.charCodeAt(i2)] << 2 | revLookup[b64.charCodeAt(i2 + 1)] >> 4;
          arr[curByte++] = tmp & 255;
        }
        if (placeHoldersLen === 1) {
          tmp = revLookup[b64.charCodeAt(i2)] << 10 | revLookup[b64.charCodeAt(i2 + 1)] << 4 | revLookup[b64.charCodeAt(i2 + 2)] >> 2;
          arr[curByte++] = tmp >> 8 & 255;
          arr[curByte++] = tmp & 255;
        }
        return arr;
      }
      function tripletToBase64(num) {
        return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
      }
      function encodeChunk(uint8, start, end) {
        var tmp;
        var output = [];
        for (var i2 = start; i2 < end; i2 += 3) {
          tmp = (uint8[i2] << 16 & 16711680) + (uint8[i2 + 1] << 8 & 65280) + (uint8[i2 + 2] & 255);
          output.push(tripletToBase64(tmp));
        }
        return output.join("");
      }
      function fromByteArray(uint8) {
        var tmp;
        var len2 = uint8.length;
        var extraBytes = len2 % 3;
        var parts = [];
        var maxChunkLength = 16383;
        for (var i2 = 0, len22 = len2 - extraBytes; i2 < len22; i2 += maxChunkLength) {
          parts.push(encodeChunk(uint8, i2, i2 + maxChunkLength > len22 ? len22 : i2 + maxChunkLength));
        }
        if (extraBytes === 1) {
          tmp = uint8[len2 - 1];
          parts.push(
            lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "=="
          );
        } else if (extraBytes === 2) {
          tmp = (uint8[len2 - 2] << 8) + uint8[len2 - 1];
          parts.push(
            lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "="
          );
        }
        return parts.join("");
      }
    }
  });

  // ../../node_modules/.pnpm/ieee754@1.2.1/node_modules/ieee754/index.js
  var require_ieee754 = __commonJS({
    "../../node_modules/.pnpm/ieee754@1.2.1/node_modules/ieee754/index.js"(exports) {
      "use strict";
      init_node_compat_inject();
      exports.read = function(buffer, offset, isLE, mLen, nBytes) {
        var e, m;
        var eLen = nBytes * 8 - mLen - 1;
        var eMax = (1 << eLen) - 1;
        var eBias = eMax >> 1;
        var nBits = -7;
        var i = isLE ? nBytes - 1 : 0;
        var d = isLE ? -1 : 1;
        var s = buffer[offset + i];
        i += d;
        e = s & (1 << -nBits) - 1;
        s >>= -nBits;
        nBits += eLen;
        for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {
        }
        m = e & (1 << -nBits) - 1;
        e >>= -nBits;
        nBits += mLen;
        for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {
        }
        if (e === 0) {
          e = 1 - eBias;
        } else if (e === eMax) {
          return m ? NaN : (s ? -1 : 1) * Infinity;
        } else {
          m = m + Math.pow(2, mLen);
          e = e - eBias;
        }
        return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
      };
      exports.write = function(buffer, value, offset, isLE, mLen, nBytes) {
        var e, m, c;
        var eLen = nBytes * 8 - mLen - 1;
        var eMax = (1 << eLen) - 1;
        var eBias = eMax >> 1;
        var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
        var i = isLE ? 0 : nBytes - 1;
        var d = isLE ? 1 : -1;
        var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
        value = Math.abs(value);
        if (isNaN(value) || value === Infinity) {
          m = isNaN(value) ? 1 : 0;
          e = eMax;
        } else {
          e = Math.floor(Math.log(value) / Math.LN2);
          if (value * (c = Math.pow(2, -e)) < 1) {
            e--;
            c *= 2;
          }
          if (e + eBias >= 1) {
            value += rt / c;
          } else {
            value += rt * Math.pow(2, 1 - eBias);
          }
          if (value * c >= 2) {
            e++;
            c /= 2;
          }
          if (e + eBias >= eMax) {
            m = 0;
            e = eMax;
          } else if (e + eBias >= 1) {
            m = (value * c - 1) * Math.pow(2, mLen);
            e = e + eBias;
          } else {
            m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
            e = 0;
          }
        }
        for (; mLen >= 8; buffer[offset + i] = m & 255, i += d, m /= 256, mLen -= 8) {
        }
        e = e << mLen | m;
        eLen += mLen;
        for (; eLen > 0; buffer[offset + i] = e & 255, i += d, e /= 256, eLen -= 8) {
        }
        buffer[offset + i - d] |= s * 128;
      };
    }
  });

  // ../../node_modules/.pnpm/buffer@6.0.3/node_modules/buffer/index.js
  var require_buffer = __commonJS({
    "../../node_modules/.pnpm/buffer@6.0.3/node_modules/buffer/index.js"(exports) {
      "use strict";
      init_node_compat_inject();
      var base64 = require_base64_js();
      var ieee754 = require_ieee754();
      var customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
      exports.Buffer = Buffer3;
      exports.SlowBuffer = SlowBuffer;
      exports.INSPECT_MAX_BYTES = 50;
      var K_MAX_LENGTH = 2147483647;
      exports.kMaxLength = K_MAX_LENGTH;
      Buffer3.TYPED_ARRAY_SUPPORT = typedArraySupport();
      if (!Buffer3.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
        console.error(
          "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
        );
      }
      function typedArraySupport() {
        try {
          const arr = new Uint8Array(1);
          const proto = { foo: function() {
            return 42;
          } };
          Object.setPrototypeOf(proto, Uint8Array.prototype);
          Object.setPrototypeOf(arr, proto);
          return arr.foo() === 42;
        } catch (e) {
          return false;
        }
      }
      Object.defineProperty(Buffer3.prototype, "parent", {
        enumerable: true,
        get: function() {
          if (!Buffer3.isBuffer(this)) return void 0;
          return this.buffer;
        }
      });
      Object.defineProperty(Buffer3.prototype, "offset", {
        enumerable: true,
        get: function() {
          if (!Buffer3.isBuffer(this)) return void 0;
          return this.byteOffset;
        }
      });
      function createBuffer(length) {
        if (length > K_MAX_LENGTH) {
          throw new RangeError('The value "' + length + '" is invalid for option "size"');
        }
        const buf = new Uint8Array(length);
        Object.setPrototypeOf(buf, Buffer3.prototype);
        return buf;
      }
      function Buffer3(arg, encodingOrOffset, length) {
        if (typeof arg === "number") {
          if (typeof encodingOrOffset === "string") {
            throw new TypeError(
              'The "string" argument must be of type string. Received type number'
            );
          }
          return allocUnsafe(arg);
        }
        return from(arg, encodingOrOffset, length);
      }
      Buffer3.poolSize = 8192;
      function from(value, encodingOrOffset, length) {
        if (typeof value === "string") {
          return fromString(value, encodingOrOffset);
        }
        if (ArrayBuffer.isView(value)) {
          return fromArrayView(value);
        }
        if (value == null) {
          throw new TypeError(
            "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
          );
        }
        if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof value === "number") {
          throw new TypeError(
            'The "value" argument must not be of type number. Received type number'
          );
        }
        const valueOf = value.valueOf && value.valueOf();
        if (valueOf != null && valueOf !== value) {
          return Buffer3.from(valueOf, encodingOrOffset, length);
        }
        const b = fromObject(value);
        if (b) return b;
        if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") {
          return Buffer3.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
        }
        throw new TypeError(
          "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
        );
      }
      Buffer3.from = function(value, encodingOrOffset, length) {
        return from(value, encodingOrOffset, length);
      };
      Object.setPrototypeOf(Buffer3.prototype, Uint8Array.prototype);
      Object.setPrototypeOf(Buffer3, Uint8Array);
      function assertSize(size) {
        if (typeof size !== "number") {
          throw new TypeError('"size" argument must be of type number');
        } else if (size < 0) {
          throw new RangeError('The value "' + size + '" is invalid for option "size"');
        }
      }
      function alloc(size, fill, encoding) {
        assertSize(size);
        if (size <= 0) {
          return createBuffer(size);
        }
        if (fill !== void 0) {
          return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
        }
        return createBuffer(size);
      }
      Buffer3.alloc = function(size, fill, encoding) {
        return alloc(size, fill, encoding);
      };
      function allocUnsafe(size) {
        assertSize(size);
        return createBuffer(size < 0 ? 0 : checked(size) | 0);
      }
      Buffer3.allocUnsafe = function(size) {
        return allocUnsafe(size);
      };
      Buffer3.allocUnsafeSlow = function(size) {
        return allocUnsafe(size);
      };
      function fromString(string, encoding) {
        if (typeof encoding !== "string" || encoding === "") {
          encoding = "utf8";
        }
        if (!Buffer3.isEncoding(encoding)) {
          throw new TypeError("Unknown encoding: " + encoding);
        }
        const length = byteLength(string, encoding) | 0;
        let buf = createBuffer(length);
        const actual = buf.write(string, encoding);
        if (actual !== length) {
          buf = buf.slice(0, actual);
        }
        return buf;
      }
      function fromArrayLike(array) {
        const length = array.length < 0 ? 0 : checked(array.length) | 0;
        const buf = createBuffer(length);
        for (let i = 0; i < length; i += 1) {
          buf[i] = array[i] & 255;
        }
        return buf;
      }
      function fromArrayView(arrayView) {
        if (isInstance(arrayView, Uint8Array)) {
          const copy = new Uint8Array(arrayView);
          return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
        }
        return fromArrayLike(arrayView);
      }
      function fromArrayBuffer(array, byteOffset, length) {
        if (byteOffset < 0 || array.byteLength < byteOffset) {
          throw new RangeError('"offset" is outside of buffer bounds');
        }
        if (array.byteLength < byteOffset + (length || 0)) {
          throw new RangeError('"length" is outside of buffer bounds');
        }
        let buf;
        if (byteOffset === void 0 && length === void 0) {
          buf = new Uint8Array(array);
        } else if (length === void 0) {
          buf = new Uint8Array(array, byteOffset);
        } else {
          buf = new Uint8Array(array, byteOffset, length);
        }
        Object.setPrototypeOf(buf, Buffer3.prototype);
        return buf;
      }
      function fromObject(obj) {
        if (Buffer3.isBuffer(obj)) {
          const len = checked(obj.length) | 0;
          const buf = createBuffer(len);
          if (buf.length === 0) {
            return buf;
          }
          obj.copy(buf, 0, 0, len);
          return buf;
        }
        if (obj.length !== void 0) {
          if (typeof obj.length !== "number" || numberIsNaN(obj.length)) {
            return createBuffer(0);
          }
          return fromArrayLike(obj);
        }
        if (obj.type === "Buffer" && Array.isArray(obj.data)) {
          return fromArrayLike(obj.data);
        }
      }
      function checked(length) {
        if (length >= K_MAX_LENGTH) {
          throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
        }
        return length | 0;
      }
      function SlowBuffer(length) {
        if (+length != length) {
          length = 0;
        }
        return Buffer3.alloc(+length);
      }
      Buffer3.isBuffer = function isBuffer(b) {
        return b != null && b._isBuffer === true && b !== Buffer3.prototype;
      };
      Buffer3.compare = function compare(a, b) {
        if (isInstance(a, Uint8Array)) a = Buffer3.from(a, a.offset, a.byteLength);
        if (isInstance(b, Uint8Array)) b = Buffer3.from(b, b.offset, b.byteLength);
        if (!Buffer3.isBuffer(a) || !Buffer3.isBuffer(b)) {
          throw new TypeError(
            'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
          );
        }
        if (a === b) return 0;
        let x = a.length;
        let y = b.length;
        for (let i = 0, len = Math.min(x, y); i < len; ++i) {
          if (a[i] !== b[i]) {
            x = a[i];
            y = b[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      Buffer3.isEncoding = function isEncoding(encoding) {
        switch (String(encoding).toLowerCase()) {
          case "hex":
          case "utf8":
          case "utf-8":
          case "ascii":
          case "latin1":
          case "binary":
          case "base64":
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return true;
          default:
            return false;
        }
      };
      Buffer3.concat = function concat(list, length) {
        if (!Array.isArray(list)) {
          throw new TypeError('"list" argument must be an Array of Buffers');
        }
        if (list.length === 0) {
          return Buffer3.alloc(0);
        }
        let i;
        if (length === void 0) {
          length = 0;
          for (i = 0; i < list.length; ++i) {
            length += list[i].length;
          }
        }
        const buffer = Buffer3.allocUnsafe(length);
        let pos = 0;
        for (i = 0; i < list.length; ++i) {
          let buf = list[i];
          if (isInstance(buf, Uint8Array)) {
            if (pos + buf.length > buffer.length) {
              if (!Buffer3.isBuffer(buf)) buf = Buffer3.from(buf);
              buf.copy(buffer, pos);
            } else {
              Uint8Array.prototype.set.call(
                buffer,
                buf,
                pos
              );
            }
          } else if (!Buffer3.isBuffer(buf)) {
            throw new TypeError('"list" argument must be an Array of Buffers');
          } else {
            buf.copy(buffer, pos);
          }
          pos += buf.length;
        }
        return buffer;
      };
      function byteLength(string, encoding) {
        if (Buffer3.isBuffer(string)) {
          return string.length;
        }
        if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
          return string.byteLength;
        }
        if (typeof string !== "string") {
          throw new TypeError(
            'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string
          );
        }
        const len = string.length;
        const mustMatch = arguments.length > 2 && arguments[2] === true;
        if (!mustMatch && len === 0) return 0;
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "ascii":
            case "latin1":
            case "binary":
              return len;
            case "utf8":
            case "utf-8":
              return utf8ToBytes(string).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return len * 2;
            case "hex":
              return len >>> 1;
            case "base64":
              return base64ToBytes(string).length;
            default:
              if (loweredCase) {
                return mustMatch ? -1 : utf8ToBytes(string).length;
              }
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer3.byteLength = byteLength;
      function slowToString(encoding, start, end) {
        let loweredCase = false;
        if (start === void 0 || start < 0) {
          start = 0;
        }
        if (start > this.length) {
          return "";
        }
        if (end === void 0 || end > this.length) {
          end = this.length;
        }
        if (end <= 0) {
          return "";
        }
        end >>>= 0;
        start >>>= 0;
        if (end <= start) {
          return "";
        }
        if (!encoding) encoding = "utf8";
        while (true) {
          switch (encoding) {
            case "hex":
              return hexSlice(this, start, end);
            case "utf8":
            case "utf-8":
              return utf8Slice(this, start, end);
            case "ascii":
              return asciiSlice(this, start, end);
            case "latin1":
            case "binary":
              return latin1Slice(this, start, end);
            case "base64":
              return base64Slice(this, start, end);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return utf16leSlice(this, start, end);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = (encoding + "").toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer3.prototype._isBuffer = true;
      function swap(b, n, m) {
        const i = b[n];
        b[n] = b[m];
        b[m] = i;
      }
      Buffer3.prototype.swap16 = function swap16() {
        const len = this.length;
        if (len % 2 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 16-bits");
        }
        for (let i = 0; i < len; i += 2) {
          swap(this, i, i + 1);
        }
        return this;
      };
      Buffer3.prototype.swap32 = function swap32() {
        const len = this.length;
        if (len % 4 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 32-bits");
        }
        for (let i = 0; i < len; i += 4) {
          swap(this, i, i + 3);
          swap(this, i + 1, i + 2);
        }
        return this;
      };
      Buffer3.prototype.swap64 = function swap64() {
        const len = this.length;
        if (len % 8 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 64-bits");
        }
        for (let i = 0; i < len; i += 8) {
          swap(this, i, i + 7);
          swap(this, i + 1, i + 6);
          swap(this, i + 2, i + 5);
          swap(this, i + 3, i + 4);
        }
        return this;
      };
      Buffer3.prototype.toString = function toString() {
        const length = this.length;
        if (length === 0) return "";
        if (arguments.length === 0) return utf8Slice(this, 0, length);
        return slowToString.apply(this, arguments);
      };
      Buffer3.prototype.toLocaleString = Buffer3.prototype.toString;
      Buffer3.prototype.equals = function equals(b) {
        if (!Buffer3.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
        if (this === b) return true;
        return Buffer3.compare(this, b) === 0;
      };
      Buffer3.prototype.inspect = function inspect() {
        let str = "";
        const max = exports.INSPECT_MAX_BYTES;
        str = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
        if (this.length > max) str += " ... ";
        return "<Buffer " + str + ">";
      };
      if (customInspectSymbol) {
        Buffer3.prototype[customInspectSymbol] = Buffer3.prototype.inspect;
      }
      Buffer3.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
        if (isInstance(target, Uint8Array)) {
          target = Buffer3.from(target, target.offset, target.byteLength);
        }
        if (!Buffer3.isBuffer(target)) {
          throw new TypeError(
            'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target
          );
        }
        if (start === void 0) {
          start = 0;
        }
        if (end === void 0) {
          end = target ? target.length : 0;
        }
        if (thisStart === void 0) {
          thisStart = 0;
        }
        if (thisEnd === void 0) {
          thisEnd = this.length;
        }
        if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
          throw new RangeError("out of range index");
        }
        if (thisStart >= thisEnd && start >= end) {
          return 0;
        }
        if (thisStart >= thisEnd) {
          return -1;
        }
        if (start >= end) {
          return 1;
        }
        start >>>= 0;
        end >>>= 0;
        thisStart >>>= 0;
        thisEnd >>>= 0;
        if (this === target) return 0;
        let x = thisEnd - thisStart;
        let y = end - start;
        const len = Math.min(x, y);
        const thisCopy = this.slice(thisStart, thisEnd);
        const targetCopy = target.slice(start, end);
        for (let i = 0; i < len; ++i) {
          if (thisCopy[i] !== targetCopy[i]) {
            x = thisCopy[i];
            y = targetCopy[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
        if (buffer.length === 0) return -1;
        if (typeof byteOffset === "string") {
          encoding = byteOffset;
          byteOffset = 0;
        } else if (byteOffset > 2147483647) {
          byteOffset = 2147483647;
        } else if (byteOffset < -2147483648) {
          byteOffset = -2147483648;
        }
        byteOffset = +byteOffset;
        if (numberIsNaN(byteOffset)) {
          byteOffset = dir ? 0 : buffer.length - 1;
        }
        if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
        if (byteOffset >= buffer.length) {
          if (dir) return -1;
          else byteOffset = buffer.length - 1;
        } else if (byteOffset < 0) {
          if (dir) byteOffset = 0;
          else return -1;
        }
        if (typeof val === "string") {
          val = Buffer3.from(val, encoding);
        }
        if (Buffer3.isBuffer(val)) {
          if (val.length === 0) {
            return -1;
          }
          return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
        } else if (typeof val === "number") {
          val = val & 255;
          if (typeof Uint8Array.prototype.indexOf === "function") {
            if (dir) {
              return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
            } else {
              return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
            }
          }
          return arrayIndexOf(buffer, [val], byteOffset, encoding, dir);
        }
        throw new TypeError("val must be string, number or Buffer");
      }
      function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
        let indexSize = 1;
        let arrLength = arr.length;
        let valLength = val.length;
        if (encoding !== void 0) {
          encoding = String(encoding).toLowerCase();
          if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
            if (arr.length < 2 || val.length < 2) {
              return -1;
            }
            indexSize = 2;
            arrLength /= 2;
            valLength /= 2;
            byteOffset /= 2;
          }
        }
        function read(buf, i2) {
          if (indexSize === 1) {
            return buf[i2];
          } else {
            return buf.readUInt16BE(i2 * indexSize);
          }
        }
        let i;
        if (dir) {
          let foundIndex = -1;
          for (i = byteOffset; i < arrLength; i++) {
            if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
              if (foundIndex === -1) foundIndex = i;
              if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
            } else {
              if (foundIndex !== -1) i -= i - foundIndex;
              foundIndex = -1;
            }
          }
        } else {
          if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
          for (i = byteOffset; i >= 0; i--) {
            let found = true;
            for (let j = 0; j < valLength; j++) {
              if (read(arr, i + j) !== read(val, j)) {
                found = false;
                break;
              }
            }
            if (found) return i;
          }
        }
        return -1;
      }
      Buffer3.prototype.includes = function includes(val, byteOffset, encoding) {
        return this.indexOf(val, byteOffset, encoding) !== -1;
      };
      Buffer3.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
      };
      Buffer3.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
      };
      function hexWrite(buf, string, offset, length) {
        offset = Number(offset) || 0;
        const remaining = buf.length - offset;
        if (!length) {
          length = remaining;
        } else {
          length = Number(length);
          if (length > remaining) {
            length = remaining;
          }
        }
        const strLen = string.length;
        if (length > strLen / 2) {
          length = strLen / 2;
        }
        let i;
        for (i = 0; i < length; ++i) {
          const parsed = parseInt(string.substr(i * 2, 2), 16);
          if (numberIsNaN(parsed)) return i;
          buf[offset + i] = parsed;
        }
        return i;
      }
      function utf8Write(buf, string, offset, length) {
        return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
      }
      function asciiWrite(buf, string, offset, length) {
        return blitBuffer(asciiToBytes(string), buf, offset, length);
      }
      function base64Write(buf, string, offset, length) {
        return blitBuffer(base64ToBytes(string), buf, offset, length);
      }
      function ucs2Write(buf, string, offset, length) {
        return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
      }
      Buffer3.prototype.write = function write(string, offset, length, encoding) {
        if (offset === void 0) {
          encoding = "utf8";
          length = this.length;
          offset = 0;
        } else if (length === void 0 && typeof offset === "string") {
          encoding = offset;
          length = this.length;
          offset = 0;
        } else if (isFinite(offset)) {
          offset = offset >>> 0;
          if (isFinite(length)) {
            length = length >>> 0;
            if (encoding === void 0) encoding = "utf8";
          } else {
            encoding = length;
            length = void 0;
          }
        } else {
          throw new Error(
            "Buffer.write(string, encoding, offset[, length]) is no longer supported"
          );
        }
        const remaining = this.length - offset;
        if (length === void 0 || length > remaining) length = remaining;
        if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
          throw new RangeError("Attempt to write outside buffer bounds");
        }
        if (!encoding) encoding = "utf8";
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "hex":
              return hexWrite(this, string, offset, length);
            case "utf8":
            case "utf-8":
              return utf8Write(this, string, offset, length);
            case "ascii":
            case "latin1":
            case "binary":
              return asciiWrite(this, string, offset, length);
            case "base64":
              return base64Write(this, string, offset, length);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return ucs2Write(this, string, offset, length);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      };
      Buffer3.prototype.toJSON = function toJSON() {
        return {
          type: "Buffer",
          data: Array.prototype.slice.call(this._arr || this, 0)
        };
      };
      function base64Slice(buf, start, end) {
        if (start === 0 && end === buf.length) {
          return base64.fromByteArray(buf);
        } else {
          return base64.fromByteArray(buf.slice(start, end));
        }
      }
      function utf8Slice(buf, start, end) {
        end = Math.min(buf.length, end);
        const res = [];
        let i = start;
        while (i < end) {
          const firstByte = buf[i];
          let codePoint = null;
          let bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
          if (i + bytesPerSequence <= end) {
            let secondByte, thirdByte, fourthByte, tempCodePoint;
            switch (bytesPerSequence) {
              case 1:
                if (firstByte < 128) {
                  codePoint = firstByte;
                }
                break;
              case 2:
                secondByte = buf[i + 1];
                if ((secondByte & 192) === 128) {
                  tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
                  if (tempCodePoint > 127) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 3:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
                  if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 4:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                fourthByte = buf[i + 3];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
                  if (tempCodePoint > 65535 && tempCodePoint < 1114112) {
                    codePoint = tempCodePoint;
                  }
                }
            }
          }
          if (codePoint === null) {
            codePoint = 65533;
            bytesPerSequence = 1;
          } else if (codePoint > 65535) {
            codePoint -= 65536;
            res.push(codePoint >>> 10 & 1023 | 55296);
            codePoint = 56320 | codePoint & 1023;
          }
          res.push(codePoint);
          i += bytesPerSequence;
        }
        return decodeCodePointsArray(res);
      }
      var MAX_ARGUMENTS_LENGTH = 4096;
      function decodeCodePointsArray(codePoints) {
        const len = codePoints.length;
        if (len <= MAX_ARGUMENTS_LENGTH) {
          return String.fromCharCode.apply(String, codePoints);
        }
        let res = "";
        let i = 0;
        while (i < len) {
          res += String.fromCharCode.apply(
            String,
            codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
          );
        }
        return res;
      }
      function asciiSlice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i] & 127);
        }
        return ret;
      }
      function latin1Slice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i]);
        }
        return ret;
      }
      function hexSlice(buf, start, end) {
        const len = buf.length;
        if (!start || start < 0) start = 0;
        if (!end || end < 0 || end > len) end = len;
        let out = "";
        for (let i = start; i < end; ++i) {
          out += hexSliceLookupTable[buf[i]];
        }
        return out;
      }
      function utf16leSlice(buf, start, end) {
        const bytes = buf.slice(start, end);
        let res = "";
        for (let i = 0; i < bytes.length - 1; i += 2) {
          res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
        }
        return res;
      }
      Buffer3.prototype.slice = function slice(start, end) {
        const len = this.length;
        start = ~~start;
        end = end === void 0 ? len : ~~end;
        if (start < 0) {
          start += len;
          if (start < 0) start = 0;
        } else if (start > len) {
          start = len;
        }
        if (end < 0) {
          end += len;
          if (end < 0) end = 0;
        } else if (end > len) {
          end = len;
        }
        if (end < start) end = start;
        const newBuf = this.subarray(start, end);
        Object.setPrototypeOf(newBuf, Buffer3.prototype);
        return newBuf;
      };
      function checkOffset(offset, ext, length) {
        if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
        if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
      }
      Buffer3.prototype.readUintLE = Buffer3.prototype.readUIntLE = function readUIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        return val;
      };
      Buffer3.prototype.readUintBE = Buffer3.prototype.readUIntBE = function readUIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          checkOffset(offset, byteLength2, this.length);
        }
        let val = this[offset + --byteLength2];
        let mul = 1;
        while (byteLength2 > 0 && (mul *= 256)) {
          val += this[offset + --byteLength2] * mul;
        }
        return val;
      };
      Buffer3.prototype.readUint8 = Buffer3.prototype.readUInt8 = function readUInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        return this[offset];
      };
      Buffer3.prototype.readUint16LE = Buffer3.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] | this[offset + 1] << 8;
      };
      Buffer3.prototype.readUint16BE = Buffer3.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] << 8 | this[offset + 1];
      };
      Buffer3.prototype.readUint32LE = Buffer3.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
      };
      Buffer3.prototype.readUint32BE = Buffer3.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
      };
      Buffer3.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
        const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last * 2 ** 24;
        return BigInt(lo) + (BigInt(hi) << BigInt(32));
      });
      Buffer3.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last;
        return (BigInt(hi) << BigInt(32)) + BigInt(lo);
      });
      Buffer3.prototype.readIntLE = function readIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer3.prototype.readIntBE = function readIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let i = byteLength2;
        let mul = 1;
        let val = this[offset + --i];
        while (i > 0 && (mul *= 256)) {
          val += this[offset + --i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer3.prototype.readInt8 = function readInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        if (!(this[offset] & 128)) return this[offset];
        return (255 - this[offset] + 1) * -1;
      };
      Buffer3.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset] | this[offset + 1] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer3.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset + 1] | this[offset] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer3.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
      };
      Buffer3.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
      };
      Buffer3.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last << 24);
        return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
      });
      Buffer3.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = (first << 24) + // Overflow
        this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last);
      });
      Buffer3.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee754.read(this, offset, true, 23, 4);
      };
      Buffer3.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee754.read(this, offset, false, 23, 4);
      };
      Buffer3.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee754.read(this, offset, true, 52, 8);
      };
      Buffer3.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee754.read(this, offset, false, 52, 8);
      };
      function checkInt(buf, value, offset, ext, max, min) {
        if (!Buffer3.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
      }
      Buffer3.prototype.writeUintLE = Buffer3.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let mul = 1;
        let i = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeUintBE = Buffer3.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeUint8 = Buffer3.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 255, 0);
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer3.prototype.writeUint16LE = Buffer3.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer3.prototype.writeUint16BE = Buffer3.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer3.prototype.writeUint32LE = Buffer3.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset + 3] = value >>> 24;
        this[offset + 2] = value >>> 16;
        this[offset + 1] = value >>> 8;
        this[offset] = value & 255;
        return offset + 4;
      };
      Buffer3.prototype.writeUint32BE = Buffer3.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      function wrtBigUInt64LE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        return offset;
      }
      function wrtBigUInt64BE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset + 7] = lo;
        lo = lo >> 8;
        buf[offset + 6] = lo;
        lo = lo >> 8;
        buf[offset + 5] = lo;
        lo = lo >> 8;
        buf[offset + 4] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset + 3] = hi;
        hi = hi >> 8;
        buf[offset + 2] = hi;
        hi = hi >> 8;
        buf[offset + 1] = hi;
        hi = hi >> 8;
        buf[offset] = hi;
        return offset + 8;
      }
      Buffer3.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer3.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer3.prototype.writeIntLE = function writeIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = 0;
        let mul = 1;
        let sub = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeIntBE = function writeIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        let sub = 0;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 127, -128);
        if (value < 0) value = 255 + value + 1;
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer3.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer3.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer3.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        this[offset + 2] = value >>> 16;
        this[offset + 3] = value >>> 24;
        return offset + 4;
      };
      Buffer3.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        if (value < 0) value = 4294967295 + value + 1;
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      Buffer3.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      Buffer3.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      function checkIEEE754(buf, value, offset, ext, max, min) {
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
        if (offset < 0) throw new RangeError("Index out of range");
      }
      function writeFloat(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 4, 34028234663852886e22, -34028234663852886e22);
        }
        ieee754.write(buf, value, offset, littleEndian, 23, 4);
        return offset + 4;
      }
      Buffer3.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
        return writeFloat(this, value, offset, true, noAssert);
      };
      Buffer3.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
        return writeFloat(this, value, offset, false, noAssert);
      };
      function writeDouble(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 8, 17976931348623157e292, -17976931348623157e292);
        }
        ieee754.write(buf, value, offset, littleEndian, 52, 8);
        return offset + 8;
      }
      Buffer3.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
        return writeDouble(this, value, offset, true, noAssert);
      };
      Buffer3.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
        return writeDouble(this, value, offset, false, noAssert);
      };
      Buffer3.prototype.copy = function copy(target, targetStart, start, end) {
        if (!Buffer3.isBuffer(target)) throw new TypeError("argument should be a Buffer");
        if (!start) start = 0;
        if (!end && end !== 0) end = this.length;
        if (targetStart >= target.length) targetStart = target.length;
        if (!targetStart) targetStart = 0;
        if (end > 0 && end < start) end = start;
        if (end === start) return 0;
        if (target.length === 0 || this.length === 0) return 0;
        if (targetStart < 0) {
          throw new RangeError("targetStart out of bounds");
        }
        if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
        if (end < 0) throw new RangeError("sourceEnd out of bounds");
        if (end > this.length) end = this.length;
        if (target.length - targetStart < end - start) {
          end = target.length - targetStart + start;
        }
        const len = end - start;
        if (this === target && typeof Uint8Array.prototype.copyWithin === "function") {
          this.copyWithin(targetStart, start, end);
        } else {
          Uint8Array.prototype.set.call(
            target,
            this.subarray(start, end),
            targetStart
          );
        }
        return len;
      };
      Buffer3.prototype.fill = function fill(val, start, end, encoding) {
        if (typeof val === "string") {
          if (typeof start === "string") {
            encoding = start;
            start = 0;
            end = this.length;
          } else if (typeof end === "string") {
            encoding = end;
            end = this.length;
          }
          if (encoding !== void 0 && typeof encoding !== "string") {
            throw new TypeError("encoding must be a string");
          }
          if (typeof encoding === "string" && !Buffer3.isEncoding(encoding)) {
            throw new TypeError("Unknown encoding: " + encoding);
          }
          if (val.length === 1) {
            const code = val.charCodeAt(0);
            if (encoding === "utf8" && code < 128 || encoding === "latin1") {
              val = code;
            }
          }
        } else if (typeof val === "number") {
          val = val & 255;
        } else if (typeof val === "boolean") {
          val = Number(val);
        }
        if (start < 0 || this.length < start || this.length < end) {
          throw new RangeError("Out of range index");
        }
        if (end <= start) {
          return this;
        }
        start = start >>> 0;
        end = end === void 0 ? this.length : end >>> 0;
        if (!val) val = 0;
        let i;
        if (typeof val === "number") {
          for (i = start; i < end; ++i) {
            this[i] = val;
          }
        } else {
          const bytes = Buffer3.isBuffer(val) ? val : Buffer3.from(val, encoding);
          const len = bytes.length;
          if (len === 0) {
            throw new TypeError('The value "' + val + '" is invalid for argument "value"');
          }
          for (i = 0; i < end - start; ++i) {
            this[i + start] = bytes[i % len];
          }
        }
        return this;
      };
      var errors = {};
      function E(sym, getMessage, Base) {
        errors[sym] = class NodeError extends Base {
          constructor() {
            super();
            Object.defineProperty(this, "message", {
              value: getMessage.apply(this, arguments),
              writable: true,
              configurable: true
            });
            this.name = `${this.name} [${sym}]`;
            this.stack;
            delete this.name;
          }
          get code() {
            return sym;
          }
          set code(value) {
            Object.defineProperty(this, "code", {
              configurable: true,
              enumerable: true,
              value,
              writable: true
            });
          }
          toString() {
            return `${this.name} [${sym}]: ${this.message}`;
          }
        };
      }
      E(
        "ERR_BUFFER_OUT_OF_BOUNDS",
        function(name) {
          if (name) {
            return `${name} is outside of buffer bounds`;
          }
          return "Attempt to access memory outside buffer bounds";
        },
        RangeError
      );
      E(
        "ERR_INVALID_ARG_TYPE",
        function(name, actual) {
          return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
        },
        TypeError
      );
      E(
        "ERR_OUT_OF_RANGE",
        function(str, range, input) {
          let msg = `The value of "${str}" is out of range.`;
          let received = input;
          if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
            received = addNumericalSeparator(String(input));
          } else if (typeof input === "bigint") {
            received = String(input);
            if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
              received = addNumericalSeparator(received);
            }
            received += "n";
          }
          msg += ` It must be ${range}. Received ${received}`;
          return msg;
        },
        RangeError
      );
      function addNumericalSeparator(val) {
        let res = "";
        let i = val.length;
        const start = val[0] === "-" ? 1 : 0;
        for (; i >= start + 4; i -= 3) {
          res = `_${val.slice(i - 3, i)}${res}`;
        }
        return `${val.slice(0, i)}${res}`;
      }
      function checkBounds(buf, offset, byteLength2) {
        validateNumber(offset, "offset");
        if (buf[offset] === void 0 || buf[offset + byteLength2] === void 0) {
          boundsError(offset, buf.length - (byteLength2 + 1));
        }
      }
      function checkIntBI(value, min, max, buf, offset, byteLength2) {
        if (value > max || value < min) {
          const n = typeof min === "bigint" ? "n" : "";
          let range;
          if (byteLength2 > 3) {
            if (min === 0 || min === BigInt(0)) {
              range = `>= 0${n} and < 2${n} ** ${(byteLength2 + 1) * 8}${n}`;
            } else {
              range = `>= -(2${n} ** ${(byteLength2 + 1) * 8 - 1}${n}) and < 2 ** ${(byteLength2 + 1) * 8 - 1}${n}`;
            }
          } else {
            range = `>= ${min}${n} and <= ${max}${n}`;
          }
          throw new errors.ERR_OUT_OF_RANGE("value", range, value);
        }
        checkBounds(buf, offset, byteLength2);
      }
      function validateNumber(value, name) {
        if (typeof value !== "number") {
          throw new errors.ERR_INVALID_ARG_TYPE(name, "number", value);
        }
      }
      function boundsError(value, length, type) {
        if (Math.floor(value) !== value) {
          validateNumber(value, type);
          throw new errors.ERR_OUT_OF_RANGE(type || "offset", "an integer", value);
        }
        if (length < 0) {
          throw new errors.ERR_BUFFER_OUT_OF_BOUNDS();
        }
        throw new errors.ERR_OUT_OF_RANGE(
          type || "offset",
          `>= ${type ? 1 : 0} and <= ${length}`,
          value
        );
      }
      var INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
      function base64clean(str) {
        str = str.split("=")[0];
        str = str.trim().replace(INVALID_BASE64_RE, "");
        if (str.length < 2) return "";
        while (str.length % 4 !== 0) {
          str = str + "=";
        }
        return str;
      }
      function utf8ToBytes(string, units) {
        units = units || Infinity;
        let codePoint;
        const length = string.length;
        let leadSurrogate = null;
        const bytes = [];
        for (let i = 0; i < length; ++i) {
          codePoint = string.charCodeAt(i);
          if (codePoint > 55295 && codePoint < 57344) {
            if (!leadSurrogate) {
              if (codePoint > 56319) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              } else if (i + 1 === length) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              }
              leadSurrogate = codePoint;
              continue;
            }
            if (codePoint < 56320) {
              if ((units -= 3) > -1) bytes.push(239, 191, 189);
              leadSurrogate = codePoint;
              continue;
            }
            codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
          } else if (leadSurrogate) {
            if ((units -= 3) > -1) bytes.push(239, 191, 189);
          }
          leadSurrogate = null;
          if (codePoint < 128) {
            if ((units -= 1) < 0) break;
            bytes.push(codePoint);
          } else if (codePoint < 2048) {
            if ((units -= 2) < 0) break;
            bytes.push(
              codePoint >> 6 | 192,
              codePoint & 63 | 128
            );
          } else if (codePoint < 65536) {
            if ((units -= 3) < 0) break;
            bytes.push(
              codePoint >> 12 | 224,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else if (codePoint < 1114112) {
            if ((units -= 4) < 0) break;
            bytes.push(
              codePoint >> 18 | 240,
              codePoint >> 12 & 63 | 128,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else {
            throw new Error("Invalid code point");
          }
        }
        return bytes;
      }
      function asciiToBytes(str) {
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          byteArray.push(str.charCodeAt(i) & 255);
        }
        return byteArray;
      }
      function utf16leToBytes(str, units) {
        let c, hi, lo;
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          if ((units -= 2) < 0) break;
          c = str.charCodeAt(i);
          hi = c >> 8;
          lo = c % 256;
          byteArray.push(lo);
          byteArray.push(hi);
        }
        return byteArray;
      }
      function base64ToBytes(str) {
        return base64.toByteArray(base64clean(str));
      }
      function blitBuffer(src, dst, offset, length) {
        let i;
        for (i = 0; i < length; ++i) {
          if (i + offset >= dst.length || i >= src.length) break;
          dst[i + offset] = src[i];
        }
        return i;
      }
      function isInstance(obj, type) {
        return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
      }
      function numberIsNaN(obj) {
        return obj !== obj;
      }
      var hexSliceLookupTable = (function() {
        const alphabet = "0123456789abcdef";
        const table = new Array(256);
        for (let i = 0; i < 16; ++i) {
          const i16 = i * 16;
          for (let j = 0; j < 16; ++j) {
            table[i16 + j] = alphabet[i] + alphabet[j];
          }
        }
        return table;
      })();
      function defineBigIntMethod(fn) {
        return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn;
      }
      function BufferBigIntNotDefined() {
        throw new Error("BigInt not supported");
      }
    }
  });

  // src/shared/node-compat-inject.ts
  var import_buffer, nodeProcess, globalWithNodeCompat, processTarget;
  var init_node_compat_inject = __esm({
    "src/shared/node-compat-inject.ts"() {
      "use strict";
      import_buffer = __toESM(require_buffer(), 1);
      nodeProcess = {
        browser: true,
        env: {},
        version: ""
      };
      globalWithNodeCompat = globalThis;
      processTarget = globalThis;
      if (!globalWithNodeCompat.Buffer) {
        globalWithNodeCompat.Buffer = import_buffer.Buffer;
      }
      if (!globalWithNodeCompat.global) {
        globalWithNodeCompat.global = globalThis;
      }
      if (!processTarget.process) {
        processTarget.process = nodeProcess;
      }
    }
  });

  // src/popup/index.ts
  init_node_compat_inject();

  // ../../packages/shared/src/index.ts
  init_node_compat_inject();

  // ../../packages/shared/src/chains.ts
  init_node_compat_inject();
  var DEFAULT_SOLANA_CHAIN_ID = 101;
  var DEFAULT_TRON_CHAIN_ID = "tron-mainnet";
  var DEFAULT_BITCOIN_CHAIN_ID = "bitcoin-mainnet";
  var DEFAULT_TON_CHAIN_ID = "ton-mainnet";
  var EVM_CHAINS = [
    {
      chainId: 1,
      family: "evm",
      name: "Ethereum",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ETH_RPC_URL",
      blockExplorerUrl: "https://etherscan.io"
    },
    {
      chainId: 56,
      family: "evm",
      name: "BNB Smart Chain",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_BSC_RPC_URL",
      blockExplorerUrl: "https://bscscan.com"
    },
    {
      chainId: 137,
      family: "evm",
      name: "Polygon",
      nativeSymbol: "MATIC",
      rpcUrlEnv: "NEXT_PUBLIC_POLYGON_RPC_URL",
      blockExplorerUrl: "https://polygonscan.com"
    },
    {
      chainId: 42161,
      family: "evm",
      name: "Arbitrum One",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ARBITRUM_RPC_URL",
      blockExplorerUrl: "https://arbiscan.io"
    },
    {
      chainId: 10,
      family: "evm",
      name: "Optimism",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_OPTIMISM_RPC_URL",
      blockExplorerUrl: "https://optimistic.etherscan.io"
    },
    {
      chainId: 8453,
      family: "evm",
      name: "Base",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_BASE_RPC_URL",
      blockExplorerUrl: "https://basescan.org"
    },
    {
      chainId: 43114,
      family: "evm",
      name: "Avalanche",
      nativeSymbol: "AVAX",
      rpcUrlEnv: "NEXT_PUBLIC_AVALANCHE_RPC_URL",
      blockExplorerUrl: "https://snowtrace.io"
    },
    {
      chainId: 59144,
      family: "evm",
      name: "Linea",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_LINEA_RPC_URL",
      blockExplorerUrl: "https://lineascan.build"
    },
    {
      chainId: 250,
      family: "evm",
      name: "Fantom",
      nativeSymbol: "FTM",
      rpcUrlEnv: "NEXT_PUBLIC_FANTOM_RPC_URL",
      blockExplorerUrl: "https://ftmscan.com"
    },
    {
      chainId: 1329,
      family: "evm",
      name: "Sei",
      nativeSymbol: "SEI",
      rpcUrlEnv: "NEXT_PUBLIC_SEI_RPC_URL",
      blockExplorerUrl: "https://seitrace.com"
    },
    {
      chainId: 204,
      family: "evm",
      name: "opBNB",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_OPBNB_RPC_URL",
      blockExplorerUrl: "https://opbnbscan.com"
    },
    {
      chainId: 324,
      family: "evm",
      name: "zkSync Era",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ZKSYNC_RPC_URL",
      blockExplorerUrl: "https://era.zksync.network"
    }
  ];
  var SOLANA_MAINNET_CHAIN = {
    chainId: DEFAULT_SOLANA_CHAIN_ID,
    family: "solana",
    name: "Solana",
    network: "mainnet-beta",
    nativeSymbol: "SOL",
    rpcUrlEnv: "NEXT_PUBLIC_SOLANA_RPC_URL",
    blockExplorerUrl: "https://solscan.io"
  };
  var TRON_MAINNET_CHAIN = {
    family: "tron",
    chainId: DEFAULT_TRON_CHAIN_ID,
    name: "Tron",
    nativeSymbol: "TRX",
    rpcUrlEnv: "NEXT_PUBLIC_TRON_RPC_URL",
    blockExplorerUrl: "https://tronscan.org/#",
    isEnabled: false,
    isSkeleton: true
  };
  var BITCOIN_MAINNET_CHAIN = {
    family: "utxo",
    chainId: DEFAULT_BITCOIN_CHAIN_ID,
    name: "Bitcoin",
    nativeSymbol: "BTC",
    rpcUrlEnv: "NEXT_PUBLIC_BITCOIN_RPC_URL",
    blockExplorerUrl: "https://mempool.space",
    isEnabled: false,
    isSkeleton: true
  };
  var TON_MAINNET_CHAIN = {
    family: "ton",
    chainId: DEFAULT_TON_CHAIN_ID,
    name: "TON",
    nativeSymbol: "TON",
    rpcUrlEnv: "NEXT_PUBLIC_TON_RPC_URL",
    blockExplorerUrl: "https://tonscan.org",
    isEnabled: false,
    isSkeleton: true
  };
  var UNIVERSAL_CHAINS = [
    ...EVM_CHAINS.map((chain) => ({
      family: "evm",
      chainId: chain.chainId,
      name: chain.name,
      nativeSymbol: chain.nativeSymbol,
      rpcUrlEnv: chain.rpcUrlEnv,
      blockExplorerUrl: chain.blockExplorerUrl,
      isEnabled: true
    })),
    {
      family: SOLANA_MAINNET_CHAIN.family,
      chainId: SOLANA_MAINNET_CHAIN.chainId,
      name: SOLANA_MAINNET_CHAIN.name,
      nativeSymbol: SOLANA_MAINNET_CHAIN.nativeSymbol,
      rpcUrlEnv: SOLANA_MAINNET_CHAIN.rpcUrlEnv,
      blockExplorerUrl: SOLANA_MAINNET_CHAIN.blockExplorerUrl,
      network: SOLANA_MAINNET_CHAIN.network,
      isEnabled: true
    },
    TRON_MAINNET_CHAIN,
    BITCOIN_MAINNET_CHAIN,
    TON_MAINNET_CHAIN
  ];

  // ../../packages/shared/src/capabilities.ts
  init_node_compat_inject();

  // ../../packages/shared/src/dapp.ts
  init_node_compat_inject();
  function getDappRequestKindLabel(kind) {
    switch (kind) {
      case "connect":
        return "Connect";
      case "add_chain":
        return "Add network";
      case "watch_asset":
        return "Watch asset";
      case "multichain_send":
        return "Send";
      case "swap":
        return "Swap";
      case "sign_message":
        return "Sign message";
      case "sign_typed_data":
        return "Sign typed data";
      case "sign_transaction":
        return "Sign transaction";
      case "send_transaction":
        return "Send transaction";
      default:
        return kind;
    }
  }
  function getDappConnectionTransportLabel(transport) {
    switch (transport) {
      case "walletconnect":
        return "WalletConnect";
      case "injected":
      default:
        return "Injected";
    }
  }

  // ../../packages/shared/src/evm-swap.ts
  init_node_compat_inject();

  // ../../packages/shared/src/tokens.ts
  init_node_compat_inject();

  // ../../packages/shared/src/evm-swap.ts
  function formatEvmTokenAmount(raw, decimals) {
    if (!/^[0-9]+$/u.test(raw)) {
      throw new Error("Invalid raw amount.");
    }
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > 30) {
      throw new Error("Invalid token decimals.");
    }
    const value = BigInt(raw);
    const base = 10n ** BigInt(decimals);
    const whole = value / base;
    const fraction = value % base;
    const fractionText = fraction.toString().padStart(decimals, "0").replace(/0+$/u, "");
    return fractionText ? `${whole.toString()}.${fractionText}` : whole.toString();
  }
  function shortenFormattedEvmTokenAmount(raw, decimals, maxFractionDigits = 6) {
    const formatted = formatEvmTokenAmount(raw, decimals);
    const [wholePart = "0", fractionPart] = formatted.split(".");
    if (!fractionPart || maxFractionDigits < 0) {
      return formatted;
    }
    const trimmedFraction = fractionPart.slice(0, maxFractionDigits).replace(/0+$/u, "");
    return trimmedFraction ? `${wholePart}.${trimmedFraction}` : wholePart;
  }

  // ../../packages/shared/src/explore.ts
  init_node_compat_inject();

  // ../../packages/shared/src/market.ts
  init_node_compat_inject();

  // ../../packages/shared/src/multichain.ts
  init_node_compat_inject();

  // ../../packages/shared/src/practice.ts
  init_node_compat_inject();

  // ../../packages/shared/src/types.ts
  init_node_compat_inject();

  // src/shared/protocol.ts
  init_node_compat_inject();
  var ACORUS_PROVIDER_METHODS = [
    "acorus_ping",
    "acorus_getVaultStatus",
    "acorus_createWallet",
    "acorus_importWallet",
    "acorus_unlockWallet",
    "acorus_lockWallet",
    "acorus_receiveAddress",
    "acorus_requestAccounts",
    "acorus_accounts",
    "acorus_chainId",
    "acorus_switchChain",
    "acorus_getPermissions",
    "acorus_requestPermissions",
    "acorus_revokePermissions",
    "acorus_addChain",
    "acorus_watchAsset",
    "acorus_multichainSend",
    "acorus_swap",
    "acorus_signMessage",
    "acorus_signTypedData",
    "acorus_signTransaction",
    "acorus_sendTransaction"
  ];
  function createRequestId(prefix = "acorus") {
    if (globalThis.crypto?.randomUUID) {
      return `${prefix}_${globalThis.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }
  function createSkeletonState(input) {
    return {
      phase: "permission_shell",
      providerInjection: input?.providerInjection ?? "stub_only",
      executionEnabled: input?.executionEnabled ?? true,
      proposals: input?.proposals ?? [],
      sessions: input?.sessions ?? [],
      pendingRequests: input?.pendingRequests ?? [],
      approvalResults: input?.approvalResults ?? [],
      activityLog: input?.activityLog ?? [],
      signerUnlockQueue: input?.signerUnlockQueue ?? [],
      activeOriginBridge: input?.activeOriginBridge ?? null,
      walletExposureMode: input?.walletExposureMode ?? "preview_accounts",
      walletExposedAccounts: input?.walletExposedAccounts ?? [],
      walletLastSyncedAt: input?.walletLastSyncedAt ?? null,
      extensionVaultStatus: input?.extensionVaultStatus ?? {
        hasVault: false,
        isUnlocked: false,
        activeProfileId: null,
        profiles: [],
        unlockedAt: null,
        createdAt: null,
        updatedAt: null
      },
      supportedMethods: ACORUS_PROVIDER_METHODS,
      lastUpdatedAt: input?.lastUpdatedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
      activeOrigin: input?.activeOrigin ?? null
    };
  }

  // src/popup/index.ts
  var root = getRoot("Popup root not found.");
  var EXTENSION_SWAP_API_BASES = ["https://24wallet.ru", "http://85.239.59.199:8080"];
  var EXTENSION_POPUP_SETTINGS_KEY = "acorus_extension_popup_settings";
  var POPUP_HOME_TIMEOUT_MS = 2500;
  var POPUP_CURRENCIES = ["USD", "EUR", "RUB", "GBP", "JPY", "CNY", "KRW", "TRY"];
  var POPUP_LANGUAGES = [
    "English",
    "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
    "Deutsch",
    "Espa\xF1ol",
    "Fran\xE7ais",
    "\u4E2D\u6587",
    "\u65E5\u672C\u8A9E",
    "\uD55C\uAD6D\uC5B4"
  ];
  var FALLBACK_NETWORKS = [
    {
      id: "1",
      family: "evm",
      chainId: 1,
      name: "Ethereum",
      nativeSymbol: "ETH",
      iconSymbol: "ETH",
      accent: "#627EEA",
      capabilities: { receive: true, balance: true, send: true, swap: true, dapp: true }
    },
    {
      id: "56",
      family: "evm",
      chainId: 56,
      name: "BNB Smart Chain",
      nativeSymbol: "BNB",
      iconSymbol: "BNB",
      accent: "#F3BA2F",
      capabilities: { receive: true, balance: true, send: true, swap: true, dapp: true }
    },
    {
      id: "137",
      family: "evm",
      chainId: 137,
      name: "Polygon",
      nativeSymbol: "POL",
      iconSymbol: "POL",
      accent: "#8247E5",
      capabilities: { receive: true, balance: true, send: true, swap: true, dapp: true }
    },
    {
      id: "8453",
      family: "evm",
      chainId: 8453,
      name: "Base",
      nativeSymbol: "ETH",
      iconSymbol: "BASE",
      accent: "#0052FF",
      capabilities: { receive: true, balance: true, send: true, swap: true, dapp: true }
    },
    {
      id: "101",
      family: "solana",
      chainId: 101,
      name: "Solana",
      nativeSymbol: "SOL",
      iconSymbol: "SOL",
      accent: "#14F195",
      capabilities: { receive: true, balance: true, send: true, swap: true, dapp: true }
    },
    {
      id: "tron-mainnet",
      family: "tron",
      chainId: "tron-mainnet",
      name: "Tron",
      nativeSymbol: "TRX",
      iconSymbol: "TRX",
      accent: "#EF0027",
      capabilities: { receive: true, balance: false, send: false, swap: false, dapp: true }
    },
    {
      id: "bitcoin-mainnet",
      family: "utxo",
      chainId: "bitcoin-mainnet",
      name: "Bitcoin",
      nativeSymbol: "BTC",
      iconSymbol: "BTC",
      accent: "#F7931A",
      capabilities: { receive: false, balance: false, send: false, swap: false, dapp: false }
    },
    {
      id: "ton-mainnet",
      family: "ton",
      chainId: "ton-mainnet",
      name: "TON",
      nativeSymbol: "TON",
      iconSymbol: "TON",
      accent: "#0098EA",
      capabilities: { receive: false, balance: false, send: false, swap: false, dapp: false }
    }
  ];
  var lastCreatedMnemonic = null;
  var onboardingTab = "create";
  var currentPopupState = createSkeletonState();
  var currentHomeSnapshot = null;
  var popupFeedback = null;
  var currentPopupSettings = {
    theme: "auto",
    currency: "USD",
    language: "English"
  };
  void loadPopupState();
  async function loadPopupState() {
    let state = createSkeletonState();
    let home = null;
    try {
      const [stateResponse, homeResponse, settingsResponse] = await Promise.all([
        chrome.runtime.sendMessage({
          kind: "get_state",
          requestId: createRequestId("popup"),
          surface: "popup",
          origin: null
        }),
        withTimeout(loadExtensionHome(), POPUP_HOME_TIMEOUT_MS, null),
        loadPopupSettings()
      ]);
      if (stateResponse.ok && stateResponse.result) {
        state = stateResponse.result;
      }
      home = homeResponse;
      currentPopupSettings = settingsResponse;
    } catch {
      state = createSkeletonState();
      home = null;
    }
    currentPopupState = state;
    currentHomeSnapshot = home;
    applyPopupTheme(currentPopupSettings.theme);
    root.innerHTML = renderPopup(state, home);
    wirePopupActions();
  }
  function withTimeout(promise, timeoutMs, fallback) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = window.setTimeout(() => {
        if (settled) {
          return;
        }
        settled = true;
        resolve(fallback);
      }, timeoutMs);
      promise.then((value) => {
        if (settled) {
          return;
        }
        settled = true;
        window.clearTimeout(timer);
        resolve(value);
      }).catch(() => {
        if (settled) {
          return;
        }
        settled = true;
        window.clearTimeout(timer);
        resolve(fallback);
      });
    });
  }
  async function loadPopupSettings() {
    try {
      const result = await chrome.storage.local.get(EXTENSION_POPUP_SETTINGS_KEY);
      return normalizePopupSettings(result[EXTENSION_POPUP_SETTINGS_KEY]);
    } catch {
      return normalizePopupSettings(null);
    }
  }
  function normalizePopupSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { theme: "auto", currency: "USD", language: "English" };
    }
    const candidate = value;
    return {
      theme: candidate.theme === "light" || candidate.theme === "dark" || candidate.theme === "auto" ? candidate.theme : "auto",
      currency: typeof candidate.currency === "string" && candidate.currency.trim() ? candidate.currency.trim().slice(0, 8) : "USD",
      language: typeof candidate.language === "string" && candidate.language.trim() ? candidate.language.trim().slice(0, 32) : "English"
    };
  }
  function applyPopupTheme(theme) {
    document.documentElement.dataset.acorusTheme = theme;
  }
  function renderPopupFeedback() {
    if (!popupFeedback) {
      return "";
    }
    return `
    <section id="popup-feedback" class="notice ${escapeHtml(popupFeedback.tone)}">
      ${escapeHtml(popupFeedback.message)}
    </section>
  `;
  }
  function setPopupFeedback(message, tone = "error") {
    popupFeedback = { message, tone };
    const feedback = root.querySelector("#popup-feedback");
    if (feedback) {
      feedback.outerHTML = renderPopupFeedback();
      return;
    }
    root.querySelector(".main")?.insertAdjacentHTML("afterbegin", renderPopupFeedback());
  }
  function clearPopupFeedback() {
    popupFeedback = null;
  }
  async function loadExtensionHome() {
    try {
      const response = await chrome.runtime.sendMessage({
        kind: "get_extension_home",
        requestId: createRequestId("popup_home"),
        surface: "popup"
      });
      return response.ok && response.result ? response.result : null;
    } catch {
      return null;
    }
  }
  function renderPopup(state, home) {
    const vault = state.extensionVaultStatus;
    const selectedProfile = state.walletExposedAccounts.find((profile) => profile.selected) ?? vault.profiles.find((profile) => profile.selected) ?? vault.profiles[0] ?? state.walletExposedAccounts[0] ?? null;
    const activeChain = home?.activeChainId ?? selectedProfile?.chainIds[0] ?? state.activeOriginBridge?.activeChainId ?? 1;
    const activeNetwork = home?.networks.find((network) => String(network.chainId) === String(activeChain));
    const pendingCount = state.proposals.length + state.pendingRequests.length + state.signerUnlockQueue.length;
    const statusLabel = !vault.hasVault ? "Setup" : vault.isUnlocked ? "Unlocked" : "Locked";
    const statusClass = !vault.hasVault ? "setup" : vault.isUnlocked ? "ok" : "locked";
    const statusAction = !vault.hasVault ? "set-onboarding-tab" : vault.isUnlocked ? "lock-extension-wallet" : "focus-unlock-wallet";
    const statusId = !vault.hasVault ? onboardingTab : "vault";
    return `
    <main class="wallet-shell">
      <header class="wallet-header">
        <div class="brand">
          <div class="brand-mark">A</div>
          <div>
            <div class="brand-title">Acorus</div>
            <div class="brand-subtitle">${escapeHtml(selectedProfile?.name ?? "Multichain wallet")}</div>
          </div>
        </div>
        <div class="row">
          <button class="network-pill as-button" type="button" data-action="open-network-panel" data-id="network">
            ${escapeHtml(String(activeChain) === "all" ? "All networks" : activeNetwork?.name ?? chainName(activeChain))} \u25BE
          </button>
          <button class="status-pill as-button ${statusClass}"
                  type="button"
                  data-action="${statusAction}"
                  data-id="${escapeHtml(statusId)}">
            ${statusLabel}
          </button>
          <button class="icon-button" type="button" data-action="open-action-panel" data-id="settings" title="Settings">\u2699</button>
        </div>
      </header>

      <div class="main">
        ${pendingCount > 0 ? renderPromptNotice(state) : ""}
        ${renderPopupFeedback()}
        ${lastCreatedMnemonic ? renderSeedReveal(lastCreatedMnemonic) : ""}
        ${!vault.hasVault ? `${renderNetworkPanel(home)}${renderExtensionActionPanel(state, home)}` : ""}
        ${vault.hasVault ? renderWalletHome(state, selectedProfile, home) : renderOnboarding()}
        ${renderConnectedSites(state)}
        ${renderRecentActivity(state)}
      </div>
    </main>
  `;
  }
  function renderWalletHome(state, selectedProfile, home) {
    const vault = state.extensionVaultStatus;
    const account = selectedProfile?.account ?? "No synced account";
    const unlockedLabel = vault.isUnlocked ? "Unlocked" : "Locked";
    const activeNetwork = home?.networks.find(
      (item) => String(item.chainId) === String(home.activeChainId)
    ) ?? home?.networks[0] ?? null;
    const visibleAssets = home?.assets.filter(
      (asset) => !activeNetwork || String(home?.activeChainId) === "all" || String(asset.chainId) === String(activeNetwork.chainId)
    ).slice(0, 30) ?? [];
    return `
    <section class="account-card">
      <div class="account-row">
        <div>
          <button class="account-name as-button" type="button" data-action="open-account-panel" data-id="account">
            ${escapeHtml(selectedProfile?.name ?? "Main wallet")} \u25BE
          </button>
          <button class="address-pill as-button" type="button" data-copy="${escapeHtml(account)}">
            ${shortAddress(account)} <span>\u29C9</span>
          </button>
        </div>
        <button class="network-pill as-button" type="button" data-action="open-network-panel" data-id="network">
          ${escapeHtml(String(home?.activeChainId) === "all" ? "All networks" : activeNetwork?.name ?? "All networks")} \u25BE
        </button>
      </div>

      <div class="balance">${formatFiat(home?.totalFiatValue)}</div>
      <div class="balance-sub">${unlockedLabel} \xB7 ${state.walletExposureMode === "wallet_backed" ? "Multichain vault active" : "Preview bridge mode"}</div>

      <div class="hero-actions">
        <button class="hero-action" type="button" data-action="open-action-panel" data-id="send">
          <span>\u2197</span>
          <strong>Send</strong>
        </button>
        <button class="hero-action" type="button" data-action="open-action-panel" data-id="receive">
          <span>\u2199</span>
          <strong>Receive</strong>
        </button>
      </div>
      <button class="portfolio-button" type="button" data-open-url="https://24wallet.ru/wallet">
        View portfolio <span>\u2192</span>
      </button>
      <div class="mini-actions">
        ${quickAction("\uFF0B", "Buy", "internal:buy")}
        ${quickAction("\u21C4", "Swap", "internal:swap")}
      </div>
    </section>

    ${renderAccountPanel(state, selectedProfile)}
    ${renderNetworkPanel(home)}
    ${renderExtensionActionPanel(state, home)}

    <section class="panel stack">
      <div class="tabs">
        <span class="tab" data-active="true">Tokens</span>
        <span class="tab">Activity</span>
        <span class="tab">dApps</span>
        <span class="tab">NFT</span>
      </div>
      <div class="row">
        <span class="network-pill">All popular networks</span>
        <span class="small">${home?.assets.length ?? 0} assets</span>
      </div>
      <div class="token-list">
        ${visibleAssets.length ? visibleAssets.map(renderAssetRow).join("") : `<p class="copy">No live assets yet. Add a token or switch network.</p>`}
      </div>
      ${home?.warnings.length ? renderWarnings(home.warnings) : ""}
      <div class="row">
        ${vault.isUnlocked ? `<button class="ghost-button" type="button" data-action="lock-extension-wallet" data-id="vault">Lock wallet</button>` : `<form id="unlock-wallet-form" class="form" style="flex:1">
                <input class="field" name="passcode" placeholder="Passcode" type="password" autocomplete="current-password">
                <button class="primary-button" type="submit">Unlock</button>
                <button class="danger-button" type="button" data-action="reset-extension-wallet" data-id="extension-vault">
                  Reset local wallet
                </button>
              </form>`}
        <button class="ghost-button" type="button" data-open-url="https://24wallet.ru/extension">Open site</button>
      </div>
    </section>
  `;
  }
  function renderAccountPanel(state, selectedProfile) {
    const profiles = state.extensionVaultStatus.profiles.length ? state.extensionVaultStatus.profiles : state.walletExposedAccounts;
    const familyLabels = [
      { family: "evm", label: "EVM Account" },
      { family: "solana", label: "Solana Account" },
      { family: "tron", label: "Tron Account" }
    ];
    return `
    <section class="panel stack" id="account-panel" hidden>
      <div class="row">
        <h2 class="section-title">Accounts</h2>
        <span class="small">${state.extensionVaultStatus.isUnlocked ? "unlocked" : "locked"}</span>
      </div>
      ${familyLabels.map(({ family, label }) => {
      const profile = profiles.find((item) => item.chainFamily === family);
      if (!profile) {
        return renderComingSoonAccount(label);
      }
      return `
          <button class="account-option ${profile.profileId === selectedProfile?.profileId ? "active" : ""}"
                  type="button"
                  data-action="select-wallet-profile"
                  data-id="${escapeHtml(profile.profileId)}">
            <span>
              <strong>${escapeHtml(label)}</strong>
              <small>${escapeHtml(profile.name)} \xB7 ${shortAddress(profile.account)}</small>
            </span>
            <span class="badge">${escapeHtml(profile.chainFamily.toUpperCase())}</span>
          </button>
        `;
    }).join("")}
      ${renderComingSoonAccount("BTC Coming soon")}
      ${renderComingSoonAccount("TON Coming soon")}
    </section>
  `;
  }
  function renderComingSoonAccount(label) {
    return `
    <div class="account-option disabled">
      <span>
        <strong>${escapeHtml(label)}</strong>
        <small>Profile derivation is not enabled yet</small>
      </span>
      <span class="badge muted-badge">Soon</span>
    </div>
  `;
  }
  function renderAssetRow(asset) {
    const assetId = [
      asset.family,
      String(asset.chainId),
      asset.type,
      asset.tokenAddress?.toLowerCase() ?? "native",
      asset.symbol.toUpperCase()
    ].join(":");
    const icon = asset.logoUrl ? `<img src="${escapeHtml(asset.logoUrl)}" alt="" loading="lazy">` : escapeHtml(asset.symbol.slice(0, 4).toUpperCase());
    const balanceText = `${asset.balanceFormatted ?? "0"} ${asset.symbol}`;
    const chainLabel = asset.family === "evm" ? `Chain ${String(asset.chainId)}` : asset.family.toUpperCase();
    return `
    <button class="token-row as-button wide" type="button" data-asset-id="${escapeHtml(assetId)}">
      <div class="token-icon">${icon}</div>
      <div>
        <div class="token-name">${escapeHtml(asset.name)}</div>
        <div class="token-meta">${escapeHtml(chainLabel)} \xB7 ${escapeHtml(balanceText)}</div>
      </div>
      <div class="token-value">${formatFiat(asset.fiatValue)}</div>
    </button>
  `;
  }
  function renderNetworkPanel(home) {
    const networks = home?.networks.length ? home.networks : FALLBACK_NETWORKS;
    const activeChainId = home?.activeChainId ?? "all";
    return `
    <section class="panel stack" id="network-panel" hidden>
      <div class="row">
        <h2 class="section-title">Networks</h2>
        <input class="field compact" id="network-search" placeholder="Search">
      </div>
      ${renderNetworkGroup("All", [
      {
        id: "all",
        family: "all",
        chainId: "all",
        name: "All networks",
        nativeSymbol: "ALL",
        iconSymbol: "ALL",
        accent: "#111827",
        capabilities: { receive: true, balance: true, send: false, swap: false, dapp: false }
      }
    ], activeChainId)}
      <div class="network-grid">
        ${["evm", "solana", "tron", "coming"].map(
      (group) => renderNetworkGroup(
        getNetworkGroupLabel(group),
        getNetworksForGroup(networks, group),
        activeChainId
      )
    ).join("")}
      </div>
    </section>
  `;
  }
  function renderNetworkGroup(label, networks, activeChainId) {
    if (!networks.length) {
      return "";
    }
    return `
    <div class="network-group" data-network-group="${escapeHtml(label.toLowerCase())}">
      <div class="network-group-label">${escapeHtml(label)}</div>
      ${networks.map((network) => renderNetworkCard(network, activeChainId)).join("")}
    </div>
  `;
  }
  function renderNetworkCard(network, activeChainId) {
    const capabilityBadges = Object.entries(network.capabilities).map(([name, enabled]) => `<span class="capability-badge ${enabled ? "on" : "off"}">${escapeHtml(name)}</span>`).join("");
    const chainId = String(network.chainId);
    return `
    <button class="network-card ${chainId === String(activeChainId) ? "active" : ""}"
            type="button"
            data-action="set-active-chain"
            data-id="${escapeHtml(chainId)}"
            data-network-name="${escapeHtml(`${network.name} ${network.nativeSymbol} ${network.family}`.toLowerCase())}">
      <span class="network-dot" style="background:${escapeHtml(network.accent)}"></span>
      <span>
        <strong>${escapeHtml(network.name)}</strong>
        <small>${escapeHtml(network.family.toUpperCase())}</small>
        <span class="capability-row">${capabilityBadges}</span>
      </span>
    </button>
  `;
  }
  function getNetworksForGroup(networks, group) {
    if (group === "coming") {
      return networks.filter((network) => network.family === "utxo" || network.family === "ton");
    }
    return networks.filter((network) => network.family === group);
  }
  function getNetworkGroupLabel(group) {
    switch (group) {
      case "evm":
        return "EVM";
      case "solana":
        return "Solana";
      case "tron":
        return "Tron";
      default:
        return "Coming soon";
    }
  }
  function renderExtensionActionPanel(state, home) {
    return `
    <section class="panel stack" id="action-panel" hidden>
      <div class="row">
        <h2 class="section-title" id="action-title">Action</h2>
        <button class="icon-button" type="button" data-action="close-action-panel" data-id="action">\xD7</button>
      </div>
      <div id="action-content">
        ${renderReceiveComposer(state, home)}
      </div>
    </section>
  `;
  }
  function renderReceiveComposer(state, home) {
    const vault = state.extensionVaultStatus;
    const profiles = vault.profiles.length ? vault.profiles : state.walletExposedAccounts;
    const networks = home?.networks.length ? home.networks : FALLBACK_NETWORKS;
    const selectedNetwork = networks.find(
      (network) => String(network.chainId) === String(home?.activeChainId)
    ) ?? networks[0] ?? null;
    const selectedFamily = selectedNetwork?.family ?? "evm";
    return `
    <div class="form">
      <label class="small">Network</label>
      <select class="field" id="receive-network">
        ${networks.map((network) => `
          <option value="${escapeHtml(String(network.chainId))}" data-family="${escapeHtml(network.family)}" ${String(network.chainId) === String(selectedNetwork?.chainId) ? "selected" : ""}>
            ${escapeHtml(network.name)}
          </option>
        `).join("")}
      </select>
      <div class="receive-box">
        ${renderReceiveAddressRows(profiles, selectedFamily)}
      </div>
      <p class="copy" id="receive-warning">${escapeHtml(buildReceiveWarning(selectedNetwork))}</p>
    </div>
  `;
  }
  function renderReceiveAddressRows(profiles, family) {
    if (family === "utxo" || family === "ton") {
      return `
      <div class="site-row" data-receive-family="${escapeHtml(family)}">
        <div>
          <div class="token-name">${family.toUpperCase()} receive</div>
          <div class="token-meta">Coming soon</div>
        </div>
      </div>
    `;
    }
    const matching = profiles.filter((profile) => profile.chainFamily === family);
    if (!matching.length) {
      return `
      <div class="site-row" data-receive-family="${escapeHtml(family)}">
        <div>
          <div class="token-name">${escapeHtml(family.toUpperCase())} address</div>
          <div class="token-meta">Coming soon</div>
        </div>
      </div>
    `;
    }
    return matching.map((profile) => `
    <div class="site-row" data-receive-family="${escapeHtml(profile.chainFamily)}">
      <div>
        <div class="token-name">${escapeHtml(profile.name)}</div>
        <div class="token-meta">${escapeHtml(profile.chainFamily)} \xB7 ${shortAddress(profile.account)}</div>
      </div>
      <button class="ghost-button" type="button" data-copy="${escapeHtml(profile.account)}">Copy</button>
    </div>
  `).join("");
  }
  function buildReceiveWarning(network) {
    if (!network) {
      return "Select a network before copying a receive address.";
    }
    if (network.family === "utxo" || network.family === "ton") {
      return `${network.name} receive is coming soon in this extension build. Do not send funds here yet.`;
    }
    return `Send only ${network.name} assets to this ${network.family.toUpperCase()} address family. Wrong network can permanently lose funds.`;
  }
  function renderWarnings(warnings) {
    return `
    <section class="notice warning">
      <strong>Network notes</strong>
      <ul>
        ${warnings.slice(0, 4).map((warning) => `<li>${escapeHtml(warning)}</li>`).join("")}
      </ul>
    </section>
  `;
  }
  function renderExtensionPasscodeFields(_formId) {
    return `
    <section class="passcode-setup-card">
      <div class="row">
        <div>
          <strong>Choose your password</strong>
          <p class="copy" style="margin-top:4px">Use any password you want. Acorus never creates one automatically and cannot recover it.</p>
        </div>
      </div>
      <div class="form">
        <input class="field" name="passcode" placeholder="Password, min 8 chars" type="password" autocomplete="new-password">
        <input class="field" name="confirmPasscode" placeholder="Repeat password" type="password" autocomplete="new-password">
        <p class="copy compact-copy">Acorus never creates a password automatically. This password is only used to encrypt and unlock this extension vault.</p>
      </div>
    </section>
  `;
  }
  function renderOnboarding() {
    const activeIsCreate = onboardingTab === "create";
    return `
    <section class="onboarding-card stack">
      <div>
        <h1 style="margin:0;font-size:24px;letter-spacing:-0.03em">
          ${activeIsCreate ? "Create your Wallet" : "Import your Wallet"}
        </h1>
        <p class="copy" style="margin-top:8px">
          Your seed phrase and encrypted vault stay inside this Chrome extension. Set your own password, then create or import.
        </p>
      </div>
      <div class="onboarding-tabs" role="tablist" aria-label="Wallet setup">
        <button class="onboarding-tab" type="button" data-active="${activeIsCreate}" data-action="set-onboarding-tab" data-id="create">
          Create your Wallet
        </button>
        <button class="onboarding-tab" type="button" data-active="${!activeIsCreate}" data-action="set-onboarding-tab" data-id="import">
          Import your Wallet
        </button>
      </div>
      <div class="extension-quick-actions" aria-label="Quick wallet actions">
        <button class="setup-action" type="button" data-action="open-action-panel" data-id="send">
          <span>\u2197</span>
          <strong>Send</strong>
        </button>
        <button class="setup-action" type="button" data-action="open-action-panel" data-id="receive">
          <span>\u2199</span>
          <strong>Receive</strong>
        </button>
      </div>
      ${activeIsCreate ? `<form id="create-wallet-form" class="form">
              <input class="field" name="name" placeholder="Wallet name" value="Main wallet">
              ${renderExtensionPasscodeFields("create-wallet-form")}
              <button class="primary-button" type="submit">Create wallet</button>
            </form>` : `<form id="import-wallet-form" class="form">
          <input class="field" name="name" placeholder="Wallet name" value="Imported wallet">
          <textarea class="field" name="mnemonic" placeholder="Seed phrase" rows="3"></textarea>
          ${renderExtensionPasscodeFields("import-wallet-form")}
          <button class="primary-button" type="submit">Import wallet</button>
        </form>`}
    </section>
  `;
  }
  function renderPromptNotice(state) {
    const signer = state.signerUnlockQueue[0];
    if (signer) {
      return `
      <section class="notice warning">
        <strong>${escapeHtml(getDappRequestKindLabel(signer.kind))}</strong><br>
        ${escapeHtml(signer.summary)}
        <div class="row" style="margin-top:10px">
          ${actionButton("confirm-signer-unlock", signer.id, "Confirm", true)}
          ${actionButton("reject-signer-unlock", signer.id, "Reject", false, true)}
        </div>
      </section>
    `;
    }
    const request = state.pendingRequests[0];
    if (request) {
      const approveLabel = request.kind === "add_chain" || request.kind === "watch_asset" ? "Confirm" : "Review";
      return `
      <section class="notice warning">
        <strong>${escapeHtml(getDappRequestKindLabel(request.kind))} request</strong><br>
        ${escapeHtml(request.origin.title)} wants approval on ${chainName(request.chainId)}.<br>
        ${renderApprovalDetailCard(request)}
        <div class="row" style="margin-top:10px">
          ${actionButton("approve-request", request.id, approveLabel, true)}
          ${actionButton("reject-request", request.id, "Reject", false, true)}
        </div>
      </section>
    `;
    }
    const proposal = state.proposals[0];
    if (!proposal) {
      return "";
    }
    return `
    <section class="notice warning">
      <strong>Connect request</strong><br>
      ${escapeHtml(proposal.origin.title)} wants to see your selected account.
      <div class="row" style="margin-top:10px">
        ${actionButton("approve-proposal", proposal.id, "Connect", true)}
        ${actionButton("reject-proposal", proposal.id, "Reject", false, true)}
      </div>
    </section>
  `;
  }
  function renderApprovalDetailCard(request) {
    const details = request.reviewDetails;
    if (details?.kind === "add_chain") {
      return `
      <div class="approval-card">
        <div class="row"><strong>Add Network</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Name</dt><dd>${escapeHtml(details.chainName || "Unknown network")}</dd></div>
          <div><dt>Chain ID</dt><dd>${escapeHtml(String(details.chainIdDecimal ?? "n/a"))} / ${escapeHtml(details.chainIdHex || "n/a")}</dd></div>
          <div><dt>RPC</dt><dd>${escapeHtml(details.rpcHostname)}</dd></div>
          <div><dt>Explorer</dt><dd>${escapeHtml(details.explorerHostname)}</dd></div>
          <div><dt>Symbol</dt><dd>${escapeHtml(details.nativeSymbol || "n/a")}</dd></div>
        </dl>
      </div>
    `;
    }
    if (details?.kind === "watch_asset") {
      return `
      <div class="approval-card">
        <div class="row"><strong>Watch Asset</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Symbol</dt><dd>${escapeHtml(details.symbol || "UNKNOWN")}</dd></div>
          <div><dt>Address</dt><dd>${escapeHtml(shortAddress(details.tokenAddress))}</dd></div>
          <div><dt>Decimals</dt><dd>${escapeHtml(String(details.decimals ?? "n/a"))}</dd></div>
          <div><dt>Chain</dt><dd>${escapeHtml(String(details.chainId ?? "n/a"))}</dd></div>
        </dl>
      </div>
    `;
    }
    if (details?.kind === "multichain_send") {
      const ataWarning = details.ataWarning ? `<div><dt>ATA</dt><dd>${escapeHtml(details.ataWarning)}</dd></div>` : "";
      const tokenAddress = details.tokenAddress ? `<div><dt>Mint</dt><dd>${escapeHtml(shortAddress(details.tokenAddress))}</dd></div>` : "";
      const fee = details.estimatedFeeFormatted ? `<div><dt>Estimated fee</dt><dd>${escapeHtml(details.estimatedFeeFormatted)} SOL</dd></div>` : "";
      return `
      <div class="approval-card">
        <div class="row"><strong>Send ${escapeHtml(details.assetSymbol)}</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Network</dt><dd>${escapeHtml(details.family.toUpperCase())} \xB7 ${escapeHtml(String(details.chainId ?? "n/a"))}</dd></div>
          <div><dt>Asset</dt><dd>${escapeHtml(details.assetType ?? "native")} \xB7 ${escapeHtml(details.assetSymbol)}</dd></div>
          ${tokenAddress}
          <div><dt>From</dt><dd>${escapeHtml(shortAddress(details.fromAddress))}</dd></div>
          <div><dt>To</dt><dd>${escapeHtml(shortAddress(details.toAddress))}</dd></div>
          <div><dt>Amount</dt><dd>${escapeHtml(details.amountFormatted)} ${escapeHtml(details.assetSymbol)}</dd></div>
          ${fee}
          ${ataWarning}
        </dl>
      </div>
    `;
    }
    if (details?.kind === "token_approval") {
      return `
      <div class="approval-card">
        <div class="row"><strong>Approve ${escapeHtml(details.tokenSymbol)}</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Network</dt><dd>${escapeHtml(String(details.chainId ?? "n/a"))}</dd></div>
          <div><dt>Token</dt><dd>${escapeHtml(shortAddress(details.tokenAddress))}</dd></div>
          <div><dt>Spender</dt><dd>${escapeHtml(shortAddress(details.spender))}</dd></div>
          <div><dt>Amount</dt><dd>${escapeHtml(details.approvalMode === "infinite" ? "Unlimited" : details.amountFormatted ?? details.amountRaw)}</dd></div>
          ${details.currentAllowanceFormatted ? `<div><dt>Current allowance</dt><dd>${escapeHtml(details.currentAllowanceFormatted)}</dd></div>` : ""}
          ${details.requiredAllowanceFormatted ? `<div><dt>Required allowance</dt><dd>${escapeHtml(details.requiredAllowanceFormatted)}</dd></div>` : ""}
          <div><dt>Mode</dt><dd>${escapeHtml(details.approvalMode)}</dd></div>
        </dl>
      </div>
    `;
    }
    if (details?.kind === "evm_swap") {
      return `
      <div class="approval-card">
        <div class="row"><strong>0x Swap</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Network</dt><dd>${escapeHtml(String(details.chainId ?? "n/a"))}</dd></div>
          <div><dt>Sell</dt><dd>${escapeHtml(details.sellAmountFormatted ?? details.sellAmountRaw)} ${escapeHtml(details.sellTokenSymbol)}</dd></div>
          <div><dt>Buy</dt><dd>${escapeHtml(details.buyAmountFormatted ?? details.buyAmountRaw)} ${escapeHtml(details.buyTokenSymbol)}</dd></div>
          <div><dt>Min received</dt><dd>${escapeHtml(details.minBuyAmountFormatted ?? details.minBuyAmountRaw ?? "n/a")}</dd></div>
          <div><dt>Route</dt><dd>${escapeHtml(details.routeLabel)}</dd></div>
          <div><dt>Contract</dt><dd>${escapeHtml(shortAddress(details.contractAddress))}</dd></div>
          <div><dt>Value</dt><dd>${escapeHtml(details.value)}</dd></div>
          ${details.expiresAt ? `<div><dt>Expires</dt><dd>${escapeHtml(new Date(details.expiresAt).toLocaleTimeString())}</dd></div>` : ""}
        </dl>
      </div>
    `;
    }
    if (details?.kind === "universal_swap") {
      return `
      <div class="approval-card">
        <div class="row"><strong>${escapeHtml(details.provider)} Swap Route</strong>${renderRiskLabels(details.riskLabels)}</div>
        <dl>
          <div><dt>Network</dt><dd>${escapeHtml(String(details.chainId ?? "multi"))}</dd></div>
          <div><dt>Sell</dt><dd>${escapeHtml(details.sellAmountFormatted ?? details.sellAmountRaw)} ${escapeHtml(details.fromLabel)}</dd></div>
          <div><dt>Buy</dt><dd>${escapeHtml(details.buyAmountFormatted ?? details.buyAmountRaw ?? "route estimate")} ${escapeHtml(details.toLabel)}</dd></div>
          <div><dt>Route</dt><dd>${escapeHtml(details.routeLabel)}</dd></div>
          <div><dt>Execution</dt><dd>${escapeHtml(details.executionStatus === "review_only" ? "Review only" : "Disabled")}</dd></div>
          ${details.slippageBps !== null && details.slippageBps !== void 0 ? `<div><dt>Slippage</dt><dd>${escapeHtml(String(details.slippageBps / 100))}%</dd></div>` : ""}
          ${details.expiresAt ? `<div><dt>Expires</dt><dd>${escapeHtml(new Date(details.expiresAt).toLocaleTimeString())}</dd></div>` : ""}
        </dl>
      </div>
    `;
    }
    return `<span>${escapeHtml(request.summary)}</span>`;
  }
  function renderRiskLabels(labels) {
    return `<span class="risk-labels">${labels.map((label) => `<span>${escapeHtml(label)}</span>`).join("")}</span>`;
  }
  function renderSeedReveal(mnemonic) {
    return `
    <section class="notice warning">
      <strong>Save these words offline now.</strong>
      <div class="seed-grid" style="margin-top:10px">
        ${mnemonic.split(" ").map((word, index) => `<div class="seed-word"><span class="muted">${index + 1}.</span> ${escapeHtml(word)}</div>`).join("")}
      </div>
      <button class="ghost-button" data-action="clear-created-seed" data-id="seed" style="margin-top:10px" type="button">I saved it</button>
    </section>
  `;
  }
  function renderConnectedSites(state) {
    const activeSessions = state.sessions.filter((session) => session.status === "active");
    if (!activeSessions.length && !state.proposals.length) {
      return `
      <section class="panel">
        <h2 class="section-title">Connected sites</h2>
        <p class="copy">No dApps connected yet. Open Acorus or another dApp and connect through the extension.</p>
      </section>
    `;
    }
    return `
    <section class="panel stack">
      <h2 class="section-title">Connected sites</h2>
      ${activeSessions.slice(0, 3).map((session) => `
          <div class="site-row">
            <div>
              <div class="token-name">${escapeHtml(session.origin.title)}</div>
              <div class="token-meta">${escapeHtml(getDappConnectionTransportLabel(session.transport))} \xB7 ${escapeHtml(String(session.activeChainId ?? "multi"))}</div>
            </div>
            ${actionButton("revoke-session", session.id, "Disconnect", false, true)}
          </div>
        `).join("")}
    </section>
  `;
  }
  function renderRecentActivity(state) {
    const latest = state.activityLog.slice(0, 4);
    return `
    <section class="panel stack">
      <h2 class="section-title">Recent activity</h2>
      ${latest.length ? latest.map((item) => `
          <div class="site-row">
            <div>
              <div class="token-name">${escapeHtml(item.kind.replace(/_/gu, " "))}</div>
              <div class="token-meta">${escapeHtml((item.amountFormatted ?? `${item.sellTokenSymbol ?? item.tokenSymbol ?? ""}${item.buyAmountFormatted ? ` -> ${item.buyAmountFormatted} ${item.buyTokenSymbol ?? ""}` : ""}`.trim()) || item.account)}</div>
            </div>
            <span class="badge">${escapeHtml(item.status)}</span>
          </div>
        `).join("") : `<p class="copy">No recent wallet activity yet.</p>`}
      <button class="portfolio-button compact-portfolio" type="button" data-action="open-action-panel" data-id="activity">
        View all activity <span>\u2192</span>
      </button>
    </section>
  `;
  }
  function openActionPanel(targetId) {
    const panel = root.querySelector("#action-panel");
    const title = root.querySelector("#action-title");
    const content = root.querySelector("#action-content");
    if (!panel || !title || !content) {
      return;
    }
    panel.hidden = false;
    title.textContent = `${targetId[0]?.toUpperCase() ?? ""}${targetId.slice(1)}`;
    content.innerHTML = renderActionContent(targetId);
    wireInlineButtons(content);
    wireReceiveNetworkSelector(content);
    wireSendForm(content);
    wireEvmSwapForm(content);
    wireExtensionSettingsForm(content);
  }
  function wirePopupActions() {
    wireWalletForms();
    wireReceiveNetworkSelector();
    wireNetworkSearch();
    const buttons = root.querySelectorAll("[data-action], [data-open-url], [data-copy]");
    buttons.forEach((button) => {
      button.addEventListener("click", async () => {
        const copyValue = button.dataset.copy;
        if (copyValue) {
          await navigator.clipboard.writeText(copyValue);
          return;
        }
        const openUrl = button.dataset.openUrl;
        if (openUrl) {
          await chrome.tabs.create({ url: openUrl.startsWith("http") ? openUrl : chrome.runtime.getURL(openUrl) });
          return;
        }
        const action = button.dataset.action;
        const targetId = button.dataset.id;
        const extra = button.dataset.extra;
        if (action === "open-network-panel") {
          root.querySelector("#network-panel")?.toggleAttribute("hidden");
          return;
        }
        if (action === "open-account-panel") {
          root.querySelector("#account-panel")?.toggleAttribute("hidden");
          return;
        }
        if (action === "set-onboarding-tab" && (targetId === "create" || targetId === "import")) {
          onboardingTab = targetId;
          clearPopupFeedback();
          root.innerHTML = renderPopup(currentPopupState, currentHomeSnapshot);
          wirePopupActions();
          return;
        }
        if (action === "focus-unlock-wallet") {
          const passcodeInput = root.querySelector('#unlock-wallet-form input[name="passcode"]');
          if (passcodeInput) {
            passcodeInput.focus();
            passcodeInput.scrollIntoView({ block: "center" });
            return;
          }
          onboardingTab = "import";
          root.innerHTML = renderPopup(currentPopupState, currentHomeSnapshot);
          wirePopupActions();
          return;
        }
        if (action === "set-active-chain" && targetId) {
          await chrome.runtime.sendMessage({
            kind: "set_active_extension_chain",
            requestId: createRequestId("popup"),
            surface: "popup",
            chainId: /^\d+$/u.test(targetId) ? Number(targetId) : targetId
          });
          await loadPopupState();
          return;
        }
        if (action === "open-action-panel" && targetId) {
          openActionPanel(targetId);
          return;
        }
        if (action === "close-action-panel") {
          const panel = root.querySelector("#action-panel");
          if (panel) {
            panel.hidden = true;
          }
          return;
        }
        if (action === "clear-created-seed") {
          lastCreatedMnemonic = null;
          await loadPopupState();
          return;
        }
        if (action === "lock-extension-wallet") {
          await chrome.runtime.sendMessage({
            kind: "lock_extension_wallet",
            requestId: createRequestId("popup"),
            surface: "popup"
          });
          await loadPopupState();
          return;
        }
        if (action === "reset-extension-wallet") {
          if (button.dataset.confirmed !== "true") {
            button.dataset.confirmed = "true";
            button.textContent = "Click again to reset";
            setPopupFeedback(
              "Reset removes only this browser profile's encrypted extension vault. Your assets remain on-chain, but you need your seed phrase to restore access.",
              "warning"
            );
            window.setTimeout(() => {
              button.dataset.confirmed = "false";
              button.textContent = "Reset local extension wallet";
            }, 6e3);
            return;
          }
          await chrome.runtime.sendMessage({
            kind: "reset_extension_wallet",
            requestId: createRequestId("popup"),
            surface: "popup"
          });
          lastCreatedMnemonic = null;
          clearPopupFeedback();
          await loadPopupState();
          return;
        }
        if (!action || !targetId) {
          return;
        }
        button.disabled = true;
        try {
          await sendAction(action, targetId, extra);
        } finally {
          await loadPopupState();
        }
      });
    });
  }
  function wireNetworkSearch(scope = root) {
    scope.querySelector("#network-search")?.addEventListener("input", (event) => {
      const query = event.currentTarget.value.trim().toLowerCase();
      filterNetworkCards(scope, query);
    });
  }
  function wireExtensionSettingsForm(scope = root) {
    const form = scope.querySelector("#extension-settings-form");
    if (!form) {
      return;
    }
    form.querySelectorAll('input[name="theme"]').forEach((input) => {
      input.addEventListener("change", () => {
        if (!input.checked) {
          return;
        }
        const nextTheme = normalizePopupSettings({
          ...currentPopupSettings,
          theme: input.value
        }).theme;
        applyPopupTheme(nextTheme);
        form.querySelectorAll(".theme-segment label").forEach((label) => {
          const radio = label.querySelector('input[name="theme"]');
          label.dataset.active = String(radio?.checked ?? false);
        });
      });
    });
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const next = normalizePopupSettings({
        theme: String(formData.get("theme") ?? currentPopupSettings.theme),
        currency: String(formData.get("currency") ?? currentPopupSettings.currency),
        language: String(formData.get("language") ?? currentPopupSettings.language)
      });
      await chrome.storage.local.set({ [EXTENSION_POPUP_SETTINGS_KEY]: next });
      currentPopupSettings = next;
      applyPopupTheme(next.theme);
      const status = form.querySelector("#extension-settings-status");
      if (status) {
        status.textContent = "Settings saved.";
      }
    });
  }
  function filterNetworkCards(scope, query) {
    scope.querySelectorAll(".network-card").forEach((card) => {
      const label = card.dataset.networkName ?? card.textContent?.toLowerCase() ?? "";
      card.hidden = Boolean(query) && !label.includes(query);
    });
  }
  function wireReceiveNetworkSelector(scope = root) {
    scope.querySelector("#receive-network")?.addEventListener("change", (event) => {
      const select = event.currentTarget;
      const selected = select.selectedOptions[0];
      const family = selected?.dataset.family ?? "evm";
      const networks = currentHomeSnapshot?.networks ?? [];
      const network = networks.find((item) => String(item.chainId) === select.value) ?? null;
      const profiles = currentPopupState.extensionVaultStatus.profiles.length ? currentPopupState.extensionVaultStatus.profiles : currentPopupState.walletExposedAccounts;
      const box = scope.querySelector(".receive-box");
      const warning = scope.querySelector("#receive-warning");
      if (box) {
        box.innerHTML = renderReceiveAddressRows(profiles, family);
        wireInlineButtons(box);
      }
      if (warning) {
        warning.textContent = buildReceiveWarning(network);
      }
    });
  }
  function wireSendForm(scope = root) {
    const form = scope.querySelector("#solana-send-form");
    if (!form) {
      return;
    }
    const networkSelect = form.querySelector("#send-network");
    const note = form.querySelector("#send-support-note");
    const button = form.querySelector("button[type='submit']");
    const updateSupport = () => {
      const family = networkSelect?.selectedOptions[0]?.dataset.family ?? "";
      const supported = family === "solana";
      if (note) {
        note.textContent = supported ? "Solana send is live after explicit popup confirmation." : "Send execution for this network is coming soon.";
      }
      if (button) {
        button.disabled = !supported;
      }
    };
    networkSelect?.addEventListener("change", updateSupport);
    updateSupport();
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const assetSelect = form.querySelector("#send-asset");
      const assetOption = assetSelect?.selectedOptions[0] ?? null;
      const response = await chrome.runtime.sendMessage({
        kind: "queue_solana_send",
        requestId: createRequestId("popup_solana_send"),
        surface: "popup",
        toAddress: String(formData.get("toAddress") ?? ""),
        amountFormatted: String(formData.get("amountFormatted") ?? ""),
        assetType: assetOption?.dataset.assetType === "spl" ? "spl" : "native",
        tokenAddress: assetOption?.dataset.tokenAddress || null,
        symbol: assetOption?.dataset.symbol || "SOL",
        decimals: assetOption?.dataset.decimals ? Number(assetOption.dataset.decimals) : 9,
        balanceRaw: assetOption?.dataset.balanceRaw || null
      });
      if (!response.ok) {
        setPopupFeedback(response.error?.message ?? "Unable to queue Solana send.");
        return;
      }
      clearPopupFeedback();
      await loadPopupState();
    });
  }
  function wireEvmSwapForm(scope = root) {
    const form = scope.querySelector("#evm-swap-form");
    if (!form) {
      return;
    }
    const chainSelect = form.querySelector("#swap-chain");
    const sellSelect = form.querySelector("#swap-sell-token");
    const buySelect = form.querySelector("#swap-buy-token");
    const result = form.querySelector("#evm-swap-result");
    chainSelect?.addEventListener("change", () => {
      const assets = getEvmSwapAssets(chainSelect.value);
      if (sellSelect) {
        sellSelect.innerHTML = assets.map((asset) => renderSwapAssetOption(asset)).join("");
      }
      if (buySelect) {
        buySelect.innerHTML = assets.map((asset, index) => renderSwapAssetOption(asset, index === Math.min(1, assets.length - 1))).join("");
      }
      if (result) {
        result.innerHTML = "";
      }
    });
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!result || !sellSelect || !buySelect || !chainSelect) {
        return;
      }
      const evmProfile = currentPopupState.extensionVaultStatus.profiles.find((profile) => profile.chainFamily === "evm") ?? currentPopupState.walletExposedAccounts.find((profile) => profile.chainFamily === "evm") ?? null;
      if (!evmProfile) {
        result.innerHTML = `<p class="copy">Create or import an EVM account before swapping.</p>`;
        return;
      }
      const formData = new FormData(form);
      const amountRaw = String(formData.get("amountRaw") ?? "").trim();
      const slippageBps = Number(formData.get("slippageBps") ?? 50);
      result.innerHTML = `<p class="copy">Fetching 0x quote...</p>`;
      try {
        const quote = await fetchEvmSwapQuote({
          chainId: Number(chainSelect.value),
          sellToken: sellSelect.value,
          buyToken: buySelect.value,
          sellAmount: amountRaw,
          taker: evmProfile.account,
          slippageBps
        });
        result.innerHTML = renderEvmSwapQuotePreview(quote, slippageBps);
        wireEvmSwapQuoteButtons(result, quote, slippageBps);
      } catch (error) {
        result.innerHTML = `<p class="copy">${escapeHtml(error instanceof Error ? error.message : "Unable to fetch quote.")}</p>`;
      }
    });
  }
  async function fetchEvmSwapQuote(input) {
    const params = new URLSearchParams({
      chainId: String(input.chainId),
      sellToken: input.sellToken,
      buyToken: input.buyToken,
      sellAmount: input.sellAmount,
      taker: input.taker,
      slippageBps: String(input.slippageBps)
    });
    for (const base of EXTENSION_SWAP_API_BASES) {
      try {
        const response = await fetch(`${base}/api/swap/evm/0x/quote?${params.toString()}`);
        const payload = await response.json().catch(() => null);
        if (response.ok && payload?.provider === "0x") {
          return payload;
        }
        if (payload?.error === "swap_provider_not_configured") {
          throw new Error("0x provider is not configured on the backend yet.");
        }
      } catch (error) {
        if (error instanceof Error && error.message.includes("0x provider")) {
          throw error;
        }
      }
    }
    throw new Error("0x quote API is unavailable.");
  }
  function renderEvmSwapQuotePreview(quote, slippageBps) {
    const sellFormatted = shortenFormattedEvmTokenAmount(
      quote.sellAmountRaw,
      quote.sellToken.decimals
    );
    const buyFormatted = shortenFormattedEvmTokenAmount(
      quote.buyAmountRaw,
      quote.buyToken.decimals
    );
    const minBuyFormatted = quote.minBuyAmountRaw ? shortenFormattedEvmTokenAmount(quote.minBuyAmountRaw, quote.buyToken.decimals) : "n/a";
    const approval = quote.approvalRequired && quote.approval ? `
      <label class="small" style="display:flex;align-items:center;gap:8px">
        <span>Approval mode</span>
        <select id="evm-approval-mode">
          <option value="exact">Exact</option>
          <option value="infinite">Infinite</option>
        </select>
      </label>
      <button class="ghost-button" type="button" id="evm-approve-token">Approve ${escapeHtml(quote.sellToken.symbol)}</button>
    ` : "";
    return `
    <div class="approval-card">
      <div class="row"><strong>0x quote</strong><span class="badge">${escapeHtml(quote.routeSummary.label)}</span></div>
      <dl>
        <div><dt>You pay</dt><dd>${escapeHtml(sellFormatted)} ${escapeHtml(quote.sellToken.symbol)}</dd></div>
        <div><dt>You receive</dt><dd>${escapeHtml(buyFormatted)} ${escapeHtml(quote.buyToken.symbol)}</dd></div>
        <div><dt>Min received</dt><dd>${escapeHtml(minBuyFormatted)} ${escapeHtml(quote.buyToken.symbol)}</dd></div>
        <div><dt>Slippage</dt><dd>${escapeHtml(String(slippageBps / 100))}%</dd></div>
        <div><dt>Gas</dt><dd>${escapeHtml(quote.gas ?? "estimate unavailable")}</dd></div>
        ${quote.approvalRequired && quote.approval ? `<div><dt>Allowance</dt><dd>${escapeHtml(quote.approval.currentAllowanceRaw ? shortenFormattedEvmTokenAmount(quote.approval.currentAllowanceRaw, quote.sellToken.decimals) : "0")} / ${escapeHtml(shortenFormattedEvmTokenAmount(quote.approval.requiredAllowanceRaw ?? quote.sellAmountRaw, quote.sellToken.decimals))} ${escapeHtml(quote.sellToken.symbol)}</dd></div>` : ""}
      </dl>
      ${quote.warnings.length ? `<p class="copy">${quote.warnings.map(escapeHtml).join(" ")}</p>` : ""}
      <div class="row" style="margin-top:10px">
        ${approval}
        <button class="primary-button" type="button" id="evm-review-swap">Review swap</button>
      </div>
    </div>
  `;
  }
  function wireEvmSwapQuoteButtons(scope, quote, slippageBps) {
    scope.querySelector("#evm-approve-token")?.addEventListener("click", async () => {
      if (!quote.approval) {
        return;
      }
      const approvalMode = scope.querySelector("#evm-approval-mode")?.value === "infinite" ? "infinite" : "exact";
      const response = await chrome.runtime.sendMessage({
        kind: "queue_evm_approve_token",
        requestId: createRequestId("popup_evm_approve"),
        surface: "popup",
        chainId: quote.chainId,
        tokenAddress: quote.approval.tokenAddress,
        tokenSymbol: quote.sellToken.symbol,
        tokenDecimals: quote.sellToken.decimals,
        spender: quote.approval.spender,
        amountRaw: quote.approval.requiredAllowanceRaw ?? quote.sellAmountRaw,
        amountFormatted: shortenFormattedEvmTokenAmount(
          quote.approval.requiredAllowanceRaw ?? quote.sellAmountRaw,
          quote.sellToken.decimals
        ),
        currentAllowanceRaw: quote.approval.currentAllowanceRaw ?? null,
        requiredAllowanceRaw: quote.approval.requiredAllowanceRaw ?? quote.sellAmountRaw,
        approvalMode
      });
      if (!response.ok) {
        setPopupFeedback(response.error?.message ?? "Unable to queue token approval.");
      } else {
        clearPopupFeedback();
        await loadPopupState();
      }
    });
    scope.querySelector("#evm-review-swap")?.addEventListener("click", async () => {
      const response = await chrome.runtime.sendMessage({
        kind: "queue_evm_swap_approval",
        requestId: createRequestId("popup_evm_swap"),
        surface: "popup",
        quote,
        slippageBps
      });
      if (!response.ok) {
        setPopupFeedback(response.error?.message ?? "Unable to queue swap.");
      } else {
        clearPopupFeedback();
        await loadPopupState();
      }
    });
  }
  function wireInlineButtons(scope) {
    scope.querySelectorAll("[data-action], [data-open-url], [data-copy]").forEach((button) => {
      button.addEventListener("click", async () => {
        const copyValue = button.dataset.copy;
        if (copyValue) {
          await navigator.clipboard.writeText(copyValue);
          return;
        }
        const openUrl = button.dataset.openUrl;
        if (openUrl) {
          await chrome.tabs.create({ url: openUrl.startsWith("http") ? openUrl : chrome.runtime.getURL(openUrl) });
          return;
        }
        const action = button.dataset.action;
        const targetId = button.dataset.id;
        if (action === "close-action-panel") {
          const panel = root.querySelector("#action-panel");
          if (panel) {
            panel.hidden = true;
          }
          return;
        }
        if (action === "open-action-panel" && targetId) {
          openActionPanel(targetId);
        }
      });
    });
  }
  function validatePopupPasscode(form) {
    const formData = new FormData(form);
    const passcode = String(formData.get("passcode") ?? "").trim();
    const confirmPasscode = String(formData.get("confirmPasscode") ?? "").trim();
    if (passcode.length < 8) {
      return "Choose a wallet password with at least 8 characters.";
    }
    if (passcode !== confirmPasscode) {
      return "Password confirmation does not match.";
    }
    return null;
  }
  function wireWalletForms() {
    root.querySelector("#unlock-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const response = await chrome.runtime.sendMessage({
        kind: "unlock_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        passcode: String(formData.get("passcode") ?? "")
      });
      if (!response.ok) {
        setPopupFeedback(response.error?.message ?? "Unable to unlock wallet.");
        return;
      }
      clearPopupFeedback();
      await loadPopupState();
    });
    root.querySelector("#create-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const passcodeError = validatePopupPasscode(form);
      if (passcodeError) {
        setPopupFeedback(passcodeError);
        return;
      }
      const formData = new FormData(form);
      const response = await chrome.runtime.sendMessage({
        kind: "create_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        name: String(formData.get("name") ?? "Main wallet"),
        passcode: String(formData.get("passcode") ?? "").trim()
      });
      if (response.ok && response.result) {
        const result = response.result;
        lastCreatedMnemonic = result.mnemonic ?? null;
        clearPopupFeedback();
      } else {
        lastCreatedMnemonic = null;
        setPopupFeedback(response.error?.message ?? "Unable to create wallet.");
        return;
      }
      await loadPopupState();
    });
    root.querySelector("#import-wallet-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const passcodeError = validatePopupPasscode(form);
      if (passcodeError) {
        setPopupFeedback(passcodeError);
        return;
      }
      const formData = new FormData(form);
      const response = await chrome.runtime.sendMessage({
        kind: "import_extension_wallet",
        requestId: createRequestId("popup"),
        surface: "popup",
        name: String(formData.get("name") ?? "Imported wallet"),
        mnemonic: String(formData.get("mnemonic") ?? ""),
        passcode: String(formData.get("passcode") ?? "").trim()
      });
      if (!response.ok) {
        setPopupFeedback(response.error?.message ?? "Unable to import wallet.");
        return;
      }
      clearPopupFeedback();
      await loadPopupState();
    });
  }
  async function sendAction(action, targetId, extra) {
    if (action === "approve-proposal") {
      await chrome.runtime.sendMessage({
        kind: "approve_proposal",
        requestId: createRequestId("popup"),
        surface: "popup",
        proposalId: targetId
      });
      return;
    }
    if (action === "reject-proposal") {
      await chrome.runtime.sendMessage({
        kind: "reject_proposal",
        requestId: createRequestId("popup"),
        surface: "popup",
        proposalId: targetId
      });
      return;
    }
    if (action === "approve-request") {
      await chrome.runtime.sendMessage({
        kind: "approve_request",
        requestId: createRequestId("popup"),
        surface: "popup",
        requestIdTarget: targetId
      });
      return;
    }
    if (action === "reject-request") {
      await chrome.runtime.sendMessage({
        kind: "reject_request",
        requestId: createRequestId("popup"),
        surface: "popup",
        requestIdTarget: targetId
      });
      return;
    }
    if (action === "revoke-session") {
      await chrome.runtime.sendMessage({
        kind: "revoke_session",
        requestId: createRequestId("popup"),
        surface: "popup",
        sessionId: targetId
      });
      return;
    }
    if (action === "select-wallet-profile") {
      await chrome.runtime.sendMessage({
        kind: "select_wallet_profile",
        requestId: createRequestId("popup"),
        surface: "popup",
        profileId: targetId
      });
      return;
    }
    if (action === "set-session-account" && extra) {
      await chrome.runtime.sendMessage({
        kind: "set_session_account",
        requestId: createRequestId("popup"),
        surface: "popup",
        sessionId: targetId,
        profileId: extra
      });
      return;
    }
    if (action === "confirm-signer-unlock") {
      await chrome.runtime.sendMessage({
        kind: "confirm_signer_unlock",
        requestId: createRequestId("popup"),
        surface: "popup",
        intentId: targetId
      });
      return;
    }
    if (action === "reject-signer-unlock") {
      await chrome.runtime.sendMessage({
        kind: "reject_signer_unlock",
        requestId: createRequestId("popup"),
        surface: "popup",
        intentId: targetId
      });
    }
  }
  function quickAction(icon, label, target) {
    if (target.startsWith("internal:")) {
      return `
      <button class="quick-action" type="button" data-action="open-action-panel" data-id="${escapeHtml(target.replace("internal:", ""))}">
        <span>${icon}</span>
        <span>${escapeHtml(label)}</span>
      </button>
    `;
    }
    return `
    <button class="quick-action" type="button" data-open-url="https://24wallet.ru${target}">
      <span>${icon}</span>
      <span>${escapeHtml(label)}</span>
    </button>
  `;
  }
  function renderActionContent(target) {
    switch (target) {
      case "buy":
        return `
        <div class="form">
          <p class="copy">Buy crypto through approved external on-ramp providers. Acorus does not custody fiat or sell crypto.</p>
          <button class="primary-button" type="button" data-open-url="https://24wallet.ru/buy">Open Buy</button>
        </div>
      `;
      case "swap":
        return renderEvmSwapComposer();
      case "send":
        return renderSendComposer();
      case "activity":
        return renderActivityComposer(currentPopupState);
      case "settings":
        return renderSettingsComposer();
      case "receive":
      default:
        return renderReceiveComposer(currentPopupState, currentHomeSnapshot);
    }
  }
  function renderActivityComposer(state) {
    const items = state.activityLog.slice(0, 18);
    return `
    <div class="settings-sheet">
      <button class="settings-back as-button" type="button" data-action="close-action-panel" data-id="activity">\u2190 Activity</button>
      <div class="settings-section-label">Recent wallet activity</div>
      ${items.length ? items.map((item) => `
          <div class="settings-row activity-row">
            <span class="settings-icon">${escapeHtml(activityIcon(item.kind))}</span>
            <span>
              <span class="settings-label">${escapeHtml(item.kind.replace(/_/gu, " "))}</span>
              <span class="token-meta">
                ${escapeHtml((item.amountFormatted ?? `${item.sellTokenSymbol ?? item.tokenSymbol ?? ""}${item.buyAmountFormatted ? ` -> ${item.buyAmountFormatted} ${item.buyTokenSymbol ?? ""}` : ""}`.trim()) || item.account)}
              </span>
            </span>
            <span class="badge">${escapeHtml(item.status)}</span>
          </div>
        `).join("") : `<p class="copy">No approvals, sends, swaps, or dApp sessions have been recorded in this extension yet.</p>`}
      <button class="ghost-button" type="button" data-action="close-action-panel" data-id="activity">Back to wallet</button>
    </div>
  `;
  }
  function activityIcon(kind) {
    if (kind.includes("swap")) {
      return "\u21C4";
    }
    if (kind.includes("send")) {
      return "\u2197";
    }
    if (kind.includes("approval")) {
      return "\u2713";
    }
    if (kind.includes("sign")) {
      return "\u270E";
    }
    return "\u2022";
  }
  function renderSettingsComposer() {
    const settings = currentPopupSettings;
    return `
    <form class="settings-sheet" id="extension-settings-form">
      <button class="settings-back as-button" type="button" data-action="close-action-panel" data-id="settings">\u2190 Settings</button>
      <div class="settings-section-label">Preferences</div>
      ${renderSettingsRow("\u25D0", "Theme", renderThemeSegment(settings.theme))}
      ${renderSettingsRow("\u25C9", "Display currency", renderSettingsSelect(
      "currency",
      settings.currency,
      POPUP_CURRENCIES.map((currency) => ({ label: currency, value: currency }))
    ))}
      ${renderSettingsRow("\u6587", "Language", renderSettingsSelect(
      "language",
      settings.language,
      POPUP_LANGUAGES.map((language) => ({ label: language, value: language }))
    ))}
      ${renderSettingsRow("\u25AE", "Balances and activity", `<button class="settings-link" type="button" data-action="open-action-panel" data-id="activity">Open \u203A</button>`)}
      <div class="settings-section-label">Security and privacy</div>
      ${renderSettingsRow("\u2301", "Allow analytics", `<span class="toggle on"><span></span></span>`)}
      <div class="settings-section-label">Developer tools</div>
      ${renderSettingsRow("\u25A4", "App data", `<span>\u203A</span>`)}
      ${renderSettingsRow("\u2692", "Testnet mode", `<span class="toggle"><span></span></span>`)}
      <p class="copy" id="extension-settings-status">Theme, currency, and language are stored only in this browser profile.</p>
      <button class="primary-button" type="submit">Save settings</button>
      <button class="ghost-button" type="button" data-open-url="options.html">Open provider diagnostics</button>
    </form>
  `;
  }
  function renderThemeSegment(theme) {
    return `
    <span class="segmented theme-segment">
      ${["auto", "light", "dark"].map((value) => `
        <label data-active="${theme === value}">
          <input type="radio" name="theme" value="${value}" ${theme === value ? "checked" : ""}>
          <span>${value === "auto" ? "Auto" : value === "light" ? "\u263C" : "\u263E"}</span>
        </label>
      `).join("")}
    </span>
  `;
  }
  function renderSettingsSelect(name, selectedValue, options) {
    return `
    <select class="mini-select" name="${escapeHtml(name)}">
      ${options.map((option) => `
        <option value="${escapeHtml(option.value)}" ${option.value === selectedValue ? "selected" : ""}>
          ${escapeHtml(option.label)}
        </option>
      `).join("")}
    </select>
  `;
  }
  function renderSettingsRow(icon, label, value) {
    return `
    <div class="settings-row">
      <span class="settings-icon">${icon}</span>
      <span class="settings-label">${escapeHtml(label)}</span>
      <span class="settings-value">${value}</span>
    </div>
  `;
  }
  function renderSendComposer() {
    const networks = currentHomeSnapshot?.networks ?? [];
    const solana = networks.find((network) => network.family === "solana");
    const solanaAssets = getSolanaSendAssets();
    return `
    <form class="form" id="solana-send-form">
      <label class="small">Network</label>
      <select class="field" id="send-network" name="chainId">
        ${networks.filter((network) => network.family !== "utxo" && network.family !== "ton").map((network) => `
            <option value="${escapeHtml(String(network.chainId))}" data-family="${escapeHtml(network.family)}" ${String(network.chainId) === String(solana?.chainId) ? "selected" : ""}>
              ${escapeHtml(network.name)}
            </option>
          `).join("")}
      </select>
      <label class="small">Asset</label>
      <select class="field" id="send-asset" name="assetId">
        ${solanaAssets.map((asset) => `
          <option
            value="${escapeHtml(buildPopupAssetId(asset))}"
            data-asset-type="${escapeHtml(asset.type === "spl" ? "spl" : "native")}"
            data-token-address="${escapeHtml(asset.tokenAddress ?? "")}"
            data-symbol="${escapeHtml(asset.symbol)}"
            data-decimals="${escapeHtml(String(asset.decimals))}"
            data-balance-raw="${escapeHtml(asset.balanceRaw)}"
          >
            ${escapeHtml(asset.symbol)} \xB7 ${escapeHtml(asset.balanceFormatted)} available
          </option>
        `).join("")}
      </select>
      <input class="field" name="toAddress" placeholder="Solana recipient address" autocomplete="off">
      <input class="field" name="amountFormatted" placeholder="Amount" inputmode="decimal">
      <p class="copy" id="send-support-note">SOL and SPL sends are queued for explicit popup confirmation. Missing recipient token accounts are shown in review.</p>
      <button class="primary-button" type="submit">Review Solana Send</button>
      <button class="ghost-button" type="button" data-open-url="https://24wallet.ru/send">Open full send</button>
    </form>
  `;
  }
  function renderEvmSwapComposer() {
    const networks = (currentHomeSnapshot?.networks ?? []).filter((network) => network.family === "evm" && network.capabilities.swap);
    const selectedNetwork = networks.find(
      (network) => String(network.chainId) === String(currentHomeSnapshot?.activeChainId)
    ) ?? networks[0] ?? null;
    const assets = getEvmSwapAssets(selectedNetwork?.chainId ?? 1);
    const defaultBuy = assets.find((asset) => asset.symbol === "USDC" && asset.type === "erc20") ?? assets.find((asset) => asset.type === "erc20") ?? assets[0];
    return `
    <form class="form" id="evm-swap-form">
      <label class="small">Network</label>
      <select class="field" id="swap-chain" name="chainId">
        ${networks.map((network) => `
          <option value="${escapeHtml(String(network.chainId))}" ${String(network.chainId) === String(selectedNetwork?.chainId) ? "selected" : ""}>
            ${escapeHtml(network.name)}
          </option>
        `).join("")}
      </select>
      <label class="small">Sell token</label>
      <select class="field" id="swap-sell-token" name="sellToken">
        ${assets.map((asset) => renderSwapAssetOption(asset)).join("")}
      </select>
      <label class="small">Buy token</label>
      <select class="field" id="swap-buy-token" name="buyToken">
        ${assets.map((asset) => renderSwapAssetOption(asset, asset === defaultBuy)).join("")}
      </select>
      <input class="field" name="amountRaw" placeholder="Sell amount in raw units, e.g. 1000000" inputmode="numeric">
      <select class="field" name="slippageBps">
        <option value="30">0.3% slippage</option>
        <option value="50" selected>0.5% slippage</option>
        <option value="100">1% slippage</option>
      </select>
      <p class="copy">0x quotes are loaded through the Acorus backend. Approval and swap broadcasts require explicit popup confirmation.</p>
      <button class="primary-button" type="submit">Get 0x Quote</button>
      <button class="ghost-button" type="button" data-open-url="https://24wallet.ru/swap">Open full swap</button>
      <div id="evm-swap-result" class="swap-result"></div>
    </form>
  `;
  }
  function renderSwapAssetOption(asset, selected = false) {
    const token = asset.type === "native" ? "native" : asset.tokenAddress ?? "";
    return `
    <option
      value="${escapeHtml(token)}"
      data-symbol="${escapeHtml(asset.symbol)}"
      data-decimals="${escapeHtml(String(asset.decimals))}"
      data-type="${escapeHtml(asset.type)}"
      ${selected ? "selected" : ""}
    >
      ${escapeHtml(asset.symbol)} \xB7 ${escapeHtml(asset.name)}
    </option>
  `;
  }
  function getEvmSwapAssets(chainId) {
    const chain = currentHomeSnapshot?.networks.find(
      (network) => String(network.chainId) === String(chainId)
    );
    const assets = currentHomeSnapshot?.assets.filter(
      (asset) => asset.family === "evm" && String(asset.chainId) === String(chainId)
    ) ?? [];
    const native = assets.find((asset) => asset.type === "native") ?? {
      family: "evm",
      chainId,
      type: "native",
      symbol: chain?.nativeSymbol ?? "ETH",
      name: chain?.name ?? "Ethereum",
      decimals: 18,
      tokenAddress: null,
      balanceRaw: "0",
      balanceFormatted: "0",
      fiatValue: null,
      priceUsd: null,
      source: "fallback"
    };
    const usdc = chainId === 1 ? {
      family: "evm",
      chainId,
      type: "erc20",
      symbol: "USDC",
      name: "USD Coin",
      decimals: 6,
      tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
      balanceRaw: "0",
      balanceFormatted: "0",
      fiatValue: null,
      priceUsd: null,
      source: "curated"
    } : null;
    const merged = [native, ...assets.filter((asset) => asset.type === "erc20")];
    if (usdc && !merged.some((asset) => asset.tokenAddress?.toLowerCase() === usdc.tokenAddress.toLowerCase())) {
      merged.push(usdc);
    }
    return merged;
  }
  function getSolanaSendAssets() {
    const assets = currentHomeSnapshot?.assets.filter((asset) => asset.family === "solana") ?? [];
    const hasSol = assets.some((asset) => asset.type === "native" && asset.symbol === "SOL");
    return hasSol ? assets : [
      {
        family: "solana",
        chainId: 101,
        type: "native",
        symbol: "SOL",
        name: "Solana",
        decimals: 9,
        tokenAddress: null,
        balanceRaw: "0",
        balanceFormatted: "0",
        fiatValue: null,
        priceUsd: null,
        source: "unavailable"
      },
      ...assets
    ];
  }
  function buildPopupAssetId(asset) {
    return [
      asset.family,
      String(asset.chainId),
      asset.type,
      asset.tokenAddress?.toLowerCase() ?? "native",
      asset.symbol.toUpperCase()
    ].join(":");
  }
  function actionButton(action, id, label, primary, danger = false) {
    const className = danger ? "danger-button" : primary ? "primary-button" : "ghost-button";
    return `<button data-action="${action}" data-id="${escapeHtml(id)}" class="${className}" type="button">${escapeHtml(label)}</button>`;
  }
  function chainName(chainId) {
    switch (Number(chainId)) {
      case 1:
        return "Ethereum";
      case 56:
        return "BNB Chain";
      case 137:
        return "Polygon";
      case 8453:
        return "Base";
      case 42161:
        return "Arbitrum";
      case 101:
        return "Solana";
      default:
        return chainId ? `Chain ${chainId}` : "Multichain";
    }
  }
  function shortAddress(value) {
    if (!value || value === "No synced account") {
      return value;
    }
    if (value.length <= 14) {
      return value;
    }
    return `${value.slice(0, 6)}...${value.slice(-4)}`;
  }
  function formatFiat(value) {
    return typeof value === "number" && Number.isFinite(value) ? `${value.toFixed(2)} $` : "\u2014";
  }
  function getRoot(message) {
    const element = document.getElementById("app");
    if (!element) {
      throw new Error(message);
    }
    return element;
  }
  function escapeHtml(value) {
    return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }
})();
/*! Bundled license information:

ieee754/index.js:
  (*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> *)

buffer/index.js:
  (*!
   * The buffer module from node.js, for the browser.
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   *)
*/
