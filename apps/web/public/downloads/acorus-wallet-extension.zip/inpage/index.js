"use strict";
(() => {
  // src/shared/evm-compat.ts
  var EVM_COMPATIBILITY_METHODS = [
    "eth_requestAccounts",
    "eth_accounts",
    "eth_chainId",
    "net_version",
    "eth_coinbase",
    "wallet_switchEthereumChain",
    "personal_sign",
    "eth_signTypedData_v4",
    "eth_signTransaction",
    "eth_sendTransaction"
  ];
  function isEvmCompatibilityMethod(value) {
    return EVM_COMPATIBILITY_METHODS.includes(value);
  }
  function normalizeEvmRequestParams(value) {
    if (Array.isArray(value)) {
      return value;
    }
    if (value === void 0) {
      return [];
    }
    return [value];
  }
  function mapEvmMethodToAcorusMethod(method) {
    switch (method) {
      case "eth_requestAccounts":
        return "acorus_requestAccounts";
      case "eth_accounts":
      case "eth_coinbase":
        return "acorus_accounts";
      case "eth_chainId":
      case "net_version":
        return "acorus_chainId";
      case "wallet_switchEthereumChain":
        return "acorus_switchChain";
      case "personal_sign":
        return "acorus_signMessage";
      case "eth_signTypedData_v4":
        return "acorus_signTypedData";
      case "eth_signTransaction":
        return "acorus_signTransaction";
      case "eth_sendTransaction":
        return "acorus_sendTransaction";
      default:
        return null;
    }
  }
  function formatEvmChainId(chainId) {
    const normalized = normalizeNumericChainId(chainId);
    if (normalized === null) {
      return null;
    }
    return `0x${normalized.toString(16)}`;
  }
  function toNetVersion(chainId) {
    const normalized = normalizeNumericChainId(chainId);
    return normalized === null ? null : String(normalized);
  }
  function parseEvmSwitchChainParameter(value) {
    const params = normalizeEvmRequestParams(value);
    const candidate = params[0];
    if (candidate && typeof candidate === "object" && "chainId" in candidate) {
      return parseChainId(candidate.chainId);
    }
    return parseChainId(candidate);
  }
  function coerceEvmAccounts(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.filter((item) => typeof item === "string");
  }
  function getEvmSelectedAccount(value) {
    return coerceEvmAccounts(value)[0] ?? null;
  }
  function parseChainId(value) {
    const normalized = normalizeNumericChainId(value);
    return normalized === null ? null : normalized;
  }
  function normalizeNumericChainId(value) {
    if (typeof value === "number" && Number.isInteger(value) && value >= 0) {
      return value;
    }
    if (typeof value !== "string") {
      return null;
    }
    const trimmed = value.trim().toLowerCase();
    if (/^0x[0-9a-f]+$/u.test(trimmed)) {
      return Number.parseInt(trimmed.slice(2), 16);
    }
    if (/^\d+$/u.test(trimmed)) {
      return Number.parseInt(trimmed, 10);
    }
    return null;
  }

  // src/shared/protocol.ts
  var ACORUS_INPAGE_REQUEST = "acorus:inpage-request";
  var ACORUS_INPAGE_RESPONSE = "acorus:inpage-response";
  var ACORUS_INPAGE_STATE = "acorus:inpage-state";
  var ACORUS_PROVIDER_METHODS = [
    "acorus_ping",
    "acorus_requestAccounts",
    "acorus_accounts",
    "acorus_chainId",
    "acorus_switchChain",
    "acorus_signMessage",
    "acorus_signTypedData",
    "acorus_signTransaction",
    "acorus_sendTransaction"
  ];
  function createRequestId(prefix = "acorus") {
    if (globalThis.crypto?.randomUUID) {
      return `${prefix}_${globalThis.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }
  function isAcorusProviderMethod(value) {
    return ACORUS_PROVIDER_METHODS.includes(value);
  }
  function isInpageStateEnvelope(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    const candidate = value;
    return candidate.type === ACORUS_INPAGE_STATE && typeof candidate.state === "object" && candidate.state !== null && typeof candidate.state.origin === "string";
  }

  // src/inpage/index.ts
  var pendingRequests = /* @__PURE__ */ new Map();
  var bridgeState = {
    origin: window.location.origin,
    status: "disconnected",
    providerMode: "stub_only",
    accounts: [],
    chainIds: [],
    activeChainId: null,
    permissions: [],
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  window.addEventListener("message", handleInpageResponse);
  window.acorus = {
    isAcorus: true,
    isConnected() {
      return bridgeState.status === "connected";
    },
    async request(input) {
      if (!isAcorusProviderMethod(input.method)) {
        throw new Error("Unsupported Acorus provider method.");
      }
      return requestBridgeMethod(input.method, input.params ?? []);
    }
  };
  function handleInpageResponse(event) {
    if (event.source !== window) {
      return;
    }
    const data = event.data;
    if (isInpageStateEnvelope(data)) {
      applyBridgeState(data);
      return;
    }
    if (typeof data !== "object" || data === null || data.type !== ACORUS_INPAGE_RESPONSE || typeof data.requestId !== "string") {
      return;
    }
    const response = data;
    const pending = pendingRequests.get(response.requestId);
    if (!pending) {
      return;
    }
    pendingRequests.delete(response.requestId);
    if (response.ok) {
      pending.resolve(response.result);
      return;
    }
    pending.reject(
      createProviderError(
        response.error?.code ?? "provider_error",
        response.error?.message ?? "Acorus extension request failed."
      )
    );
  }
  function applyBridgeState(envelope) {
    const previous = bridgeState;
    bridgeState = envelope.state;
    window.dispatchEvent(
      new CustomEvent("acorus#stateChanged", {
        detail: bridgeState
      })
    );
    if (JSON.stringify(previous.accounts) !== JSON.stringify(bridgeState.accounts)) {
      window.dispatchEvent(
        new CustomEvent("acorus#accountsChanged", {
          detail: bridgeState.accounts
        })
      );
    }
    if (previous.activeChainId !== bridgeState.activeChainId) {
      window.dispatchEvent(
        new CustomEvent("acorus#chainChanged", {
          detail: bridgeState.activeChainId
        })
      );
    }
    emitEthereumStateChanges(previous, bridgeState);
  }
  function createProviderError(code, message) {
    const error = new Error(message);
    error.name = code;
    return error;
  }
  function requestBridgeMethod(method, params) {
    const requestId = createRequestId("inpage");
    const envelope = {
      type: ACORUS_INPAGE_REQUEST,
      requestId,
      method,
      params
    };
    return new Promise((resolve, reject) => {
      pendingRequests.set(requestId, { resolve, reject });
      window.postMessage(envelope, window.location.origin);
    });
  }
  var AcorusEthereumProviderRuntime = class {
    isAcorus = true;
    isMetaMask = false;
    providers = [this];
    listeners = /* @__PURE__ */ new Map();
    get chainId() {
      return formatEvmChainId(bridgeState.activeChainId);
    }
    get selectedAddress() {
      return bridgeState.accounts[0] ?? null;
    }
    isConnected() {
      return bridgeState.status === "connected";
    }
    async request(args) {
      if (!isEvmCompatibilityMethod(args.method)) {
        throw createEthereumProviderError(
          4200,
          `Unsupported Ethereum provider method: ${args.method}.`
        );
      }
      try {
        return await handleEvmCompatibilityRequest(args.method, args.params);
      } catch (error) {
        throw normalizeEthereumProviderError(error);
      }
    }
    send(methodOrPayload, paramsOrCallback) {
      if (typeof methodOrPayload === "string") {
        if (isLegacyCallback(paramsOrCallback)) {
          this.sendAsync(
            {
              id: createRequestId("ethereum"),
              jsonrpc: "2.0",
              method: methodOrPayload,
              params: []
            },
            paramsOrCallback
          );
          return;
        }
        return this.request({
          method: methodOrPayload,
          params: paramsOrCallback
        });
      }
      if (isLegacyCallback(paramsOrCallback)) {
        this.sendAsync(methodOrPayload, paramsOrCallback);
        return;
      }
      return this.request({
        method: methodOrPayload.method,
        params: methodOrPayload.params
      });
    }
    sendAsync(payload, callback) {
      void this.request({
        method: payload.method,
        params: payload.params
      }).then((result) => {
        callback(null, {
          id: payload.id ?? null,
          jsonrpc: "2.0",
          result
        });
      }).catch((error) => {
        const providerError = normalizeEthereumProviderError(error);
        callback(providerError, {
          id: payload.id ?? null,
          jsonrpc: "2.0",
          error: {
            code: getEthereumProviderErrorCode(providerError),
            message: providerError.message
          }
        });
      });
    }
    enable() {
      return this.request({
        method: "eth_requestAccounts"
      });
    }
    on(event, listener) {
      const listeners = this.listeners.get(event) ?? /* @__PURE__ */ new Set();
      listeners.add(listener);
      this.listeners.set(event, listeners);
      return this;
    }
    removeListener(event, listener) {
      this.listeners.get(event)?.delete(listener);
      return this;
    }
    emit(event, ...args) {
      const listeners = this.listeners.get(event);
      if (!listeners) {
        return;
      }
      for (const listener of listeners) {
        listener(...args);
      }
    }
  };
  var ethereumProvider = new AcorusEthereumProviderRuntime();
  window.ethereum = ethereumProvider;
  window.acorusEthereum = ethereumProvider;
  window.dispatchEvent(new Event("acorus#initialized"));
  window.dispatchEvent(new Event("ethereum#initialized"));
  async function handleEvmCompatibilityRequest(method, paramsInput) {
    if (method === "wallet_switchEthereumChain") {
      const requestedChainId = parseEvmSwitchChainParameter(paramsInput);
      if (requestedChainId === null) {
        throw createEthereumProviderError(
          -32602,
          "wallet_switchEthereumChain expects a chainId field in the first parameter."
        );
      }
      await requestBridgeMethod("acorus_switchChain", [requestedChainId]);
      return null;
    }
    const acorusMethod = mapEvmMethodToAcorusMethod(method);
    if (!acorusMethod) {
      throw createEthereumProviderError(
        4200,
        `Unsupported Ethereum provider method: ${method}.`
      );
    }
    const result = await requestBridgeMethod(
      acorusMethod,
      normalizeEvmRequestParams(paramsInput)
    );
    switch (method) {
      case "eth_requestAccounts":
      case "eth_accounts":
        return coerceEvmAccounts(result);
      case "eth_chainId": {
        const chainId = formatEvmChainId(result);
        if (!chainId) {
          throw createEthereumProviderError(
            4900,
            "No active EVM chain is available for this origin."
          );
        }
        return chainId;
      }
      case "net_version": {
        const chainId = toNetVersion(result);
        if (!chainId) {
          throw createEthereumProviderError(
            4900,
            "No active EVM chain is available for this origin."
          );
        }
        return chainId;
      }
      case "eth_coinbase":
        return getEvmSelectedAccount(result);
      case "personal_sign":
      case "eth_signTypedData_v4":
      case "eth_signTransaction":
      case "eth_sendTransaction":
        return result;
      default:
        return result;
    }
  }
  function emitEthereumStateChanges(previous, next) {
    const previousChainId = formatEvmChainId(previous.activeChainId);
    const nextChainId = formatEvmChainId(next.activeChainId);
    const wasConnected = previous.status === "connected";
    const isConnected = next.status === "connected";
    if (JSON.stringify(previous.accounts) !== JSON.stringify(next.accounts)) {
      ethereumProvider.emit("accountsChanged", next.accounts);
    }
    if (previousChainId !== nextChainId && nextChainId) {
      ethereumProvider.emit("chainChanged", nextChainId);
    }
    if (!wasConnected && isConnected) {
      ethereumProvider.emit("connect", {
        chainId: nextChainId ?? "0x0"
      });
    }
    if (wasConnected && !isConnected) {
      ethereumProvider.emit(
        "disconnect",
        createEthereumProviderError(
          4900,
          "Acorus Wallet disconnected from this origin."
        )
      );
    }
  }
  function normalizeEthereumProviderError(error) {
    if (error instanceof Error && getEthereumProviderErrorCode(error) !== -32603) {
      return error;
    }
    if (error instanceof Error) {
      return createEthereumProviderError(
        mapAcorusErrorCode(error.name),
        error.message
      );
    }
    return createEthereumProviderError(
      -32603,
      "Ethereum provider request failed."
    );
  }
  function createEthereumProviderError(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }
  function getEthereumProviderErrorCode(error) {
    const code = error.code;
    return typeof code === "number" ? code : -32603;
  }
  function mapAcorusErrorCode(code) {
    switch (code) {
      case "user_rejected":
        return 4001;
      case "approval_required":
      case "permission_denied":
        return 4100;
      case "unsupported_method":
      case "not_enabled":
        return 4200;
      case "not_connected":
      case "session_revoked":
      case "wallet_locked":
        return 4900;
      case "unsupported_chain":
        return 4902;
      case "bad_request":
        return -32602;
      default:
        return -32603;
    }
  }
  function isLegacyCallback(value) {
    return typeof value === "function";
  }
})();
