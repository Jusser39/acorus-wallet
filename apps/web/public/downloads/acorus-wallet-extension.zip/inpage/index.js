"use strict";
(() => {
  // src/shared/evm-compat.ts
  var EVM_COMPATIBILITY_METHODS = [
    "eth_requestAccounts",
    "eth_accounts",
    "eth_chainId",
    "web3_clientVersion",
    "net_version",
    "eth_coinbase",
    "wallet_getPermissions",
    "wallet_requestPermissions",
    "wallet_revokePermissions",
    "wallet_addEthereumChain",
    "wallet_switchEthereumChain",
    "wallet_watchAsset",
    "personal_sign",
    "eth_signTypedData_v4",
    "eth_signTransaction",
    "eth_sendTransaction"
  ];
  function isEvmCompatibilityMethod(value) {
    return EVM_COMPATIBILITY_METHODS.includes(value);
  }
  function normalizeEvmRequestParams(value) {
    if (Array.isArray(value)) {
      return value;
    }
    if (value === void 0) {
      return [];
    }
    return [value];
  }
  function mapEvmMethodToAcorusMethod(method) {
    switch (method) {
      case "eth_requestAccounts":
        return "acorus_requestAccounts";
      case "eth_accounts":
      case "eth_coinbase":
        return "acorus_accounts";
      case "eth_chainId":
      case "web3_clientVersion":
      case "net_version":
        return "acorus_chainId";
      case "wallet_getPermissions":
        return "acorus_getPermissions";
      case "wallet_requestPermissions":
        return "acorus_requestPermissions";
      case "wallet_revokePermissions":
        return "acorus_revokePermissions";
      case "wallet_addEthereumChain":
        return "acorus_addChain";
      case "wallet_switchEthereumChain":
        return "acorus_switchChain";
      case "wallet_watchAsset":
        return "acorus_watchAsset";
      case "personal_sign":
        return "acorus_signMessage";
      case "eth_signTypedData_v4":
        return "acorus_signTypedData";
      case "eth_signTransaction":
        return "acorus_signTransaction";
      case "eth_sendTransaction":
        return "acorus_sendTransaction";
      default:
        return null;
    }
  }
  function formatEvmChainId(chainId) {
    const normalized = normalizeNumericChainId(chainId);
    if (normalized === null) {
      return null;
    }
    return `0x${normalized.toString(16)}`;
  }
  function toNetVersion(chainId) {
    const normalized = normalizeNumericChainId(chainId);
    return normalized === null ? null : String(normalized);
  }
  function parseEvmSwitchChainParameter(value) {
    const params = normalizeEvmRequestParams(value);
    const candidate = params[0];
    if (candidate && typeof candidate === "object" && "chainId" in candidate) {
      return parseChainId(candidate.chainId);
    }
    return parseChainId(candidate);
  }
  function coerceEvmAccounts(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.filter((item) => typeof item === "string");
  }
  function getEvmSelectedAccount(value) {
    return coerceEvmAccounts(value)[0] ?? null;
  }
  function parseChainId(value) {
    const normalized = normalizeNumericChainId(value);
    return normalized === null ? null : normalized;
  }
  function normalizeNumericChainId(value) {
    if (typeof value === "number" && Number.isInteger(value) && value >= 0) {
      return value;
    }
    if (typeof value !== "string") {
      return null;
    }
    const trimmed = value.trim().toLowerCase();
    if (/^0x[0-9a-f]+$/u.test(trimmed)) {
      return Number.parseInt(trimmed.slice(2), 16);
    }
    if (/^\d+$/u.test(trimmed)) {
      return Number.parseInt(trimmed, 10);
    }
    return null;
  }

  // src/shared/protocol.ts
  var ACORUS_INPAGE_REQUEST = "acorus:inpage-request";
  var ACORUS_INPAGE_RESPONSE = "acorus:inpage-response";
  var ACORUS_INPAGE_STATE = "acorus:inpage-state";
  var ACORUS_PROVIDER_METHODS = [
    "acorus_ping",
    "acorus_getVaultStatus",
    "acorus_createWallet",
    "acorus_importWallet",
    "acorus_unlockWallet",
    "acorus_lockWallet",
    "acorus_receiveAddress",
    "acorus_requestAccounts",
    "acorus_accounts",
    "acorus_chainId",
    "acorus_switchChain",
    "acorus_getPermissions",
    "acorus_requestPermissions",
    "acorus_revokePermissions",
    "acorus_addChain",
    "acorus_watchAsset",
    "acorus_multichainSend",
    "acorus_swap",
    "acorus_signMessage",
    "acorus_signTypedData",
    "acorus_signTransaction",
    "acorus_sendTransaction"
  ];
  function createRequestId(prefix = "acorus") {
    if (globalThis.crypto?.randomUUID) {
      return `${prefix}_${globalThis.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }
  function isAcorusProviderMethod(value) {
    return ACORUS_PROVIDER_METHODS.includes(value);
  }
  function isInpageStateEnvelope(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    const candidate = value;
    return candidate.type === ACORUS_INPAGE_STATE && typeof candidate.state === "object" && candidate.state !== null && typeof candidate.state.origin === "string";
  }

  // src/inpage/index.ts
  window.acorusEthereumInjected = true;
  var pendingRequests = /* @__PURE__ */ new Map();
  var bridgeState = {
    origin: window.location.origin,
    status: "disconnected",
    providerMode: "stub_only",
    accounts: [],
    chainIds: [],
    activeChainId: null,
    permissions: [],
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  var ACORUS_EIP6963_INFO = {
    uuid: "7e7f39e2-7b23-4f04-b3b9-acoruswallet01",
    name: "Acorus Wallet",
    icon: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' x2='1' y1='0' y2='1'%3E%3Cstop stop-color='%23ff46b7'/%3E%3Cstop offset='.55' stop-color='%238b5cf6'/%3E%3Cstop offset='1' stop-color='%2338bdf8'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='18' fill='url(%23g)'/%3E%3Cpath fill='white' d='M33 13 50 51h-9l-3-8H24l-3 8h-8L30 13h3Zm2 23-4-11-4 11h8Z'/%3E%3C/svg%3E",
    rdns: "ru.24wallet.acorus"
  };
  window.addEventListener("message", handleInpageResponse);
  function handleInpageResponse(event) {
    if (event.source !== window) {
      return;
    }
    const data = event.data;
    if (isInpageStateEnvelope(data)) {
      applyBridgeState(data);
      return;
    }
    if (typeof data !== "object" || data === null || data.type !== ACORUS_INPAGE_RESPONSE || typeof data.requestId !== "string") {
      return;
    }
    const response = data;
    const pending = pendingRequests.get(response.requestId);
    if (!pending) {
      return;
    }
    pendingRequests.delete(response.requestId);
    if (response.ok) {
      pending.resolve(response.result);
      return;
    }
    pending.reject(
      createProviderError(
        response.error?.code ?? "provider_error",
        response.error?.message ?? "Acorus extension request failed."
      )
    );
  }
  function applyBridgeState(envelope) {
    const previous = bridgeState;
    bridgeState = envelope.state;
    window.dispatchEvent(
      new CustomEvent("acorus#stateChanged", {
        detail: bridgeState
      })
    );
    if (JSON.stringify(previous.accounts) !== JSON.stringify(bridgeState.accounts)) {
      window.dispatchEvent(
        new CustomEvent("acorus#accountsChanged", {
          detail: bridgeState.accounts
        })
      );
    }
    if (previous.activeChainId !== bridgeState.activeChainId) {
      window.dispatchEvent(
        new CustomEvent("acorus#chainChanged", {
          detail: bridgeState.activeChainId
        })
      );
    }
    emitEthereumStateChanges(previous, bridgeState);
  }
  function createProviderError(code, message) {
    const error = new Error(message);
    error.name = code;
    return error;
  }
  function requestBridgeMethod(method, params) {
    const requestId = createRequestId("inpage");
    const envelope = {
      type: ACORUS_INPAGE_REQUEST,
      requestId,
      method,
      params
    };
    return new Promise((resolve, reject) => {
      pendingRequests.set(requestId, { resolve, reject });
      window.postMessage(envelope, window.location.origin);
    });
  }
  var AcorusEthereumProviderRuntime = class {
    isAcorus = true;
    isMetaMask = true;
    isTrust = false;
    providers = [this];
    listeners = /* @__PURE__ */ new Map();
    get chainId() {
      return formatEvmChainId(bridgeState.activeChainId);
    }
    get selectedAddress() {
      return bridgeState.accounts[0] ?? null;
    }
    isConnected() {
      return bridgeState.status === "connected";
    }
    async request(args) {
      if (!isEvmCompatibilityMethod(args.method)) {
        throw createEthereumProviderError(
          4200,
          `Unsupported Ethereum provider method: ${args.method}.`
        );
      }
      try {
        return await handleEvmCompatibilityRequest(args.method, args.params);
      } catch (error) {
        throw normalizeEthereumProviderError(error);
      }
    }
    send(methodOrPayload, paramsOrCallback) {
      if (typeof methodOrPayload === "string") {
        if (isLegacyCallback(paramsOrCallback)) {
          this.sendAsync(
            {
              id: createRequestId("ethereum"),
              jsonrpc: "2.0",
              method: methodOrPayload,
              params: []
            },
            paramsOrCallback
          );
          return;
        }
        return this.request({
          method: methodOrPayload,
          params: paramsOrCallback
        });
      }
      if (isLegacyCallback(paramsOrCallback)) {
        this.sendAsync(methodOrPayload, paramsOrCallback);
        return;
      }
      return this.request({
        method: methodOrPayload.method,
        params: methodOrPayload.params
      });
    }
    sendAsync(payload, callback) {
      void this.request({
        method: payload.method,
        params: payload.params
      }).then((result) => {
        callback(null, {
          id: payload.id ?? null,
          jsonrpc: "2.0",
          result
        });
      }).catch((error) => {
        const providerError = normalizeEthereumProviderError(error);
        callback(providerError, {
          id: payload.id ?? null,
          jsonrpc: "2.0",
          error: {
            code: getEthereumProviderErrorCode(providerError),
            message: providerError.message
          }
        });
      });
    }
    enable() {
      return this.request({
        method: "eth_requestAccounts"
      });
    }
    on(event, listener) {
      const listeners = this.listeners.get(event) ?? /* @__PURE__ */ new Set();
      listeners.add(listener);
      this.listeners.set(event, listeners);
      return this;
    }
    removeListener(event, listener) {
      this.listeners.get(event)?.delete(listener);
      return this;
    }
    emit(event, ...args) {
      const listeners = this.listeners.get(event);
      if (!listeners) {
        return;
      }
      for (const listener of listeners) {
        listener(...args);
      }
    }
  };
  var ethereumProvider = new AcorusEthereumProviderRuntime();
  window.ethereum = ethereumProvider;
  window.acorusEthereum = ethereumProvider;
  var solanaProvider = createSolanaProvider();
  var tronProvider = createTronProvider();
  var bitcoinProvider = createSimpleChainProvider("utxo", "bitcoin-mainnet");
  var tonProvider = createSimpleChainProvider("ton", "ton-mainnet");
  window.solana = solanaProvider;
  window.acorusSolana = solanaProvider;
  window.tronLink = tronProvider;
  window.acorusTron = tronProvider;
  window.acorusBitcoin = bitcoinProvider;
  window.acorusTon = tonProvider;
  window.acorus = {
    isAcorus: true,
    providers: {
      evm: ethereumProvider,
      solana: solanaProvider,
      tron: tronProvider,
      bitcoin: bitcoinProvider,
      ton: tonProvider
    },
    isConnected() {
      return bridgeState.status === "connected";
    },
    async request(input) {
      if (!isAcorusProviderMethod(input.method)) {
        throw new Error("Unsupported Acorus provider method.");
      }
      return requestBridgeMethod(input.method, input.params ?? []);
    }
  };
  window.dispatchEvent(new Event("acorus#initialized"));
  window.dispatchEvent(new Event("ethereum#initialized"));
  window.dispatchEvent(new Event("solana#initialized"));
  window.dispatchEvent(new Event("tronLink#initialized"));
  announceEip6963Provider();
  window.addEventListener("eip6963:requestProvider", announceEip6963Provider);
  async function handleEvmCompatibilityRequest(method, paramsInput) {
    if (method === "wallet_switchEthereumChain") {
      const requestedChainId = parseEvmSwitchChainParameter(paramsInput);
      if (requestedChainId === null) {
        throw createEthereumProviderError(
          -32602,
          "wallet_switchEthereumChain expects a chainId field in the first parameter."
        );
      }
      await requestBridgeMethod("acorus_switchChain", [requestedChainId]);
      return null;
    }
    const acorusMethod = mapEvmMethodToAcorusMethod(method);
    if (!acorusMethod) {
      throw createEthereumProviderError(
        4200,
        `Unsupported Ethereum provider method: ${method}.`
      );
    }
    const result = await requestBridgeMethod(
      acorusMethod,
      shouldScopeEvmMethodToFamily(method) ? [{ family: "evm" }, ...normalizeEvmRequestParams(paramsInput)] : normalizeEvmRequestParams(paramsInput)
    );
    switch (method) {
      case "eth_requestAccounts":
      case "eth_accounts":
        return coerceEvmAccounts(result);
      case "eth_chainId": {
        const chainId = formatEvmChainId(result);
        if (!chainId) {
          throw createEthereumProviderError(
            4900,
            "No active EVM chain is available for this origin."
          );
        }
        return chainId;
      }
      case "web3_clientVersion":
        return "AcorusWallet/v0.1.0";
      case "wallet_getPermissions":
      case "wallet_requestPermissions":
        return Array.isArray(result) ? result.map((parentCapability) => ({ parentCapability })) : [];
      case "wallet_revokePermissions":
      case "wallet_addEthereumChain":
        return null;
      case "wallet_watchAsset":
        return Boolean(result);
      case "net_version": {
        const chainId = toNetVersion(result);
        if (!chainId) {
          throw createEthereumProviderError(
            4900,
            "No active EVM chain is available for this origin."
          );
        }
        return chainId;
      }
      case "eth_coinbase":
        return getEvmSelectedAccount(result);
      case "personal_sign":
      case "eth_signTypedData_v4":
      case "eth_signTransaction":
      case "eth_sendTransaction":
        return result;
      default:
        return result;
    }
  }
  function emitEthereumStateChanges(previous, next) {
    const previousChainId = formatEvmChainId(previous.activeChainId);
    const nextChainId = formatEvmChainId(next.activeChainId);
    const wasConnected = previous.status === "connected";
    const isConnected = next.status === "connected";
    if (JSON.stringify(previous.accounts) !== JSON.stringify(next.accounts)) {
      ethereumProvider.emit("accountsChanged", next.accounts);
    }
    if (previousChainId !== nextChainId && nextChainId) {
      ethereumProvider.emit("chainChanged", nextChainId);
    }
    if (!wasConnected && isConnected) {
      ethereumProvider.emit("connect", {
        chainId: nextChainId ?? "0x0"
      });
    }
    if (wasConnected && !isConnected) {
      ethereumProvider.emit(
        "disconnect",
        createEthereumProviderError(
          4900,
          "Acorus Wallet disconnected from this origin."
        )
      );
    }
  }
  function shouldScopeEvmMethodToFamily(method) {
    return method === "eth_requestAccounts" || method === "eth_accounts" || method === "eth_coinbase" || method === "wallet_requestPermissions";
  }
  function createSolanaProvider() {
    const provider = {
      isAcorus: true,
      isPhantom: false,
      family: "solana",
      chainId: 101,
      get publicKey() {
        const account = bridgeState.accounts.find((value) => !value.startsWith("0x"));
        return account ? {
          toString() {
            return account;
          }
        } : null;
      },
      get isConnected() {
        return Boolean(this.publicKey);
      },
      async connect() {
        const accounts = await requestFamilyAccounts("solana");
        window.dispatchEvent(new CustomEvent("acorusSolana#connect", {
          detail: { publicKey: accounts[0] ?? null }
        }));
        return {
          publicKey: accounts[0],
          address: accounts[0],
          accounts
        };
      },
      async disconnect() {
        await requestBridgeMethod("acorus_revokePermissions", []);
        window.dispatchEvent(new Event("acorusSolana#disconnect"));
      },
      async signMessage(message) {
        return requestBridgeMethod("acorus_signMessage", [
          {
            family: "solana",
            message: typeof message === "string" ? message : Array.from(message)
          }
        ]);
      },
      async request(input) {
        if (input.method === "connect" || input.method === "solana_connect") {
          return this.connect();
        }
        if (input.method === "disconnect" || input.method === "solana_disconnect") {
          return this.disconnect();
        }
        if (input.method === "signMessage" || input.method === "solana_signMessage") {
          return this.signMessage((input.params ?? [])[0]);
        }
        return requestBridgeMethod("acorus_requestAccounts", [{ family: "solana" }]);
      }
    };
    return provider;
  }
  function createTronProvider() {
    return {
      isAcorus: true,
      get ready() {
        return bridgeState.status === "connected";
      },
      async request(input) {
        if (input.method === "tron_requestAccounts" || input.method === "request_accounts" || input.method === "connect") {
          return {
            code: 200,
            message: "OK",
            accounts: await requestFamilyAccounts("tron")
          };
        }
        if (input.method === "tron_signMessage") {
          return requestBridgeMethod("acorus_signMessage", [
            {
              family: "tron",
              message: (input.params ?? [])[0]
            }
          ]);
        }
        return requestBridgeMethod("acorus_requestAccounts", [{ family: "tron" }]);
      }
    };
  }
  function createSimpleChainProvider(family, chainId) {
    return {
      isAcorus: true,
      family,
      chainId,
      async connect() {
        const accounts = await requestFamilyAccounts(family);
        return {
          address: accounts[0],
          accounts
        };
      },
      async request(input) {
        if (input.method === "connect" || input.method.endsWith("_requestAccounts")) {
          return this.connect();
        }
        if (input.method.toLowerCase().includes("sign")) {
          return requestBridgeMethod("acorus_signMessage", [
            {
              family,
              payload: input.params ?? []
            }
          ]);
        }
        return requestBridgeMethod("acorus_accounts", [{ family }]);
      }
    };
  }
  async function requestFamilyAccounts(family) {
    const accounts = await requestBridgeMethod("acorus_requestAccounts", [{ family }]);
    return Array.isArray(accounts) ? accounts.filter((account) => typeof account === "string") : [];
  }
  function announceEip6963Provider() {
    window.dispatchEvent(
      new CustomEvent("eip6963:announceProvider", {
        detail: {
          info: ACORUS_EIP6963_INFO,
          provider: ethereumProvider
        }
      })
    );
  }
  function normalizeEthereumProviderError(error) {
    if (error instanceof Error && getEthereumProviderErrorCode(error) !== -32603) {
      return error;
    }
    if (error instanceof Error) {
      return createEthereumProviderError(
        mapAcorusErrorCode(error.name),
        error.message
      );
    }
    return createEthereumProviderError(
      -32603,
      "Ethereum provider request failed."
    );
  }
  function createEthereumProviderError(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }
  function getEthereumProviderErrorCode(error) {
    const code = error.code;
    return typeof code === "number" ? code : -32603;
  }
  function mapAcorusErrorCode(code) {
    switch (code) {
      case "user_rejected":
        return 4001;
      case "approval_required":
      case "permission_denied":
        return 4100;
      case "unsupported_method":
      case "not_enabled":
        return 4200;
      case "not_connected":
      case "session_revoked":
      case "wallet_locked":
        return 4900;
      case "unsupported_chain":
        return 4902;
      case "bad_request":
        return -32602;
      default:
        return -32603;
    }
  }
  function isLegacyCallback(value) {
    return typeof value === "function";
  }
})();
