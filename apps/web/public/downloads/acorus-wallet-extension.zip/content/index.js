"use strict";
(() => {
  // src/shared/protocol.ts
  var ACORUS_INPAGE_REQUEST = "acorus:inpage-request";
  var ACORUS_INPAGE_RESPONSE = "acorus:inpage-response";
  var ACORUS_INPAGE_STATE = "acorus:inpage-state";
  var ACORUS_PROVIDER_METHODS = [
    "acorus_ping",
    "acorus_getVaultStatus",
    "acorus_createWallet",
    "acorus_importWallet",
    "acorus_unlockWallet",
    "acorus_lockWallet",
    "acorus_receiveAddress",
    "acorus_requestAccounts",
    "acorus_accounts",
    "acorus_chainId",
    "acorus_switchChain",
    "acorus_getPermissions",
    "acorus_requestPermissions",
    "acorus_revokePermissions",
    "acorus_addChain",
    "acorus_watchAsset",
    "acorus_multichainSend",
    "acorus_swap",
    "acorus_signMessage",
    "acorus_signTypedData",
    "acorus_signTransaction",
    "acorus_sendTransaction"
  ];
  function createRequestId(prefix = "acorus") {
    if (globalThis.crypto?.randomUUID) {
      return `${prefix}_${globalThis.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }
  function isAcorusProviderMethod(value) {
    return ACORUS_PROVIDER_METHODS.includes(value);
  }
  function isInpageRequestEnvelope(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    const candidate = value;
    return candidate.type === ACORUS_INPAGE_REQUEST && typeof candidate.requestId === "string" && typeof candidate.method === "string" && isAcorusProviderMethod(candidate.method);
  }

  // ../../packages/shared/src/chains.ts
  var DEFAULT_SOLANA_CHAIN_ID = 101;
  var DEFAULT_TRON_CHAIN_ID = "tron-mainnet";
  var DEFAULT_BITCOIN_CHAIN_ID = "bitcoin-mainnet";
  var DEFAULT_TON_CHAIN_ID = "ton-mainnet";
  var EVM_CHAINS = [
    {
      chainId: 1,
      family: "evm",
      name: "Ethereum",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ETH_RPC_URL",
      blockExplorerUrl: "https://etherscan.io"
    },
    {
      chainId: 56,
      family: "evm",
      name: "BNB Smart Chain",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_BSC_RPC_URL",
      blockExplorerUrl: "https://bscscan.com"
    },
    {
      chainId: 137,
      family: "evm",
      name: "Polygon",
      nativeSymbol: "MATIC",
      rpcUrlEnv: "NEXT_PUBLIC_POLYGON_RPC_URL",
      blockExplorerUrl: "https://polygonscan.com"
    },
    {
      chainId: 42161,
      family: "evm",
      name: "Arbitrum One",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ARBITRUM_RPC_URL",
      blockExplorerUrl: "https://arbiscan.io"
    },
    {
      chainId: 10,
      family: "evm",
      name: "Optimism",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_OPTIMISM_RPC_URL",
      blockExplorerUrl: "https://optimistic.etherscan.io"
    },
    {
      chainId: 8453,
      family: "evm",
      name: "Base",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_BASE_RPC_URL",
      blockExplorerUrl: "https://basescan.org"
    },
    {
      chainId: 43114,
      family: "evm",
      name: "Avalanche",
      nativeSymbol: "AVAX",
      rpcUrlEnv: "NEXT_PUBLIC_AVALANCHE_RPC_URL",
      blockExplorerUrl: "https://snowtrace.io"
    },
    {
      chainId: 59144,
      family: "evm",
      name: "Linea",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_LINEA_RPC_URL",
      blockExplorerUrl: "https://lineascan.build"
    },
    {
      chainId: 250,
      family: "evm",
      name: "Fantom",
      nativeSymbol: "FTM",
      rpcUrlEnv: "NEXT_PUBLIC_FANTOM_RPC_URL",
      blockExplorerUrl: "https://ftmscan.com"
    },
    {
      chainId: 1329,
      family: "evm",
      name: "Sei",
      nativeSymbol: "SEI",
      rpcUrlEnv: "NEXT_PUBLIC_SEI_RPC_URL",
      blockExplorerUrl: "https://seitrace.com"
    },
    {
      chainId: 204,
      family: "evm",
      name: "opBNB",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_OPBNB_RPC_URL",
      blockExplorerUrl: "https://opbnbscan.com"
    },
    {
      chainId: 324,
      family: "evm",
      name: "zkSync Era",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ZKSYNC_RPC_URL",
      blockExplorerUrl: "https://era.zksync.network"
    }
  ];
  var SOLANA_MAINNET_CHAIN = {
    chainId: DEFAULT_SOLANA_CHAIN_ID,
    family: "solana",
    name: "Solana",
    network: "mainnet-beta",
    nativeSymbol: "SOL",
    rpcUrlEnv: "NEXT_PUBLIC_SOLANA_RPC_URL",
    blockExplorerUrl: "https://solscan.io"
  };
  var TRON_MAINNET_CHAIN = {
    family: "tron",
    chainId: DEFAULT_TRON_CHAIN_ID,
    name: "Tron",
    nativeSymbol: "TRX",
    rpcUrlEnv: "NEXT_PUBLIC_TRON_RPC_URL",
    blockExplorerUrl: "https://tronscan.org/#",
    isEnabled: false,
    isSkeleton: true
  };
  var BITCOIN_MAINNET_CHAIN = {
    family: "utxo",
    chainId: DEFAULT_BITCOIN_CHAIN_ID,
    name: "Bitcoin",
    nativeSymbol: "BTC",
    rpcUrlEnv: "NEXT_PUBLIC_BITCOIN_RPC_URL",
    blockExplorerUrl: "https://mempool.space",
    isEnabled: false,
    isSkeleton: true
  };
  var TON_MAINNET_CHAIN = {
    family: "ton",
    chainId: DEFAULT_TON_CHAIN_ID,
    name: "TON",
    nativeSymbol: "TON",
    rpcUrlEnv: "NEXT_PUBLIC_TON_RPC_URL",
    blockExplorerUrl: "https://tonscan.org",
    isEnabled: false,
    isSkeleton: true
  };
  var UNIVERSAL_CHAINS = [
    ...EVM_CHAINS.map((chain) => ({
      family: "evm",
      chainId: chain.chainId,
      name: chain.name,
      nativeSymbol: chain.nativeSymbol,
      rpcUrlEnv: chain.rpcUrlEnv,
      blockExplorerUrl: chain.blockExplorerUrl,
      isEnabled: true
    })),
    {
      family: SOLANA_MAINNET_CHAIN.family,
      chainId: SOLANA_MAINNET_CHAIN.chainId,
      name: SOLANA_MAINNET_CHAIN.name,
      nativeSymbol: SOLANA_MAINNET_CHAIN.nativeSymbol,
      rpcUrlEnv: SOLANA_MAINNET_CHAIN.rpcUrlEnv,
      blockExplorerUrl: SOLANA_MAINNET_CHAIN.blockExplorerUrl,
      network: SOLANA_MAINNET_CHAIN.network,
      isEnabled: true
    },
    TRON_MAINNET_CHAIN,
    BITCOIN_MAINNET_CHAIN,
    TON_MAINNET_CHAIN
  ];

  // ../../packages/shared/src/dapp.ts
  var ACORUS_EXTENSION_WALLET_SYNC = "acorus:wallet-sync";
  function isDappWalletSyncEnvelope(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    const candidate = value;
    return candidate.type === ACORUS_EXTENSION_WALLET_SYNC && candidate.source === "acorus_wallet_web" && typeof candidate.syncedAt === "string" && Array.isArray(candidate.profiles) && candidate.profiles.every(
      (profile) => typeof profile?.id === "string" && typeof profile?.name === "string" && typeof profile?.type === "string" && typeof profile?.publicAddress === "string" && typeof profile?.chainFamily === "string"
    );
  }

  // src/content/index.ts
  var TRUSTED_WALLET_SYNC_ORIGINS = /* @__PURE__ */ new Set([
    "http://85.239.59.199:8080",
    "http://24wallet.ru",
    "https://24wallet.ru",
    "http://www.24wallet.ru",
    "https://www.24wallet.ru",
    "http://localhost:3000",
    "http://127.0.0.1:3000"
  ]);
  window.addEventListener("message", handleWindowMessage);
  chrome.storage.onChanged.addListener((_changes, areaName) => {
    if (areaName === "local") {
      void syncOriginState();
    }
  });
  void syncOriginState();
  function handleWindowMessage(event) {
    if (event.source !== window) {
      return;
    }
    if (isInpageRequestEnvelope(event.data)) {
      const request = event.data;
      void chrome.runtime.sendMessage({
        kind: "provider_request",
        requestId: request.requestId,
        surface: "content",
        origin: window.location.origin,
        method: request.method,
        params: request.params ?? []
      }).then((response) => {
        postInpageResponse(request.requestId, response);
        return syncOriginState();
      }).catch((error) => {
        const response = {
          type: ACORUS_INPAGE_RESPONSE,
          requestId: request.requestId,
          ok: false,
          error: {
            code: "bridge_error",
            message: error instanceof Error ? error.message : "Failed to route the Acorus extension message."
          }
        };
        window.postMessage(response, window.location.origin);
      });
      return;
    }
    if (!isTrustedWalletSyncEnvelope(event.data)) {
      return;
    }
    void chrome.runtime.sendMessage({
      kind: "sync_wallet_profiles",
      requestId: createRequestId("wallet_sync"),
      surface: "content",
      origin: window.location.origin,
      payload: event.data
    }).then(() => syncOriginState()).catch(() => {
    });
  }
  function postInpageResponse(requestId, response) {
    const payload = {
      type: ACORUS_INPAGE_RESPONSE,
      requestId,
      ok: response.ok,
      result: response.result,
      error: response.error
    };
    window.postMessage(payload, window.location.origin);
  }
  async function syncOriginState() {
    try {
      const response = await chrome.runtime.sendMessage({
        kind: "get_state",
        requestId: createRequestId("content"),
        surface: "content",
        origin: window.location.origin
      });
      if (!response.ok || !response.result) {
        return;
      }
      const state = response.result;
      if (!state.activeOriginBridge) {
        return;
      }
      const payload = {
        type: ACORUS_INPAGE_STATE,
        state: state.activeOriginBridge
      };
      window.postMessage(payload, window.location.origin);
    } catch {
    }
  }
  function isTrustedWalletSyncEnvelope(value) {
    return TRUSTED_WALLET_SYNC_ORIGINS.has(window.location.origin) && isDappWalletSyncEnvelope(value);
  }
})();
