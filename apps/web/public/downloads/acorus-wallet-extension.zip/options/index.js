"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../../node_modules/.pnpm/base64-js@1.5.1/node_modules/base64-js/index.js
  var require_base64_js = __commonJS({
    "../../node_modules/.pnpm/base64-js@1.5.1/node_modules/base64-js/index.js"(exports) {
      "use strict";
      init_node_compat_inject();
      exports.byteLength = byteLength;
      exports.toByteArray = toByteArray;
      exports.fromByteArray = fromByteArray;
      var lookup = [];
      var revLookup = [];
      var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
      var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for (i = 0, len = code.length; i < len; ++i) {
        lookup[i] = code[i];
        revLookup[code.charCodeAt(i)] = i;
      }
      var i;
      var len;
      revLookup["-".charCodeAt(0)] = 62;
      revLookup["_".charCodeAt(0)] = 63;
      function getLens(b64) {
        var len2 = b64.length;
        if (len2 % 4 > 0) {
          throw new Error("Invalid string. Length must be a multiple of 4");
        }
        var validLen = b64.indexOf("=");
        if (validLen === -1) validLen = len2;
        var placeHoldersLen = validLen === len2 ? 0 : 4 - validLen % 4;
        return [validLen, placeHoldersLen];
      }
      function byteLength(b64) {
        var lens = getLens(b64);
        var validLen = lens[0];
        var placeHoldersLen = lens[1];
        return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
      }
      function _byteLength(b64, validLen, placeHoldersLen) {
        return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
      }
      function toByteArray(b64) {
        var tmp;
        var lens = getLens(b64);
        var validLen = lens[0];
        var placeHoldersLen = lens[1];
        var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
        var curByte = 0;
        var len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
        var i2;
        for (i2 = 0; i2 < len2; i2 += 4) {
          tmp = revLookup[b64.charCodeAt(i2)] << 18 | revLookup[b64.charCodeAt(i2 + 1)] << 12 | revLookup[b64.charCodeAt(i2 + 2)] << 6 | revLookup[b64.charCodeAt(i2 + 3)];
          arr[curByte++] = tmp >> 16 & 255;
          arr[curByte++] = tmp >> 8 & 255;
          arr[curByte++] = tmp & 255;
        }
        if (placeHoldersLen === 2) {
          tmp = revLookup[b64.charCodeAt(i2)] << 2 | revLookup[b64.charCodeAt(i2 + 1)] >> 4;
          arr[curByte++] = tmp & 255;
        }
        if (placeHoldersLen === 1) {
          tmp = revLookup[b64.charCodeAt(i2)] << 10 | revLookup[b64.charCodeAt(i2 + 1)] << 4 | revLookup[b64.charCodeAt(i2 + 2)] >> 2;
          arr[curByte++] = tmp >> 8 & 255;
          arr[curByte++] = tmp & 255;
        }
        return arr;
      }
      function tripletToBase64(num) {
        return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
      }
      function encodeChunk(uint8, start, end) {
        var tmp;
        var output = [];
        for (var i2 = start; i2 < end; i2 += 3) {
          tmp = (uint8[i2] << 16 & 16711680) + (uint8[i2 + 1] << 8 & 65280) + (uint8[i2 + 2] & 255);
          output.push(tripletToBase64(tmp));
        }
        return output.join("");
      }
      function fromByteArray(uint8) {
        var tmp;
        var len2 = uint8.length;
        var extraBytes = len2 % 3;
        var parts = [];
        var maxChunkLength = 16383;
        for (var i2 = 0, len22 = len2 - extraBytes; i2 < len22; i2 += maxChunkLength) {
          parts.push(encodeChunk(uint8, i2, i2 + maxChunkLength > len22 ? len22 : i2 + maxChunkLength));
        }
        if (extraBytes === 1) {
          tmp = uint8[len2 - 1];
          parts.push(
            lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "=="
          );
        } else if (extraBytes === 2) {
          tmp = (uint8[len2 - 2] << 8) + uint8[len2 - 1];
          parts.push(
            lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "="
          );
        }
        return parts.join("");
      }
    }
  });

  // ../../node_modules/.pnpm/ieee754@1.2.1/node_modules/ieee754/index.js
  var require_ieee754 = __commonJS({
    "../../node_modules/.pnpm/ieee754@1.2.1/node_modules/ieee754/index.js"(exports) {
      "use strict";
      init_node_compat_inject();
      exports.read = function(buffer, offset, isLE, mLen, nBytes) {
        var e, m;
        var eLen = nBytes * 8 - mLen - 1;
        var eMax = (1 << eLen) - 1;
        var eBias = eMax >> 1;
        var nBits = -7;
        var i = isLE ? nBytes - 1 : 0;
        var d = isLE ? -1 : 1;
        var s = buffer[offset + i];
        i += d;
        e = s & (1 << -nBits) - 1;
        s >>= -nBits;
        nBits += eLen;
        for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {
        }
        m = e & (1 << -nBits) - 1;
        e >>= -nBits;
        nBits += mLen;
        for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {
        }
        if (e === 0) {
          e = 1 - eBias;
        } else if (e === eMax) {
          return m ? NaN : (s ? -1 : 1) * Infinity;
        } else {
          m = m + Math.pow(2, mLen);
          e = e - eBias;
        }
        return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
      };
      exports.write = function(buffer, value, offset, isLE, mLen, nBytes) {
        var e, m, c;
        var eLen = nBytes * 8 - mLen - 1;
        var eMax = (1 << eLen) - 1;
        var eBias = eMax >> 1;
        var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
        var i = isLE ? 0 : nBytes - 1;
        var d = isLE ? 1 : -1;
        var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
        value = Math.abs(value);
        if (isNaN(value) || value === Infinity) {
          m = isNaN(value) ? 1 : 0;
          e = eMax;
        } else {
          e = Math.floor(Math.log(value) / Math.LN2);
          if (value * (c = Math.pow(2, -e)) < 1) {
            e--;
            c *= 2;
          }
          if (e + eBias >= 1) {
            value += rt / c;
          } else {
            value += rt * Math.pow(2, 1 - eBias);
          }
          if (value * c >= 2) {
            e++;
            c /= 2;
          }
          if (e + eBias >= eMax) {
            m = 0;
            e = eMax;
          } else if (e + eBias >= 1) {
            m = (value * c - 1) * Math.pow(2, mLen);
            e = e + eBias;
          } else {
            m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
            e = 0;
          }
        }
        for (; mLen >= 8; buffer[offset + i] = m & 255, i += d, m /= 256, mLen -= 8) {
        }
        e = e << mLen | m;
        eLen += mLen;
        for (; eLen > 0; buffer[offset + i] = e & 255, i += d, e /= 256, eLen -= 8) {
        }
        buffer[offset + i - d] |= s * 128;
      };
    }
  });

  // ../../node_modules/.pnpm/buffer@6.0.3/node_modules/buffer/index.js
  var require_buffer = __commonJS({
    "../../node_modules/.pnpm/buffer@6.0.3/node_modules/buffer/index.js"(exports) {
      "use strict";
      init_node_compat_inject();
      var base64 = require_base64_js();
      var ieee754 = require_ieee754();
      var customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
      exports.Buffer = Buffer3;
      exports.SlowBuffer = SlowBuffer;
      exports.INSPECT_MAX_BYTES = 50;
      var K_MAX_LENGTH = 2147483647;
      exports.kMaxLength = K_MAX_LENGTH;
      Buffer3.TYPED_ARRAY_SUPPORT = typedArraySupport();
      if (!Buffer3.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
        console.error(
          "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
        );
      }
      function typedArraySupport() {
        try {
          const arr = new Uint8Array(1);
          const proto = { foo: function() {
            return 42;
          } };
          Object.setPrototypeOf(proto, Uint8Array.prototype);
          Object.setPrototypeOf(arr, proto);
          return arr.foo() === 42;
        } catch (e) {
          return false;
        }
      }
      Object.defineProperty(Buffer3.prototype, "parent", {
        enumerable: true,
        get: function() {
          if (!Buffer3.isBuffer(this)) return void 0;
          return this.buffer;
        }
      });
      Object.defineProperty(Buffer3.prototype, "offset", {
        enumerable: true,
        get: function() {
          if (!Buffer3.isBuffer(this)) return void 0;
          return this.byteOffset;
        }
      });
      function createBuffer(length) {
        if (length > K_MAX_LENGTH) {
          throw new RangeError('The value "' + length + '" is invalid for option "size"');
        }
        const buf = new Uint8Array(length);
        Object.setPrototypeOf(buf, Buffer3.prototype);
        return buf;
      }
      function Buffer3(arg, encodingOrOffset, length) {
        if (typeof arg === "number") {
          if (typeof encodingOrOffset === "string") {
            throw new TypeError(
              'The "string" argument must be of type string. Received type number'
            );
          }
          return allocUnsafe(arg);
        }
        return from(arg, encodingOrOffset, length);
      }
      Buffer3.poolSize = 8192;
      function from(value, encodingOrOffset, length) {
        if (typeof value === "string") {
          return fromString(value, encodingOrOffset);
        }
        if (ArrayBuffer.isView(value)) {
          return fromArrayView(value);
        }
        if (value == null) {
          throw new TypeError(
            "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
          );
        }
        if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof value === "number") {
          throw new TypeError(
            'The "value" argument must not be of type number. Received type number'
          );
        }
        const valueOf = value.valueOf && value.valueOf();
        if (valueOf != null && valueOf !== value) {
          return Buffer3.from(valueOf, encodingOrOffset, length);
        }
        const b = fromObject(value);
        if (b) return b;
        if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") {
          return Buffer3.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
        }
        throw new TypeError(
          "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
        );
      }
      Buffer3.from = function(value, encodingOrOffset, length) {
        return from(value, encodingOrOffset, length);
      };
      Object.setPrototypeOf(Buffer3.prototype, Uint8Array.prototype);
      Object.setPrototypeOf(Buffer3, Uint8Array);
      function assertSize(size) {
        if (typeof size !== "number") {
          throw new TypeError('"size" argument must be of type number');
        } else if (size < 0) {
          throw new RangeError('The value "' + size + '" is invalid for option "size"');
        }
      }
      function alloc(size, fill, encoding) {
        assertSize(size);
        if (size <= 0) {
          return createBuffer(size);
        }
        if (fill !== void 0) {
          return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
        }
        return createBuffer(size);
      }
      Buffer3.alloc = function(size, fill, encoding) {
        return alloc(size, fill, encoding);
      };
      function allocUnsafe(size) {
        assertSize(size);
        return createBuffer(size < 0 ? 0 : checked(size) | 0);
      }
      Buffer3.allocUnsafe = function(size) {
        return allocUnsafe(size);
      };
      Buffer3.allocUnsafeSlow = function(size) {
        return allocUnsafe(size);
      };
      function fromString(string, encoding) {
        if (typeof encoding !== "string" || encoding === "") {
          encoding = "utf8";
        }
        if (!Buffer3.isEncoding(encoding)) {
          throw new TypeError("Unknown encoding: " + encoding);
        }
        const length = byteLength(string, encoding) | 0;
        let buf = createBuffer(length);
        const actual = buf.write(string, encoding);
        if (actual !== length) {
          buf = buf.slice(0, actual);
        }
        return buf;
      }
      function fromArrayLike(array) {
        const length = array.length < 0 ? 0 : checked(array.length) | 0;
        const buf = createBuffer(length);
        for (let i = 0; i < length; i += 1) {
          buf[i] = array[i] & 255;
        }
        return buf;
      }
      function fromArrayView(arrayView) {
        if (isInstance(arrayView, Uint8Array)) {
          const copy = new Uint8Array(arrayView);
          return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
        }
        return fromArrayLike(arrayView);
      }
      function fromArrayBuffer(array, byteOffset, length) {
        if (byteOffset < 0 || array.byteLength < byteOffset) {
          throw new RangeError('"offset" is outside of buffer bounds');
        }
        if (array.byteLength < byteOffset + (length || 0)) {
          throw new RangeError('"length" is outside of buffer bounds');
        }
        let buf;
        if (byteOffset === void 0 && length === void 0) {
          buf = new Uint8Array(array);
        } else if (length === void 0) {
          buf = new Uint8Array(array, byteOffset);
        } else {
          buf = new Uint8Array(array, byteOffset, length);
        }
        Object.setPrototypeOf(buf, Buffer3.prototype);
        return buf;
      }
      function fromObject(obj) {
        if (Buffer3.isBuffer(obj)) {
          const len = checked(obj.length) | 0;
          const buf = createBuffer(len);
          if (buf.length === 0) {
            return buf;
          }
          obj.copy(buf, 0, 0, len);
          return buf;
        }
        if (obj.length !== void 0) {
          if (typeof obj.length !== "number" || numberIsNaN(obj.length)) {
            return createBuffer(0);
          }
          return fromArrayLike(obj);
        }
        if (obj.type === "Buffer" && Array.isArray(obj.data)) {
          return fromArrayLike(obj.data);
        }
      }
      function checked(length) {
        if (length >= K_MAX_LENGTH) {
          throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
        }
        return length | 0;
      }
      function SlowBuffer(length) {
        if (+length != length) {
          length = 0;
        }
        return Buffer3.alloc(+length);
      }
      Buffer3.isBuffer = function isBuffer(b) {
        return b != null && b._isBuffer === true && b !== Buffer3.prototype;
      };
      Buffer3.compare = function compare(a, b) {
        if (isInstance(a, Uint8Array)) a = Buffer3.from(a, a.offset, a.byteLength);
        if (isInstance(b, Uint8Array)) b = Buffer3.from(b, b.offset, b.byteLength);
        if (!Buffer3.isBuffer(a) || !Buffer3.isBuffer(b)) {
          throw new TypeError(
            'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
          );
        }
        if (a === b) return 0;
        let x = a.length;
        let y = b.length;
        for (let i = 0, len = Math.min(x, y); i < len; ++i) {
          if (a[i] !== b[i]) {
            x = a[i];
            y = b[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      Buffer3.isEncoding = function isEncoding(encoding) {
        switch (String(encoding).toLowerCase()) {
          case "hex":
          case "utf8":
          case "utf-8":
          case "ascii":
          case "latin1":
          case "binary":
          case "base64":
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return true;
          default:
            return false;
        }
      };
      Buffer3.concat = function concat(list, length) {
        if (!Array.isArray(list)) {
          throw new TypeError('"list" argument must be an Array of Buffers');
        }
        if (list.length === 0) {
          return Buffer3.alloc(0);
        }
        let i;
        if (length === void 0) {
          length = 0;
          for (i = 0; i < list.length; ++i) {
            length += list[i].length;
          }
        }
        const buffer = Buffer3.allocUnsafe(length);
        let pos = 0;
        for (i = 0; i < list.length; ++i) {
          let buf = list[i];
          if (isInstance(buf, Uint8Array)) {
            if (pos + buf.length > buffer.length) {
              if (!Buffer3.isBuffer(buf)) buf = Buffer3.from(buf);
              buf.copy(buffer, pos);
            } else {
              Uint8Array.prototype.set.call(
                buffer,
                buf,
                pos
              );
            }
          } else if (!Buffer3.isBuffer(buf)) {
            throw new TypeError('"list" argument must be an Array of Buffers');
          } else {
            buf.copy(buffer, pos);
          }
          pos += buf.length;
        }
        return buffer;
      };
      function byteLength(string, encoding) {
        if (Buffer3.isBuffer(string)) {
          return string.length;
        }
        if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
          return string.byteLength;
        }
        if (typeof string !== "string") {
          throw new TypeError(
            'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string
          );
        }
        const len = string.length;
        const mustMatch = arguments.length > 2 && arguments[2] === true;
        if (!mustMatch && len === 0) return 0;
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "ascii":
            case "latin1":
            case "binary":
              return len;
            case "utf8":
            case "utf-8":
              return utf8ToBytes(string).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return len * 2;
            case "hex":
              return len >>> 1;
            case "base64":
              return base64ToBytes(string).length;
            default:
              if (loweredCase) {
                return mustMatch ? -1 : utf8ToBytes(string).length;
              }
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer3.byteLength = byteLength;
      function slowToString(encoding, start, end) {
        let loweredCase = false;
        if (start === void 0 || start < 0) {
          start = 0;
        }
        if (start > this.length) {
          return "";
        }
        if (end === void 0 || end > this.length) {
          end = this.length;
        }
        if (end <= 0) {
          return "";
        }
        end >>>= 0;
        start >>>= 0;
        if (end <= start) {
          return "";
        }
        if (!encoding) encoding = "utf8";
        while (true) {
          switch (encoding) {
            case "hex":
              return hexSlice(this, start, end);
            case "utf8":
            case "utf-8":
              return utf8Slice(this, start, end);
            case "ascii":
              return asciiSlice(this, start, end);
            case "latin1":
            case "binary":
              return latin1Slice(this, start, end);
            case "base64":
              return base64Slice(this, start, end);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return utf16leSlice(this, start, end);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = (encoding + "").toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer3.prototype._isBuffer = true;
      function swap(b, n, m) {
        const i = b[n];
        b[n] = b[m];
        b[m] = i;
      }
      Buffer3.prototype.swap16 = function swap16() {
        const len = this.length;
        if (len % 2 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 16-bits");
        }
        for (let i = 0; i < len; i += 2) {
          swap(this, i, i + 1);
        }
        return this;
      };
      Buffer3.prototype.swap32 = function swap32() {
        const len = this.length;
        if (len % 4 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 32-bits");
        }
        for (let i = 0; i < len; i += 4) {
          swap(this, i, i + 3);
          swap(this, i + 1, i + 2);
        }
        return this;
      };
      Buffer3.prototype.swap64 = function swap64() {
        const len = this.length;
        if (len % 8 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 64-bits");
        }
        for (let i = 0; i < len; i += 8) {
          swap(this, i, i + 7);
          swap(this, i + 1, i + 6);
          swap(this, i + 2, i + 5);
          swap(this, i + 3, i + 4);
        }
        return this;
      };
      Buffer3.prototype.toString = function toString() {
        const length = this.length;
        if (length === 0) return "";
        if (arguments.length === 0) return utf8Slice(this, 0, length);
        return slowToString.apply(this, arguments);
      };
      Buffer3.prototype.toLocaleString = Buffer3.prototype.toString;
      Buffer3.prototype.equals = function equals(b) {
        if (!Buffer3.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
        if (this === b) return true;
        return Buffer3.compare(this, b) === 0;
      };
      Buffer3.prototype.inspect = function inspect() {
        let str = "";
        const max = exports.INSPECT_MAX_BYTES;
        str = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
        if (this.length > max) str += " ... ";
        return "<Buffer " + str + ">";
      };
      if (customInspectSymbol) {
        Buffer3.prototype[customInspectSymbol] = Buffer3.prototype.inspect;
      }
      Buffer3.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
        if (isInstance(target, Uint8Array)) {
          target = Buffer3.from(target, target.offset, target.byteLength);
        }
        if (!Buffer3.isBuffer(target)) {
          throw new TypeError(
            'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target
          );
        }
        if (start === void 0) {
          start = 0;
        }
        if (end === void 0) {
          end = target ? target.length : 0;
        }
        if (thisStart === void 0) {
          thisStart = 0;
        }
        if (thisEnd === void 0) {
          thisEnd = this.length;
        }
        if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
          throw new RangeError("out of range index");
        }
        if (thisStart >= thisEnd && start >= end) {
          return 0;
        }
        if (thisStart >= thisEnd) {
          return -1;
        }
        if (start >= end) {
          return 1;
        }
        start >>>= 0;
        end >>>= 0;
        thisStart >>>= 0;
        thisEnd >>>= 0;
        if (this === target) return 0;
        let x = thisEnd - thisStart;
        let y = end - start;
        const len = Math.min(x, y);
        const thisCopy = this.slice(thisStart, thisEnd);
        const targetCopy = target.slice(start, end);
        for (let i = 0; i < len; ++i) {
          if (thisCopy[i] !== targetCopy[i]) {
            x = thisCopy[i];
            y = targetCopy[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
        if (buffer.length === 0) return -1;
        if (typeof byteOffset === "string") {
          encoding = byteOffset;
          byteOffset = 0;
        } else if (byteOffset > 2147483647) {
          byteOffset = 2147483647;
        } else if (byteOffset < -2147483648) {
          byteOffset = -2147483648;
        }
        byteOffset = +byteOffset;
        if (numberIsNaN(byteOffset)) {
          byteOffset = dir ? 0 : buffer.length - 1;
        }
        if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
        if (byteOffset >= buffer.length) {
          if (dir) return -1;
          else byteOffset = buffer.length - 1;
        } else if (byteOffset < 0) {
          if (dir) byteOffset = 0;
          else return -1;
        }
        if (typeof val === "string") {
          val = Buffer3.from(val, encoding);
        }
        if (Buffer3.isBuffer(val)) {
          if (val.length === 0) {
            return -1;
          }
          return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
        } else if (typeof val === "number") {
          val = val & 255;
          if (typeof Uint8Array.prototype.indexOf === "function") {
            if (dir) {
              return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
            } else {
              return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
            }
          }
          return arrayIndexOf(buffer, [val], byteOffset, encoding, dir);
        }
        throw new TypeError("val must be string, number or Buffer");
      }
      function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
        let indexSize = 1;
        let arrLength = arr.length;
        let valLength = val.length;
        if (encoding !== void 0) {
          encoding = String(encoding).toLowerCase();
          if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
            if (arr.length < 2 || val.length < 2) {
              return -1;
            }
            indexSize = 2;
            arrLength /= 2;
            valLength /= 2;
            byteOffset /= 2;
          }
        }
        function read(buf, i2) {
          if (indexSize === 1) {
            return buf[i2];
          } else {
            return buf.readUInt16BE(i2 * indexSize);
          }
        }
        let i;
        if (dir) {
          let foundIndex = -1;
          for (i = byteOffset; i < arrLength; i++) {
            if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
              if (foundIndex === -1) foundIndex = i;
              if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
            } else {
              if (foundIndex !== -1) i -= i - foundIndex;
              foundIndex = -1;
            }
          }
        } else {
          if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
          for (i = byteOffset; i >= 0; i--) {
            let found = true;
            for (let j = 0; j < valLength; j++) {
              if (read(arr, i + j) !== read(val, j)) {
                found = false;
                break;
              }
            }
            if (found) return i;
          }
        }
        return -1;
      }
      Buffer3.prototype.includes = function includes(val, byteOffset, encoding) {
        return this.indexOf(val, byteOffset, encoding) !== -1;
      };
      Buffer3.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
      };
      Buffer3.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
      };
      function hexWrite(buf, string, offset, length) {
        offset = Number(offset) || 0;
        const remaining = buf.length - offset;
        if (!length) {
          length = remaining;
        } else {
          length = Number(length);
          if (length > remaining) {
            length = remaining;
          }
        }
        const strLen = string.length;
        if (length > strLen / 2) {
          length = strLen / 2;
        }
        let i;
        for (i = 0; i < length; ++i) {
          const parsed = parseInt(string.substr(i * 2, 2), 16);
          if (numberIsNaN(parsed)) return i;
          buf[offset + i] = parsed;
        }
        return i;
      }
      function utf8Write(buf, string, offset, length) {
        return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
      }
      function asciiWrite(buf, string, offset, length) {
        return blitBuffer(asciiToBytes(string), buf, offset, length);
      }
      function base64Write(buf, string, offset, length) {
        return blitBuffer(base64ToBytes(string), buf, offset, length);
      }
      function ucs2Write(buf, string, offset, length) {
        return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
      }
      Buffer3.prototype.write = function write(string, offset, length, encoding) {
        if (offset === void 0) {
          encoding = "utf8";
          length = this.length;
          offset = 0;
        } else if (length === void 0 && typeof offset === "string") {
          encoding = offset;
          length = this.length;
          offset = 0;
        } else if (isFinite(offset)) {
          offset = offset >>> 0;
          if (isFinite(length)) {
            length = length >>> 0;
            if (encoding === void 0) encoding = "utf8";
          } else {
            encoding = length;
            length = void 0;
          }
        } else {
          throw new Error(
            "Buffer.write(string, encoding, offset[, length]) is no longer supported"
          );
        }
        const remaining = this.length - offset;
        if (length === void 0 || length > remaining) length = remaining;
        if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
          throw new RangeError("Attempt to write outside buffer bounds");
        }
        if (!encoding) encoding = "utf8";
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "hex":
              return hexWrite(this, string, offset, length);
            case "utf8":
            case "utf-8":
              return utf8Write(this, string, offset, length);
            case "ascii":
            case "latin1":
            case "binary":
              return asciiWrite(this, string, offset, length);
            case "base64":
              return base64Write(this, string, offset, length);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return ucs2Write(this, string, offset, length);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      };
      Buffer3.prototype.toJSON = function toJSON() {
        return {
          type: "Buffer",
          data: Array.prototype.slice.call(this._arr || this, 0)
        };
      };
      function base64Slice(buf, start, end) {
        if (start === 0 && end === buf.length) {
          return base64.fromByteArray(buf);
        } else {
          return base64.fromByteArray(buf.slice(start, end));
        }
      }
      function utf8Slice(buf, start, end) {
        end = Math.min(buf.length, end);
        const res = [];
        let i = start;
        while (i < end) {
          const firstByte = buf[i];
          let codePoint = null;
          let bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
          if (i + bytesPerSequence <= end) {
            let secondByte, thirdByte, fourthByte, tempCodePoint;
            switch (bytesPerSequence) {
              case 1:
                if (firstByte < 128) {
                  codePoint = firstByte;
                }
                break;
              case 2:
                secondByte = buf[i + 1];
                if ((secondByte & 192) === 128) {
                  tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
                  if (tempCodePoint > 127) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 3:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
                  if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 4:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                fourthByte = buf[i + 3];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
                  if (tempCodePoint > 65535 && tempCodePoint < 1114112) {
                    codePoint = tempCodePoint;
                  }
                }
            }
          }
          if (codePoint === null) {
            codePoint = 65533;
            bytesPerSequence = 1;
          } else if (codePoint > 65535) {
            codePoint -= 65536;
            res.push(codePoint >>> 10 & 1023 | 55296);
            codePoint = 56320 | codePoint & 1023;
          }
          res.push(codePoint);
          i += bytesPerSequence;
        }
        return decodeCodePointsArray(res);
      }
      var MAX_ARGUMENTS_LENGTH = 4096;
      function decodeCodePointsArray(codePoints) {
        const len = codePoints.length;
        if (len <= MAX_ARGUMENTS_LENGTH) {
          return String.fromCharCode.apply(String, codePoints);
        }
        let res = "";
        let i = 0;
        while (i < len) {
          res += String.fromCharCode.apply(
            String,
            codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
          );
        }
        return res;
      }
      function asciiSlice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i] & 127);
        }
        return ret;
      }
      function latin1Slice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i]);
        }
        return ret;
      }
      function hexSlice(buf, start, end) {
        const len = buf.length;
        if (!start || start < 0) start = 0;
        if (!end || end < 0 || end > len) end = len;
        let out = "";
        for (let i = start; i < end; ++i) {
          out += hexSliceLookupTable[buf[i]];
        }
        return out;
      }
      function utf16leSlice(buf, start, end) {
        const bytes = buf.slice(start, end);
        let res = "";
        for (let i = 0; i < bytes.length - 1; i += 2) {
          res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
        }
        return res;
      }
      Buffer3.prototype.slice = function slice(start, end) {
        const len = this.length;
        start = ~~start;
        end = end === void 0 ? len : ~~end;
        if (start < 0) {
          start += len;
          if (start < 0) start = 0;
        } else if (start > len) {
          start = len;
        }
        if (end < 0) {
          end += len;
          if (end < 0) end = 0;
        } else if (end > len) {
          end = len;
        }
        if (end < start) end = start;
        const newBuf = this.subarray(start, end);
        Object.setPrototypeOf(newBuf, Buffer3.prototype);
        return newBuf;
      };
      function checkOffset(offset, ext, length) {
        if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
        if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
      }
      Buffer3.prototype.readUintLE = Buffer3.prototype.readUIntLE = function readUIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        return val;
      };
      Buffer3.prototype.readUintBE = Buffer3.prototype.readUIntBE = function readUIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          checkOffset(offset, byteLength2, this.length);
        }
        let val = this[offset + --byteLength2];
        let mul = 1;
        while (byteLength2 > 0 && (mul *= 256)) {
          val += this[offset + --byteLength2] * mul;
        }
        return val;
      };
      Buffer3.prototype.readUint8 = Buffer3.prototype.readUInt8 = function readUInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        return this[offset];
      };
      Buffer3.prototype.readUint16LE = Buffer3.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] | this[offset + 1] << 8;
      };
      Buffer3.prototype.readUint16BE = Buffer3.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] << 8 | this[offset + 1];
      };
      Buffer3.prototype.readUint32LE = Buffer3.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
      };
      Buffer3.prototype.readUint32BE = Buffer3.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
      };
      Buffer3.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
        const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last * 2 ** 24;
        return BigInt(lo) + (BigInt(hi) << BigInt(32));
      });
      Buffer3.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last;
        return (BigInt(hi) << BigInt(32)) + BigInt(lo);
      });
      Buffer3.prototype.readIntLE = function readIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer3.prototype.readIntBE = function readIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let i = byteLength2;
        let mul = 1;
        let val = this[offset + --i];
        while (i > 0 && (mul *= 256)) {
          val += this[offset + --i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer3.prototype.readInt8 = function readInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        if (!(this[offset] & 128)) return this[offset];
        return (255 - this[offset] + 1) * -1;
      };
      Buffer3.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset] | this[offset + 1] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer3.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset + 1] | this[offset] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer3.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
      };
      Buffer3.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
      };
      Buffer3.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last << 24);
        return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
      });
      Buffer3.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = (first << 24) + // Overflow
        this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last);
      });
      Buffer3.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee754.read(this, offset, true, 23, 4);
      };
      Buffer3.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee754.read(this, offset, false, 23, 4);
      };
      Buffer3.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee754.read(this, offset, true, 52, 8);
      };
      Buffer3.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee754.read(this, offset, false, 52, 8);
      };
      function checkInt(buf, value, offset, ext, max, min) {
        if (!Buffer3.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
      }
      Buffer3.prototype.writeUintLE = Buffer3.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let mul = 1;
        let i = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeUintBE = Buffer3.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeUint8 = Buffer3.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 255, 0);
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer3.prototype.writeUint16LE = Buffer3.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer3.prototype.writeUint16BE = Buffer3.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer3.prototype.writeUint32LE = Buffer3.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset + 3] = value >>> 24;
        this[offset + 2] = value >>> 16;
        this[offset + 1] = value >>> 8;
        this[offset] = value & 255;
        return offset + 4;
      };
      Buffer3.prototype.writeUint32BE = Buffer3.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      function wrtBigUInt64LE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        return offset;
      }
      function wrtBigUInt64BE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset + 7] = lo;
        lo = lo >> 8;
        buf[offset + 6] = lo;
        lo = lo >> 8;
        buf[offset + 5] = lo;
        lo = lo >> 8;
        buf[offset + 4] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset + 3] = hi;
        hi = hi >> 8;
        buf[offset + 2] = hi;
        hi = hi >> 8;
        buf[offset + 1] = hi;
        hi = hi >> 8;
        buf[offset] = hi;
        return offset + 8;
      }
      Buffer3.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer3.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer3.prototype.writeIntLE = function writeIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = 0;
        let mul = 1;
        let sub = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeIntBE = function writeIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        let sub = 0;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 127, -128);
        if (value < 0) value = 255 + value + 1;
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer3.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer3.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer3.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        this[offset + 2] = value >>> 16;
        this[offset + 3] = value >>> 24;
        return offset + 4;
      };
      Buffer3.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        if (value < 0) value = 4294967295 + value + 1;
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      Buffer3.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      Buffer3.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      function checkIEEE754(buf, value, offset, ext, max, min) {
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
        if (offset < 0) throw new RangeError("Index out of range");
      }
      function writeFloat(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 4, 34028234663852886e22, -34028234663852886e22);
        }
        ieee754.write(buf, value, offset, littleEndian, 23, 4);
        return offset + 4;
      }
      Buffer3.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
        return writeFloat(this, value, offset, true, noAssert);
      };
      Buffer3.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
        return writeFloat(this, value, offset, false, noAssert);
      };
      function writeDouble(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 8, 17976931348623157e292, -17976931348623157e292);
        }
        ieee754.write(buf, value, offset, littleEndian, 52, 8);
        return offset + 8;
      }
      Buffer3.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
        return writeDouble(this, value, offset, true, noAssert);
      };
      Buffer3.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
        return writeDouble(this, value, offset, false, noAssert);
      };
      Buffer3.prototype.copy = function copy(target, targetStart, start, end) {
        if (!Buffer3.isBuffer(target)) throw new TypeError("argument should be a Buffer");
        if (!start) start = 0;
        if (!end && end !== 0) end = this.length;
        if (targetStart >= target.length) targetStart = target.length;
        if (!targetStart) targetStart = 0;
        if (end > 0 && end < start) end = start;
        if (end === start) return 0;
        if (target.length === 0 || this.length === 0) return 0;
        if (targetStart < 0) {
          throw new RangeError("targetStart out of bounds");
        }
        if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
        if (end < 0) throw new RangeError("sourceEnd out of bounds");
        if (end > this.length) end = this.length;
        if (target.length - targetStart < end - start) {
          end = target.length - targetStart + start;
        }
        const len = end - start;
        if (this === target && typeof Uint8Array.prototype.copyWithin === "function") {
          this.copyWithin(targetStart, start, end);
        } else {
          Uint8Array.prototype.set.call(
            target,
            this.subarray(start, end),
            targetStart
          );
        }
        return len;
      };
      Buffer3.prototype.fill = function fill(val, start, end, encoding) {
        if (typeof val === "string") {
          if (typeof start === "string") {
            encoding = start;
            start = 0;
            end = this.length;
          } else if (typeof end === "string") {
            encoding = end;
            end = this.length;
          }
          if (encoding !== void 0 && typeof encoding !== "string") {
            throw new TypeError("encoding must be a string");
          }
          if (typeof encoding === "string" && !Buffer3.isEncoding(encoding)) {
            throw new TypeError("Unknown encoding: " + encoding);
          }
          if (val.length === 1) {
            const code = val.charCodeAt(0);
            if (encoding === "utf8" && code < 128 || encoding === "latin1") {
              val = code;
            }
          }
        } else if (typeof val === "number") {
          val = val & 255;
        } else if (typeof val === "boolean") {
          val = Number(val);
        }
        if (start < 0 || this.length < start || this.length < end) {
          throw new RangeError("Out of range index");
        }
        if (end <= start) {
          return this;
        }
        start = start >>> 0;
        end = end === void 0 ? this.length : end >>> 0;
        if (!val) val = 0;
        let i;
        if (typeof val === "number") {
          for (i = start; i < end; ++i) {
            this[i] = val;
          }
        } else {
          const bytes = Buffer3.isBuffer(val) ? val : Buffer3.from(val, encoding);
          const len = bytes.length;
          if (len === 0) {
            throw new TypeError('The value "' + val + '" is invalid for argument "value"');
          }
          for (i = 0; i < end - start; ++i) {
            this[i + start] = bytes[i % len];
          }
        }
        return this;
      };
      var errors = {};
      function E(sym, getMessage, Base) {
        errors[sym] = class NodeError extends Base {
          constructor() {
            super();
            Object.defineProperty(this, "message", {
              value: getMessage.apply(this, arguments),
              writable: true,
              configurable: true
            });
            this.name = `${this.name} [${sym}]`;
            this.stack;
            delete this.name;
          }
          get code() {
            return sym;
          }
          set code(value) {
            Object.defineProperty(this, "code", {
              configurable: true,
              enumerable: true,
              value,
              writable: true
            });
          }
          toString() {
            return `${this.name} [${sym}]: ${this.message}`;
          }
        };
      }
      E(
        "ERR_BUFFER_OUT_OF_BOUNDS",
        function(name) {
          if (name) {
            return `${name} is outside of buffer bounds`;
          }
          return "Attempt to access memory outside buffer bounds";
        },
        RangeError
      );
      E(
        "ERR_INVALID_ARG_TYPE",
        function(name, actual) {
          return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
        },
        TypeError
      );
      E(
        "ERR_OUT_OF_RANGE",
        function(str, range, input) {
          let msg = `The value of "${str}" is out of range.`;
          let received = input;
          if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
            received = addNumericalSeparator(String(input));
          } else if (typeof input === "bigint") {
            received = String(input);
            if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
              received = addNumericalSeparator(received);
            }
            received += "n";
          }
          msg += ` It must be ${range}. Received ${received}`;
          return msg;
        },
        RangeError
      );
      function addNumericalSeparator(val) {
        let res = "";
        let i = val.length;
        const start = val[0] === "-" ? 1 : 0;
        for (; i >= start + 4; i -= 3) {
          res = `_${val.slice(i - 3, i)}${res}`;
        }
        return `${val.slice(0, i)}${res}`;
      }
      function checkBounds(buf, offset, byteLength2) {
        validateNumber(offset, "offset");
        if (buf[offset] === void 0 || buf[offset + byteLength2] === void 0) {
          boundsError(offset, buf.length - (byteLength2 + 1));
        }
      }
      function checkIntBI(value, min, max, buf, offset, byteLength2) {
        if (value > max || value < min) {
          const n = typeof min === "bigint" ? "n" : "";
          let range;
          if (byteLength2 > 3) {
            if (min === 0 || min === BigInt(0)) {
              range = `>= 0${n} and < 2${n} ** ${(byteLength2 + 1) * 8}${n}`;
            } else {
              range = `>= -(2${n} ** ${(byteLength2 + 1) * 8 - 1}${n}) and < 2 ** ${(byteLength2 + 1) * 8 - 1}${n}`;
            }
          } else {
            range = `>= ${min}${n} and <= ${max}${n}`;
          }
          throw new errors.ERR_OUT_OF_RANGE("value", range, value);
        }
        checkBounds(buf, offset, byteLength2);
      }
      function validateNumber(value, name) {
        if (typeof value !== "number") {
          throw new errors.ERR_INVALID_ARG_TYPE(name, "number", value);
        }
      }
      function boundsError(value, length, type) {
        if (Math.floor(value) !== value) {
          validateNumber(value, type);
          throw new errors.ERR_OUT_OF_RANGE(type || "offset", "an integer", value);
        }
        if (length < 0) {
          throw new errors.ERR_BUFFER_OUT_OF_BOUNDS();
        }
        throw new errors.ERR_OUT_OF_RANGE(
          type || "offset",
          `>= ${type ? 1 : 0} and <= ${length}`,
          value
        );
      }
      var INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
      function base64clean(str) {
        str = str.split("=")[0];
        str = str.trim().replace(INVALID_BASE64_RE, "");
        if (str.length < 2) return "";
        while (str.length % 4 !== 0) {
          str = str + "=";
        }
        return str;
      }
      function utf8ToBytes(string, units) {
        units = units || Infinity;
        let codePoint;
        const length = string.length;
        let leadSurrogate = null;
        const bytes = [];
        for (let i = 0; i < length; ++i) {
          codePoint = string.charCodeAt(i);
          if (codePoint > 55295 && codePoint < 57344) {
            if (!leadSurrogate) {
              if (codePoint > 56319) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              } else if (i + 1 === length) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              }
              leadSurrogate = codePoint;
              continue;
            }
            if (codePoint < 56320) {
              if ((units -= 3) > -1) bytes.push(239, 191, 189);
              leadSurrogate = codePoint;
              continue;
            }
            codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
          } else if (leadSurrogate) {
            if ((units -= 3) > -1) bytes.push(239, 191, 189);
          }
          leadSurrogate = null;
          if (codePoint < 128) {
            if ((units -= 1) < 0) break;
            bytes.push(codePoint);
          } else if (codePoint < 2048) {
            if ((units -= 2) < 0) break;
            bytes.push(
              codePoint >> 6 | 192,
              codePoint & 63 | 128
            );
          } else if (codePoint < 65536) {
            if ((units -= 3) < 0) break;
            bytes.push(
              codePoint >> 12 | 224,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else if (codePoint < 1114112) {
            if ((units -= 4) < 0) break;
            bytes.push(
              codePoint >> 18 | 240,
              codePoint >> 12 & 63 | 128,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else {
            throw new Error("Invalid code point");
          }
        }
        return bytes;
      }
      function asciiToBytes(str) {
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          byteArray.push(str.charCodeAt(i) & 255);
        }
        return byteArray;
      }
      function utf16leToBytes(str, units) {
        let c, hi, lo;
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          if ((units -= 2) < 0) break;
          c = str.charCodeAt(i);
          hi = c >> 8;
          lo = c % 256;
          byteArray.push(lo);
          byteArray.push(hi);
        }
        return byteArray;
      }
      function base64ToBytes(str) {
        return base64.toByteArray(base64clean(str));
      }
      function blitBuffer(src, dst, offset, length) {
        let i;
        for (i = 0; i < length; ++i) {
          if (i + offset >= dst.length || i >= src.length) break;
          dst[i + offset] = src[i];
        }
        return i;
      }
      function isInstance(obj, type) {
        return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
      }
      function numberIsNaN(obj) {
        return obj !== obj;
      }
      var hexSliceLookupTable = (function() {
        const alphabet = "0123456789abcdef";
        const table = new Array(256);
        for (let i = 0; i < 16; ++i) {
          const i16 = i * 16;
          for (let j = 0; j < 16; ++j) {
            table[i16 + j] = alphabet[i] + alphabet[j];
          }
        }
        return table;
      })();
      function defineBigIntMethod(fn) {
        return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn;
      }
      function BufferBigIntNotDefined() {
        throw new Error("BigInt not supported");
      }
    }
  });

  // src/shared/node-compat-inject.ts
  var import_buffer, nodeProcess, globalWithNodeCompat;
  var init_node_compat_inject = __esm({
    "src/shared/node-compat-inject.ts"() {
      "use strict";
      import_buffer = __toESM(require_buffer(), 1);
      nodeProcess = {
        browser: true,
        env: {},
        version: ""
      };
      globalWithNodeCompat = globalThis;
      if (!globalWithNodeCompat.Buffer) {
        globalWithNodeCompat.Buffer = import_buffer.Buffer;
      }
      if (!globalWithNodeCompat.global) {
        globalWithNodeCompat.global = globalThis;
      }
      if (!globalWithNodeCompat.process) {
        globalWithNodeCompat.process = nodeProcess;
      }
    }
  });

  // src/options/index.ts
  init_node_compat_inject();

  // ../../packages/shared/src/index.ts
  init_node_compat_inject();

  // ../../packages/shared/src/chains.ts
  init_node_compat_inject();
  var DEFAULT_SOLANA_CHAIN_ID = 101;
  var DEFAULT_TRON_CHAIN_ID = "tron-mainnet";
  var DEFAULT_BITCOIN_CHAIN_ID = "bitcoin-mainnet";
  var DEFAULT_TON_CHAIN_ID = "ton-mainnet";
  var EVM_CHAINS = [
    {
      chainId: 1,
      family: "evm",
      name: "Ethereum",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ETH_RPC_URL",
      blockExplorerUrl: "https://etherscan.io"
    },
    {
      chainId: 56,
      family: "evm",
      name: "BNB Smart Chain",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_BSC_RPC_URL",
      blockExplorerUrl: "https://bscscan.com"
    },
    {
      chainId: 137,
      family: "evm",
      name: "Polygon",
      nativeSymbol: "MATIC",
      rpcUrlEnv: "NEXT_PUBLIC_POLYGON_RPC_URL",
      blockExplorerUrl: "https://polygonscan.com"
    },
    {
      chainId: 42161,
      family: "evm",
      name: "Arbitrum One",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ARBITRUM_RPC_URL",
      blockExplorerUrl: "https://arbiscan.io"
    },
    {
      chainId: 10,
      family: "evm",
      name: "Optimism",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_OPTIMISM_RPC_URL",
      blockExplorerUrl: "https://optimistic.etherscan.io"
    },
    {
      chainId: 8453,
      family: "evm",
      name: "Base",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_BASE_RPC_URL",
      blockExplorerUrl: "https://basescan.org"
    },
    {
      chainId: 43114,
      family: "evm",
      name: "Avalanche",
      nativeSymbol: "AVAX",
      rpcUrlEnv: "NEXT_PUBLIC_AVALANCHE_RPC_URL",
      blockExplorerUrl: "https://snowtrace.io"
    },
    {
      chainId: 59144,
      family: "evm",
      name: "Linea",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_LINEA_RPC_URL",
      blockExplorerUrl: "https://lineascan.build"
    },
    {
      chainId: 250,
      family: "evm",
      name: "Fantom",
      nativeSymbol: "FTM",
      rpcUrlEnv: "NEXT_PUBLIC_FANTOM_RPC_URL",
      blockExplorerUrl: "https://ftmscan.com"
    },
    {
      chainId: 1329,
      family: "evm",
      name: "Sei",
      nativeSymbol: "SEI",
      rpcUrlEnv: "NEXT_PUBLIC_SEI_RPC_URL",
      blockExplorerUrl: "https://seitrace.com"
    },
    {
      chainId: 204,
      family: "evm",
      name: "opBNB",
      nativeSymbol: "BNB",
      rpcUrlEnv: "NEXT_PUBLIC_OPBNB_RPC_URL",
      blockExplorerUrl: "https://opbnbscan.com"
    },
    {
      chainId: 324,
      family: "evm",
      name: "zkSync Era",
      nativeSymbol: "ETH",
      rpcUrlEnv: "NEXT_PUBLIC_ZKSYNC_RPC_URL",
      blockExplorerUrl: "https://era.zksync.network"
    }
  ];
  var SOLANA_MAINNET_CHAIN = {
    chainId: DEFAULT_SOLANA_CHAIN_ID,
    family: "solana",
    name: "Solana",
    network: "mainnet-beta",
    nativeSymbol: "SOL",
    rpcUrlEnv: "NEXT_PUBLIC_SOLANA_RPC_URL",
    blockExplorerUrl: "https://solscan.io"
  };
  var TRON_MAINNET_CHAIN = {
    family: "tron",
    chainId: DEFAULT_TRON_CHAIN_ID,
    name: "Tron",
    nativeSymbol: "TRX",
    rpcUrlEnv: "NEXT_PUBLIC_TRON_RPC_URL",
    blockExplorerUrl: "https://tronscan.org/#",
    isEnabled: false,
    isSkeleton: true
  };
  var BITCOIN_MAINNET_CHAIN = {
    family: "utxo",
    chainId: DEFAULT_BITCOIN_CHAIN_ID,
    name: "Bitcoin",
    nativeSymbol: "BTC",
    rpcUrlEnv: "NEXT_PUBLIC_BITCOIN_RPC_URL",
    blockExplorerUrl: "https://mempool.space",
    isEnabled: false,
    isSkeleton: true
  };
  var TON_MAINNET_CHAIN = {
    family: "ton",
    chainId: DEFAULT_TON_CHAIN_ID,
    name: "TON",
    nativeSymbol: "TON",
    rpcUrlEnv: "NEXT_PUBLIC_TON_RPC_URL",
    blockExplorerUrl: "https://tonscan.org",
    isEnabled: false,
    isSkeleton: true
  };
  var UNIVERSAL_CHAINS = [
    ...EVM_CHAINS.map((chain) => ({
      family: "evm",
      chainId: chain.chainId,
      name: chain.name,
      nativeSymbol: chain.nativeSymbol,
      rpcUrlEnv: chain.rpcUrlEnv,
      blockExplorerUrl: chain.blockExplorerUrl,
      isEnabled: true
    })),
    {
      family: SOLANA_MAINNET_CHAIN.family,
      chainId: SOLANA_MAINNET_CHAIN.chainId,
      name: SOLANA_MAINNET_CHAIN.name,
      nativeSymbol: SOLANA_MAINNET_CHAIN.nativeSymbol,
      rpcUrlEnv: SOLANA_MAINNET_CHAIN.rpcUrlEnv,
      blockExplorerUrl: SOLANA_MAINNET_CHAIN.blockExplorerUrl,
      network: SOLANA_MAINNET_CHAIN.network,
      isEnabled: true
    },
    TRON_MAINNET_CHAIN,
    BITCOIN_MAINNET_CHAIN,
    TON_MAINNET_CHAIN
  ];

  // ../../packages/shared/src/capabilities.ts
  init_node_compat_inject();

  // ../../packages/shared/src/dapp.ts
  init_node_compat_inject();
  var DAPP_PERMISSION_DEFINITIONS = [
    {
      id: "view_accounts",
      label: "View accounts",
      description: "Allow the site to see selected wallet addresses."
    },
    {
      id: "view_chain",
      label: "View active chain",
      description: "Allow the site to read the currently selected network."
    },
    {
      id: "switch_chain",
      label: "Switch chain",
      description: "Allow the site to request a network switch prompt."
    },
    {
      id: "add_chain",
      label: "Add networks",
      description: "Allow the site to request adding a custom EVM network."
    },
    {
      id: "watch_asset",
      label: "Watch assets",
      description: "Allow the site to request adding a visible token."
    },
    {
      id: "multichain_send",
      label: "Send assets",
      description: "Allow the site to request multichain send approvals."
    },
    {
      id: "swap",
      label: "Swap assets",
      description: "Allow the site to request swap approvals."
    },
    {
      id: "sign_message",
      label: "Sign messages",
      description: "Allow the site to request personal message signatures later."
    },
    {
      id: "sign_typed_data",
      label: "Sign typed data",
      description: "Allow the site to request typed data signatures later."
    },
    {
      id: "sign_transaction",
      label: "Sign transactions",
      description: "Allow the site to request transaction signatures later."
    },
    {
      id: "send_transaction",
      label: "Send transactions",
      description: "Allow the site to request transaction broadcasts later."
    }
  ];
  function getDappRequestKindLabel(kind) {
    switch (kind) {
      case "connect":
        return "Connect";
      case "add_chain":
        return "Add network";
      case "watch_asset":
        return "Watch asset";
      case "multichain_send":
        return "Send";
      case "swap":
        return "Swap";
      case "sign_message":
        return "Sign message";
      case "sign_typed_data":
        return "Sign typed data";
      case "sign_transaction":
        return "Sign transaction";
      case "send_transaction":
        return "Send transaction";
      default:
        return kind;
    }
  }
  function getDappSessionStatusLabel(status) {
    switch (status) {
      case "active":
        return "Active";
      case "revoked":
        return "Revoked";
      case "expired":
        return "Expired";
      default:
        return status;
    }
  }
  function getDappConnectionTransportLabel(transport) {
    switch (transport) {
      case "walletconnect":
        return "WalletConnect";
      case "injected":
      default:
        return "Injected";
    }
  }

  // ../../packages/shared/src/evm-swap.ts
  init_node_compat_inject();

  // ../../packages/shared/src/tokens.ts
  init_node_compat_inject();

  // ../../packages/shared/src/explore.ts
  init_node_compat_inject();

  // ../../packages/shared/src/market.ts
  init_node_compat_inject();

  // ../../packages/shared/src/multichain.ts
  init_node_compat_inject();

  // ../../packages/shared/src/practice.ts
  init_node_compat_inject();

  // ../../packages/shared/src/types.ts
  init_node_compat_inject();

  // src/shared/evm-compat.ts
  init_node_compat_inject();
  var EVM_COMPATIBILITY_METHODS = [
    "eth_requestAccounts",
    "eth_accounts",
    "eth_chainId",
    "web3_clientVersion",
    "net_version",
    "eth_coinbase",
    "wallet_getPermissions",
    "wallet_requestPermissions",
    "wallet_revokePermissions",
    "wallet_addEthereumChain",
    "wallet_switchEthereumChain",
    "wallet_watchAsset",
    "personal_sign",
    "eth_signTypedData_v4",
    "eth_signTransaction",
    "eth_sendTransaction"
  ];

  // src/shared/protocol.ts
  init_node_compat_inject();
  var ACORUS_PROVIDER_METHODS = [
    "acorus_ping",
    "acorus_getVaultStatus",
    "acorus_createWallet",
    "acorus_importWallet",
    "acorus_unlockWallet",
    "acorus_lockWallet",
    "acorus_receiveAddress",
    "acorus_requestAccounts",
    "acorus_accounts",
    "acorus_chainId",
    "acorus_switchChain",
    "acorus_getPermissions",
    "acorus_requestPermissions",
    "acorus_revokePermissions",
    "acorus_addChain",
    "acorus_watchAsset",
    "acorus_multichainSend",
    "acorus_swap",
    "acorus_signMessage",
    "acorus_signTypedData",
    "acorus_signTransaction",
    "acorus_sendTransaction"
  ];
  var EXTENSION_PHASES = [
    "Manifest V3 shell",
    "Background message router",
    "Content-to-inpage bridge",
    "Live preview provider bridge",
    "Popup and options shells",
    "Permission store types",
    "Connected sites UX",
    "Permission queue shell",
    "EVM compatibility",
    "Universal account controls",
    "WalletConnect pairing shell",
    "Multichain session request shell",
    "Signer unlock layer"
  ];
  function createRequestId(prefix = "acorus") {
    if (globalThis.crypto?.randomUUID) {
      return `${prefix}_${globalThis.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }
  function createSkeletonState(input) {
    return {
      phase: "permission_shell",
      providerInjection: input?.providerInjection ?? "stub_only",
      executionEnabled: input?.executionEnabled ?? true,
      proposals: input?.proposals ?? [],
      sessions: input?.sessions ?? [],
      pendingRequests: input?.pendingRequests ?? [],
      approvalResults: input?.approvalResults ?? [],
      activityLog: input?.activityLog ?? [],
      signerUnlockQueue: input?.signerUnlockQueue ?? [],
      activeOriginBridge: input?.activeOriginBridge ?? null,
      walletExposureMode: input?.walletExposureMode ?? "preview_accounts",
      walletExposedAccounts: input?.walletExposedAccounts ?? [],
      walletLastSyncedAt: input?.walletLastSyncedAt ?? null,
      extensionVaultStatus: input?.extensionVaultStatus ?? {
        hasVault: false,
        isUnlocked: false,
        activeProfileId: null,
        profiles: [],
        unlockedAt: null,
        createdAt: null,
        updatedAt: null
      },
      supportedMethods: ACORUS_PROVIDER_METHODS,
      lastUpdatedAt: input?.lastUpdatedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
      activeOrigin: input?.activeOrigin ?? null
    };
  }

  // src/options/index.ts
  var root = getRoot("Options root not found.");
  void loadOptionsState();
  async function loadOptionsState() {
    let state = createSkeletonState();
    try {
      const response = await chrome.runtime.sendMessage({
        kind: "get_state",
        requestId: createRequestId("options"),
        surface: "options",
        origin: null
      });
      if (response.ok && response.result) {
        state = response.result;
      }
    } catch {
      state = createSkeletonState();
    }
    root.innerHTML = renderOptions(state);
    wireOptionActions();
  }
  function renderOptions(state) {
    const bridge = state.activeOriginBridge;
    return `
    <main style="max-width:1100px;margin:0 auto;padding:32px 20px 48px;display:flex;flex-direction:column;gap:20px">
      <section style="border:1px solid rgba(71,85,105,0.5);background:linear-gradient(135deg,rgba(15,23,42,0.96),rgba(30,41,59,0.82));border-radius:28px;padding:24px">
        <div style="font-size:12px;letter-spacing:0.18em;text-transform:uppercase;color:#94a3b8">Acorus Extension</div>
        <h1 style="margin:12px 0 0;font-size:34px;line-height:1.15">Acorus Wallet control center</h1>
        <p style="margin:12px 0 0;color:#cbd5e1;font-size:15px;line-height:1.6">
          \u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043A\u043E\u0448\u0435\u043B\u044C\u043A\u043E\u043C, \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043D\u044B\u043C\u0438 \u0441\u0430\u0439\u0442\u0430\u043C\u0438, \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u043C\u0438 \u0441\u0435\u0442\u044F\u043C\u0438 \u0438 permission-\u0437\u0430\u043F\u0440\u043E\u0441\u0430\u043C\u0438.
          EVM dApps \u0432\u0438\u0434\u044F\u0442 <code>window.ethereum</code>, Solana dApps \u0432\u0438\u0434\u044F\u0442 <code>window.solana</code>,
          Tron dApps \u0432\u0438\u0434\u044F\u0442 <code>window.tronLink</code>, \u0430 Acorus-native \u0441\u0430\u0439\u0442\u044B \u043C\u043E\u0433\u0443\u0442 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C \u0435\u0434\u0438\u043D\u044B\u0439
          <code>window.acorus.providers</code> \u0434\u043B\u044F EVM, Solana, Tron, Bitcoin \u0438 TON.
        </p>
      </section>

      ${renderMultichainWalletSummary(state)}

      <section style="display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">
        <div style="border:1px solid rgba(245,158,11,0.35);background:rgba(245,158,11,0.12);border-radius:24px;padding:20px;color:#fde68a">
          <div style="font-size:12px;text-transform:uppercase;letter-spacing:0.14em">Proposals</div>
          <div style="margin-top:10px;font-size:32px;font-weight:700">${state.proposals.length}</div>
        </div>
        <div style="border:1px solid rgba(14,165,233,0.35);background:rgba(14,165,233,0.12);border-radius:24px;padding:20px;color:#bae6fd">
          <div style="font-size:12px;text-transform:uppercase;letter-spacing:0.14em">Pending requests</div>
          <div style="margin-top:10px;font-size:32px;font-weight:700">${state.pendingRequests.length}</div>
        </div>
        <div style="border:1px solid rgba(16,185,129,0.35);background:rgba(16,185,129,0.12);border-radius:24px;padding:20px;color:#d1fae5">
          <div style="font-size:12px;text-transform:uppercase;letter-spacing:0.14em">Active sessions</div>
          <div style="margin-top:10px;font-size:32px;font-weight:700">${state.sessions.filter((session) => session.status === "active").length}</div>
        </div>
        <div style="border:1px solid rgba(168,85,247,0.35);background:rgba(168,85,247,0.12);border-radius:24px;padding:20px;color:#e9d5ff">
          <div style="font-size:12px;text-transform:uppercase;letter-spacing:0.14em">Bridge status</div>
          <div style="margin-top:10px;font-size:32px;font-weight:700">${escapeHtml(bridge?.status ?? "disconnected")}</div>
        </div>
      </section>

      <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
        <h2 style="margin:0 0 10px;font-size:20px">Active origin bridge</h2>
        <div style="display:grid;gap:8px">
          <div style="font-size:14px;color:#fff">${escapeHtml(bridge?.origin ?? "No active origin selected")}</div>
          <div style="font-size:14px;color:#cbd5e1">Provider mode: <strong>${escapeHtml(bridge?.providerMode ?? "stub_only")}</strong></div>
          <div style="font-size:14px;color:#cbd5e1">Active chain: <strong>${escapeHtml(String(bridge?.activeChainId ?? "n/a"))}</strong></div>
          <div style="font-size:14px;color:#cbd5e1">Approved accounts: <strong>${escapeHtml((bridge?.accounts ?? []).join(", ") || "none")}</strong></div>
          <div style="font-size:14px;color:#cbd5e1">Wallet sync mode: <strong>${escapeHtml(state.walletExposureMode)}</strong></div>
          <div style="font-size:14px;color:#cbd5e1">Synced wallet accounts: <strong>${String(state.walletExposedAccounts.length)}</strong></div>
          <div style="font-size:14px;color:#cbd5e1">Default exposed account: <strong>${escapeHtml(state.walletExposedAccounts.find((profile) => profile.selected)?.account ?? "none")}</strong></div>
          <div style="font-size:14px;color:#cbd5e1">EVM compatibility: <strong>${escapeHtml(EVM_COMPATIBILITY_METHODS.join(", "))}</strong></div>
          <div style="font-size:12px;color:#94a3b8;line-height:1.5">${escapeHtml(bridge?.warning ?? "The bridge is idle until a page requests approval.")}</div>
        </div>
      </section>

      <section style="display:grid;gap:16px;grid-template-columns:minmax(0,1.2fr) minmax(320px,0.8fr)">
        <div style="display:grid;gap:16px">
          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">Connection proposals</h2>
            <div style="display:grid;gap:12px">${renderProposals(state)}</div>
          </section>

          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">Request queue</h2>
            <div style="display:grid;gap:12px">${renderRequests(state)}</div>
          </section>

          ${state.signerUnlockQueue.length ? `<section style="border:1px solid rgba(245,158,11,0.45);background:rgba(120,53,15,0.16);border-radius:24px;padding:20px">
                   <h2 style="margin:0 0 10px;font-size:20px;color:#fde68a">Signer confirmation gate</h2>
                   <p style="margin:0 0 12px;color:#fcd34d;font-size:14px;line-height:1.6">
                     Approved requests pause here until the user explicitly confirms inside the extension wallet.
                     After confirmation, the requesting dApp receives only the final signature or transaction hash for that approved request \u2014 never raw key material.
                   </p>
                   <div style="display:grid;gap:12px">${renderSignerUnlockQueue(state)}</div>
                 </section>` : ""}

          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">Connected peers</h2>
            <div style="display:grid;gap:12px">${renderSessions(state)}</div>
          </section>
        </div>

        <div style="display:grid;gap:16px">
          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">WalletConnect pairing shell</h2>
            <p style="margin:0;color:#cbd5e1;font-size:14px;line-height:1.6">
              Paste a WalletConnect URI to queue a preview-only pairing proposal. The
              symKey is redacted immediately and never persisted in extension state.
            </p>
            ${renderWalletConnectComposer()}
          </section>

          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">Session request studio</h2>
            <p style="margin:0;color:#cbd5e1;font-size:14px;line-height:1.6">
              Queue preview-only follow-up requests for any connected injected site
              or WalletConnect peer, with explicit chain and account context.
            </p>
            ${renderSessionRequestComposer(state)}
          </section>

          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">Synced wallet accounts</h2>
            <div style="display:grid;gap:10px">${renderWalletProfiles(state)}</div>
          </section>

          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">Permission model</h2>
            <div style="display:grid;gap:10px">
              ${DAPP_PERMISSION_DEFINITIONS.map(
      (permission) => `
                  <article style="border:1px solid rgba(51,65,85,1);border-radius:18px;padding:14px 16px;background:rgba(2,6,23,0.72)">
                    <div style="font-weight:600;color:#fff">${permission.label}</div>
                    <div style="margin-top:6px;color:#cbd5e1;font-size:14px;line-height:1.5">${permission.description}</div>
                  </article>`
    ).join("")}
            </div>
          </section>

          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">Safety constraints</h2>
            <ul style="margin:0;padding-left:18px;color:#cbd5e1;font-size:14px;line-height:1.7">
              <li>No seed or private key in webpages or content scripts</li>
              <li>No silent approvals or background signing</li>
              <li>No raw WalletConnect pairing secret persistence</li>
              <li>No live WalletConnect relay session in this wave</li>
              <li>No real client-side sign execution behind queued session requests yet</li>
              <li>No live transaction signing output or broadcast</li>
              <li>No automatic exposure of every synced account to every site</li>
            </ul>
          </section>

          <section style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:24px;padding:20px">
            <h2 style="margin:0 0 10px;font-size:20px">Recent decisions</h2>
            <div style="display:grid;gap:10px">${renderApprovalResults(state)}</div>
          </section>
        </div>
      </section>

      <details style="border:1px solid rgba(51,65,85,1);border-radius:24px;background:rgba(15,23,42,0.88);padding:18px">
        <summary style="cursor:pointer;font-weight:700;color:#fff">Developer roadmap phases</summary>
        <section style="display:grid;gap:12px;margin-top:14px">
          ${EXTENSION_PHASES.map(
      (phase, index) => `
            <div style="display:flex;justify-content:space-between;gap:12px;border:1px solid rgba(51,65,85,1);border-radius:20px;padding:16px;background:rgba(15,23,42,0.88)">
              <div>
                <div style="font-size:12px;color:#94a3b8">Phase ${index + 1}</div>
                <div style="margin-top:4px;font-weight:600;color:#fff">${phase}</div>
              </div>
              <span style="align-self:flex-start;border:1px solid rgba(250,204,21,0.35);background:rgba(250,204,21,0.12);color:#fde68a;border-radius:999px;padding:4px 8px;font-size:12px">${index < EXTENSION_PHASES.length ? "Preview" : "Planned"}</span>
            </div>`
    ).join("")}
        </section>
      </details>
    </main>
  `;
  }
  function renderMultichainWalletSummary(state) {
    const profiles = state.extensionVaultStatus.profiles.length ? state.extensionVaultStatus.profiles : state.walletExposedAccounts;
    const families = [
      ["evm", "EVM", "window.ethereum", "Ethereum, BNB, Polygon, Base, Arbitrum"],
      ["solana", "Solana", "window.solana", "SOL accounts and sign queue"],
      ["tron", "Tron", "window.tronLink", "TRX accounts and sign queue"],
      ["utxo", "Bitcoin", "window.acorusBitcoin", "BTC receive/send preview"],
      ["ton", "TON", "window.acorusTon", "TON receive/send preview"]
    ];
    return `
    <section style="display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(190px,1fr))">
      ${families.map(([family, label, provider, detail]) => {
      const profile = profiles.find((item) => item.chainFamily === family);
      return `
          <article style="border:1px solid rgba(51,65,85,1);background:rgba(15,23,42,0.88);border-radius:22px;padding:16px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
              <strong style="color:#fff">${label}</strong>
              <span style="${badgeStyle(profile ? "#10b981" : "#64748b")}">${profile ? "ready" : "preview"}</span>
            </div>
            <div style="margin-top:8px;color:#93c5fd;font-size:12px">${provider}</div>
            <div style="margin-top:8px;color:#cbd5e1;font-size:13px;line-height:1.45">${detail}</div>
            <div style="margin-top:10px;color:#94a3b8;font-size:12px;word-break:break-all">${escapeHtml(profile?.account ?? "No local account yet")}</div>
          </article>`;
    }).join("")}
    </section>`;
  }
  function getRoot(message) {
    const element = document.getElementById("app");
    if (!element) {
      throw new Error(message);
    }
    return element;
  }
  function renderProposals(state) {
    if (state.proposals.length === 0) {
      return emptyCard("No pending connection proposals.");
    }
    return state.proposals.map(
      (proposal) => `
        <article style="border:1px solid rgba(51,65,85,1);border-radius:18px;padding:14px 16px;background:rgba(2,6,23,0.72);display:grid;gap:10px">
          <div style="display:flex;justify-content:space-between;gap:12px">
            <div>
              <div style="font-weight:600;color:#fff">${escapeHtml(proposal.origin.title)}</div>
              <div style="margin-top:4px;font-size:12px;color:#94a3b8">${escapeHtml(proposal.origin.origin)}</div>
            </div>
            <span style="${badgeStyle(proposal.origin.trustLevel === "trusted" ? "#10b981" : "#f59e0b")}">${proposal.origin.trustLevel}</span>
          </div>
          <div style="font-size:14px;color:#cbd5e1;line-height:1.5">Transport: <strong>${escapeHtml(getDappConnectionTransportLabel(proposal.transport))}</strong></div>
          <div style="font-size:14px;color:#cbd5e1;line-height:1.5">Permissions: ${escapeHtml(proposal.requestedPermissions.join(", "))}</div>
          <div style="font-size:14px;color:#cbd5e1;line-height:1.5">Account to expose: <strong>${escapeHtml(proposal.requestedAccounts[0] ?? "none")}</strong></div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            ${actionButton("approve-proposal", proposal.id, "Approve account", true)}
            ${actionButton("reject-proposal", proposal.id, "Reject", false)}
          </div>
        </article>`
    ).join("");
  }
  function renderRequests(state) {
    if (state.pendingRequests.length === 0) {
      return emptyCard("No request prompts are waiting.");
    }
    return state.pendingRequests.map(
      (request) => `
        <article style="border:1px solid rgba(51,65,85,1);border-radius:18px;padding:14px 16px;background:rgba(2,6,23,0.72);display:grid;gap:10px">
          <div style="display:flex;justify-content:space-between;gap:12px">
            <div>
              <div style="font-weight:600;color:#fff">${escapeHtml(getDappRequestKindLabel(request.kind))}</div>
              <div style="margin-top:4px;font-size:12px;color:#94a3b8">${escapeHtml(request.origin.origin)}</div>
            </div>
            <span style="${badgeStyle("#0ea5e9")}">${request.chainId ?? "multi"}</span>
          </div>
          <div style="font-size:14px;color:#cbd5e1;line-height:1.5">Transport: <strong>${escapeHtml(getDappConnectionTransportLabel(request.transport))}</strong></div>
          <div style="font-size:14px;color:#cbd5e1;line-height:1.5">${escapeHtml(request.summary)}</div>
          ${request.warning ? `<div style="font-size:13px;color:#fbbf24;line-height:1.6">${escapeHtml(request.warning)}</div>` : ""}
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            ${actionButton("approve-request", request.id, "Approve to signer gate", true)}
            ${actionButton("reject-request", request.id, "Reject", false)}
          </div>
        </article>`
    ).join("");
  }
  function renderSignerUnlockQueue(state) {
    return state.signerUnlockQueue.map(
      (intent) => `
        <article style="border:1px solid rgba(245,158,11,0.45);border-radius:18px;padding:14px 16px;background:rgba(120,53,15,0.14);display:grid;gap:10px">
          <div style="display:flex;justify-content:space-between;gap:12px">
            <div>
              <div style="font-weight:600;color:#fff">${escapeHtml(getDappRequestKindLabel(intent.kind))}</div>
              <div style="margin-top:4px;font-size:12px;color:#fcd34d">${escapeHtml(intent.origin)}</div>
            </div>
            <span style="${badgeStyle(state.extensionVaultStatus.isUnlocked ? "#10b981" : "#f59e0b")}">${state.extensionVaultStatus.isUnlocked ? "ready" : "unlock required"}</span>
          </div>
          <div style="font-size:14px;color:#fde68a;line-height:1.5">${escapeHtml(intent.summary)}</div>
          ${intent.warning ? `<div style="font-size:13px;color:#fbbf24;line-height:1.6">${escapeHtml(intent.warning)}</div>` : ""}
          <div style="font-size:13px;color:#fcd34d">Account: <strong>${escapeHtml(intent.account ?? "none")}</strong> \xB7 Chain: <strong>${escapeHtml(String(intent.chainId ?? "multi"))}</strong></div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            ${actionButton("confirm-signer-unlock", intent.id, "Confirm", true)}
            ${actionButton("reject-signer-unlock", intent.id, "Reject", false)}
          </div>
        </article>`
    ).join("");
  }
  function renderSessions(state) {
    if (state.sessions.length === 0) {
      return emptyCard("No connected peers stored.");
    }
    return state.sessions.map(
      (session) => `
        <article style="border:1px solid rgba(51,65,85,1);border-radius:18px;padding:14px 16px;background:rgba(2,6,23,0.72);display:grid;gap:10px">
          <div style="display:flex;justify-content:space-between;gap:12px">
            <div>
              <div style="font-weight:600;color:#fff">${escapeHtml(session.origin.title)}</div>
              <div style="margin-top:4px;font-size:12px;color:#94a3b8">${escapeHtml(session.origin.origin)}</div>
            </div>
            <span style="${badgeStyle(session.status === "active" ? "#10b981" : "#ef4444")}">${escapeHtml(getDappSessionStatusLabel(session.status))}</span>
          </div>
          <div style="font-size:14px;color:#cbd5e1;line-height:1.5">Transport: <strong>${escapeHtml(getDappConnectionTransportLabel(session.transport))}</strong></div>
          <div style="font-size:14px;color:#cbd5e1;line-height:1.5">Permissions: ${escapeHtml(session.permissions.join(", "))}</div>
          <div style="font-size:14px;color:#cbd5e1;line-height:1.5">Exposed account: <strong>${escapeHtml(session.accounts[0] ?? "none")}</strong></div>
          ${renderSessionAccountActions(session.id, session.accounts[0] ?? null, state)}
          ${session.status === "active" ? `<div>${actionButton("revoke-session", session.id, "Revoke session", false)}</div>` : ""}
        </article>`
    ).join("");
  }
  function renderApprovalResults(state) {
    if (state.approvalResults.length === 0) {
      return emptyCard("No approvals or rejections recorded yet.");
    }
    return state.approvalResults.slice(0, 6).map(
      (result) => `
        <article style="border:1px solid rgba(51,65,85,1);border-radius:18px;padding:14px 16px;background:rgba(2,6,23,0.72)">
          <div style="display:flex;justify-content:space-between;gap:12px">
            <div style="font-weight:600;color:#fff">${result.decision} ${result.targetKind}</div>
            <div style="font-size:12px;color:#94a3b8">${escapeHtml(result.targetId)}</div>
          </div>
          ${result.reason ? `<div style="margin-top:6px;font-size:13px;color:#cbd5e1;line-height:1.5">${escapeHtml(result.reason)}</div>` : ""}
        </article>`
    ).join("");
  }
  function renderWalletProfiles(state) {
    if (state.walletExposedAccounts.length === 0) {
      return emptyCard("Open the Acorus web app in the same browser profile to sync local EVM wallet addresses into the extension bridge.");
    }
    return state.walletExposedAccounts.map(
      (profile) => `
        <article style="border:1px solid rgba(51,65,85,1);border-radius:18px;padding:14px 16px;background:rgba(2,6,23,0.72)">
          <div style="display:flex;justify-content:space-between;gap:12px">
            <div>
              <div style="font-weight:600;color:#fff">${escapeHtml(profile.name)}</div>
              <div style="margin-top:4px;font-size:12px;color:#94a3b8">${escapeHtml(profile.account)}</div>
            </div>
            <span style="${badgeStyle(profile.selected ? "#10b981" : "#0ea5e9")}">${profile.selected ? "selected" : "synced"}</span>
          </div>
          ${profile.selected ? `<div style="margin-top:10px;font-size:12px;color:#86efac">Default for new dApp connections</div>` : `<div style="margin-top:10px">${actionButton("select-wallet-profile", profile.profileId, "Use by default", true)}</div>`}
        </article>`
    ).join("");
  }
  function wireOptionActions() {
    const buttons = root.querySelectorAll("[data-action]");
    buttons.forEach((button) => {
      button.addEventListener("click", async () => {
        const action = button.dataset.action;
        const targetId = button.dataset.id;
        const extra = button.dataset.extra;
        if (!action || !targetId) {
          return;
        }
        button.disabled = true;
        try {
          await sendAction(action, targetId, extra);
        } finally {
          await loadOptionsState();
        }
      });
    });
    const pairingForm = root.querySelector("#walletconnect-pairing-form");
    const pairButton = root.querySelector("#walletconnect-pair-button");
    const uriField = root.querySelector("#walletconnect-uri");
    const titleField = root.querySelector("#walletconnect-title");
    const requestForm = root.querySelector("#session-request-form");
    const requestButton = root.querySelector("#session-request-button");
    const requestSessionField = root.querySelector("#session-request-session");
    const requestChainField = root.querySelector("#session-request-chain");
    const requestSummaryField = root.querySelector("#session-request-summary");
    const requestMeta = root.querySelector("#session-request-meta");
    pairingForm?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const uri = uriField?.value.trim() ?? "";
      const title = titleField?.value.trim() ?? "";
      if (!uri) {
        window.alert("Paste a WalletConnect URI first.");
        return;
      }
      if (pairButton) {
        pairButton.disabled = true;
      }
      try {
        const response = await chrome.runtime.sendMessage({
          kind: "queue_walletconnect_pairing",
          requestId: createRequestId("options"),
          surface: "options",
          uri,
          title: title || void 0
        });
        if (!response.ok) {
          window.alert(response.error?.message ?? "WalletConnect pairing preview failed.");
        }
      } finally {
        await loadOptionsState();
      }
    });
    const syncSessionRequestComposer = () => {
      if (!requestSessionField || !requestChainField) {
        return;
      }
      const selected = requestSessionField.selectedOptions[0];
      const chainIds = (selected?.dataset.chainIds ?? "").split(",").filter((value) => value.length > 0);
      const currentValue = requestChainField.value;
      requestChainField.innerHTML = chainIds.map((chainId) => `<option value="${escapeAttribute(chainId)}">${escapeHtml(chainId)}</option>`).join("");
      if (chainIds.includes(currentValue)) {
        requestChainField.value = currentValue;
      }
      if (requestMeta) {
        requestMeta.textContent = `${selected?.dataset.transport ?? "Injected"} \xB7 ${selected?.dataset.account ?? "No account exposed"}`;
      }
    };
    requestSessionField?.addEventListener("change", syncSessionRequestComposer);
    syncSessionRequestComposer();
    requestForm?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const sessionId = requestSessionField?.value ?? "";
      const requestKind = parseSessionRequestKind(
        root.querySelector("#session-request-kind")?.value ?? ""
      );
      const chainId = requestChainField?.value ?? "";
      const summary = requestSummaryField?.value.trim() ?? "";
      if (!sessionId || !requestKind) {
        window.alert("Choose a connected peer and request kind first.");
        return;
      }
      if (requestButton) {
        requestButton.disabled = true;
      }
      try {
        const response = await chrome.runtime.sendMessage({
          kind: "queue_session_request_preview",
          requestId: createRequestId("options"),
          surface: "options",
          sessionId,
          requestKind,
          chainId: chainId ? Number(chainId) : void 0,
          summary: summary || void 0
        });
        if (!response.ok) {
          window.alert(response.error?.message ?? "Session request preview failed.");
        }
      } finally {
        await loadOptionsState();
      }
    });
  }
  async function sendAction(action, targetId, extra) {
    if (action === "approve-proposal") {
      await chrome.runtime.sendMessage({
        kind: "approve_proposal",
        requestId: createRequestId("options"),
        surface: "options",
        proposalId: targetId
      });
      return;
    }
    if (action === "reject-proposal") {
      await chrome.runtime.sendMessage({
        kind: "reject_proposal",
        requestId: createRequestId("options"),
        surface: "options",
        proposalId: targetId
      });
      return;
    }
    if (action === "approve-request") {
      await chrome.runtime.sendMessage({
        kind: "approve_request",
        requestId: createRequestId("options"),
        surface: "options",
        requestIdTarget: targetId
      });
      return;
    }
    if (action === "reject-request") {
      await chrome.runtime.sendMessage({
        kind: "reject_request",
        requestId: createRequestId("options"),
        surface: "options",
        requestIdTarget: targetId
      });
      return;
    }
    if (action === "revoke-session") {
      await chrome.runtime.sendMessage({
        kind: "revoke_session",
        requestId: createRequestId("options"),
        surface: "options",
        sessionId: targetId
      });
      return;
    }
    if (action === "select-wallet-profile") {
      await chrome.runtime.sendMessage({
        kind: "select_wallet_profile",
        requestId: createRequestId("options"),
        surface: "options",
        profileId: targetId
      });
      return;
    }
    if (action === "set-session-account" && extra) {
      await chrome.runtime.sendMessage({
        kind: "set_session_account",
        requestId: createRequestId("options"),
        surface: "options",
        sessionId: targetId,
        profileId: extra
      });
      return;
    }
    if (action === "confirm-signer-unlock") {
      await chrome.runtime.sendMessage({
        kind: "confirm_signer_unlock",
        requestId: createRequestId("options"),
        surface: "options",
        intentId: targetId
      });
      return;
    }
    if (action === "reject-signer-unlock") {
      await chrome.runtime.sendMessage({
        kind: "reject_signer_unlock",
        requestId: createRequestId("options"),
        surface: "options",
        intentId: targetId
      });
    }
  }
  function actionButton(action, id, label, primary, extra) {
    return `<button data-action="${action}" data-id="${id}"${extra ? ` data-extra="${extra}"` : ""} style="border:1px solid ${primary ? "rgba(56,189,248,0.35)" : "rgba(71,85,105,0.7)"};background:${primary ? "rgba(14,165,233,0.12)" : "rgba(2,6,23,0.75)"};color:${primary ? "#bae6fd" : "#e2e8f0"};border-radius:999px;padding:8px 12px;font-size:12px;cursor:pointer">${label}</button>`;
  }
  function renderWalletConnectComposer() {
    return `
    <form id="walletconnect-pairing-form" style="margin-top:14px;display:grid;gap:10px">
      <label style="display:grid;gap:6px">
        <span style="font-size:12px;color:#94a3b8">Peer label</span>
        <input id="walletconnect-title" placeholder="Universal Swap" style="border:1px solid rgba(71,85,105,0.8);background:rgba(2,6,23,0.72);color:#fff;border-radius:16px;padding:12px 14px;font-size:14px" />
      </label>
      <label style="display:grid;gap:6px">
        <span style="font-size:12px;color:#94a3b8">WalletConnect URI</span>
        <textarea id="walletconnect-uri" rows="3" placeholder="wc:topic@2?relay-protocol=irn&symKey=..." style="border:1px solid rgba(71,85,105,0.8);background:rgba(2,6,23,0.72);color:#fff;border-radius:16px;padding:12px 14px;font-size:14px;resize:vertical"></textarea>
      </label>
      <div style="font-size:12px;color:#94a3b8;line-height:1.6">
        Acorus stores only redacted peer metadata in the preview queue. Live WalletConnect relay and WalletConnect-side execution remain disabled.
      </div>
      <div>
        <button id="walletconnect-pair-button" type="submit" style="border:1px solid rgba(56,189,248,0.35);background:rgba(14,165,233,0.12);color:#bae6fd;border-radius:999px;padding:10px 14px;font-size:12px;cursor:pointer">
          Queue pairing preview
        </button>
      </div>
    </form>`;
  }
  function renderSessionRequestComposer(state) {
    const activeSessions = state.sessions.filter((session) => session.status === "active");
    if (activeSessions.length === 0) {
      return emptyCard("Approve a site or WalletConnect peer first to queue preview requests.");
    }
    const firstSession = activeSessions[0];
    if (!firstSession) {
      return emptyCard("Approve a site or WalletConnect peer first to queue preview requests.");
    }
    const chainOptions = firstSession.chainIds.map((chainId) => `<option value="${chainId}">${chainId}</option>`).join("");
    return `
    <form id="session-request-form" style="margin-top:14px;display:grid;gap:10px">
      <label style="display:grid;gap:6px">
        <span style="font-size:12px;color:#94a3b8">Connected peer</span>
        <select id="session-request-session" style="border:1px solid rgba(71,85,105,0.8);background:rgba(2,6,23,0.72);color:#fff;border-radius:16px;padding:12px 14px;font-size:14px">
          ${activeSessions.map((session) => `
              <option
                value="${escapeAttribute(session.id)}"
                data-chain-ids="${escapeAttribute(session.chainIds.join(","))}"
                data-account="${escapeAttribute(session.accounts[0] ?? "")}"
                data-transport="${escapeAttribute(getDappConnectionTransportLabel(session.transport))}"
              >
                ${escapeHtml(session.origin.title)} \xB7 ${escapeHtml(getDappConnectionTransportLabel(session.transport))}
              </option>`).join("")}
        </select>
      </label>
      <div id="session-request-meta" style="font-size:12px;color:#94a3b8;line-height:1.6">
        ${escapeHtml(getDappConnectionTransportLabel(firstSession.transport))} \xB7 ${escapeHtml(firstSession.accounts[0] ?? "No account exposed")}
      </div>
      <div style="display:grid;gap:10px;grid-template-columns:repeat(2,minmax(0,1fr))">
        <label style="display:grid;gap:6px">
          <span style="font-size:12px;color:#94a3b8">Request kind</span>
          <select id="session-request-kind" style="border:1px solid rgba(71,85,105,0.8);background:rgba(2,6,23,0.72);color:#fff;border-radius:16px;padding:12px 14px;font-size:14px">
            <option value="sign_message">Sign message</option>
            <option value="sign_typed_data">Sign typed data</option>
            <option value="sign_transaction">Sign transaction</option>
            <option value="send_transaction">Send transaction</option>
          </select>
        </label>
        <label style="display:grid;gap:6px">
          <span style="font-size:12px;color:#94a3b8">Chain</span>
          <select id="session-request-chain" style="border:1px solid rgba(71,85,105,0.8);background:rgba(2,6,23,0.72);color:#fff;border-radius:16px;padding:12px 14px;font-size:14px">
            ${chainOptions}
          </select>
        </label>
      </div>
      <label style="display:grid;gap:6px">
        <span style="font-size:12px;color:#94a3b8">Summary override</span>
        <input id="session-request-summary" placeholder="Leave blank to auto-generate a preview summary" style="border:1px solid rgba(71,85,105,0.8);background:rgba(2,6,23,0.72);color:#fff;border-radius:16px;padding:12px 14px;font-size:14px" />
      </label>
      <div style="font-size:12px;color:#94a3b8;line-height:1.6">
        Requests target the selected peer's currently exposed account and chosen chain, then land in the same preview approval queue used by injected dApps.
      </div>
      <div>
        <button id="session-request-button" type="submit" style="border:1px solid rgba(56,189,248,0.35);background:rgba(14,165,233,0.12);color:#bae6fd;border-radius:999px;padding:10px 14px;font-size:12px;cursor:pointer">
          Queue request preview
        </button>
      </div>
    </form>`;
  }
  function renderSessionAccountActions(sessionId, currentAccount, state) {
    const alternatives = state.walletExposedAccounts.filter(
      (profile) => profile.account !== currentAccount
    );
    if (alternatives.length === 0) {
      return "";
    }
    return `
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      ${alternatives.map((profile) => actionButton(
      "set-session-account",
      sessionId,
      `Use ${escapeHtml(profile.name)}`,
      false,
      profile.profileId
    )).join("")}
    </div>`;
  }
  function emptyCard(message) {
    return `<div style="border:1px dashed rgba(71,85,105,0.8);border-radius:18px;padding:14px 16px;background:rgba(2,6,23,0.42);color:#94a3b8;font-size:13px">${message}</div>`;
  }
  function badgeStyle(color) {
    return `align-self:flex-start;border:1px solid ${color}55;background:${color}22;color:#e2e8f0;border-radius:999px;padding:4px 8px;font-size:12px`;
  }
  function escapeHtml(value) {
    return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
  }
  function escapeAttribute(value) {
    return escapeHtml(value).replaceAll('"', "&quot;").replaceAll("'", "&#39;");
  }
  function parseSessionRequestKind(value) {
    switch (value) {
      case "sign_message":
      case "sign_typed_data":
      case "sign_transaction":
      case "send_transaction":
        return value;
      default:
        return null;
    }
  }
})();
/*! Bundled license information:

ieee754/index.js:
  (*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> *)

buffer/index.js:
  (*!
   * The buffer module from node.js, for the browser.
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   *)
*/
